//
//  DGSensor.h — 传感器屏蔽模块对外接口
//
//  hook 本体在 Tweak.xm（Logos 只能在 .xm 里工作），这里只放状态与策略。
//

#import <Foundation/Foundation.h>
#import <CoreMotion/CoreMotion.h>

// 初始化内部状态（weak 表等），幂等
FOUNDATION_EXPORT void DGSensorSetup(void);

// 当前进程是否被禁止读取运动数据（总闸，任一传感器被禁就返回 YES 的旧行为）
FOUNDATION_EXPORT BOOL DGSensorBlockedForCurrentProcess(void);

// ---------------------------------------------------------------------------
//  按传感器类型分别判定（3.6.0）
// ---------------------------------------------------------------------------
//
//  为什么要拆开：
//    指南针（CLHeading）和磁力计（CMMagnetometer）不是同一条路径 ——
//    指南针走 CLLocationManager，磁力计走 CMMotionManager。
//    而且很多 App 只用指南针（地图、AR），并不读加速度计。
//    一个总开关没法表达「只拦指南针」。
//
//  每个函数都是「总闸 && 该传感器分项」：
//    总闸 = 全局 SensorEnabled + 该 App 的 sensor 键
//    分项 = 该 App 的对应子键（没设过就跟随总闸）

typedef NS_ENUM(NSInteger, DGSensorKind) {
    DGSensorKindAccelerometer = 0,  // 加速度计
    DGSensorKindGyro,               // 陀螺仪
    DGSensorKindMagnetometer,       // 磁力计
    DGSensorKindDeviceMotion,       // 设备姿态（融合）
    DGSensorKindCompass,            // 指南针（CLHeading）
    DGSensorKindLocation,           // 定位（CLLocationManager）
};

// 某个传感器是否应被屏蔽
FOUNDATION_EXPORT BOOL DGSensorBlockedKind(DGSensorKind kind);

// 该传感器对应的 per-App 特性名
FOUNDATION_EXPORT NSString *DGSensorFeatureForKind(DGSensorKind kind);

// 该传感器的中文名（日志用）
FOUNDATION_EXPORT NSString *DGSensorNameForKind(DGSensorKind kind);

// 记录一次被拦截的请求（首次会打日志）
FOUNDATION_EXPORT void DGSensorNoteBlocked(void);

// 线程局部的「正在转发」标志，hook 里用来防递归
FOUNDATION_EXPORT BOOL DGSensorIsForwarding(void);
FOUNDATION_EXPORT void DGSensorEnterForwarding(void);
FOUNDATION_EXPORT void DGSensorLeaveForwarding(void);

// 线程局部的「正在主动停流」标志，stop hook 里用来保住 resume block
FOUNDATION_EXPORT BOOL DGSensorIsRevoking(void);
FOUNDATION_EXPORT void DGSensorSetRevoking(BOOL revoking);

// 为 manager 取/建对应的流对象（accelerometer / deviceMotion 各一份）
@class DGStream;
FOUNDATION_EXPORT DGStream *DGSensorStreamFor(CMMotionManager *manager, BOOL motion);

// 流对象：记录 resume block、活跃状态、代次
@interface DGStream : NSObject
@property (nonatomic, copy) dispatch_block_t resume;
@property (nonatomic) BOOL active;
@property (nonatomic) NSUInteger generation;
@end

// 策略变化：重新评估所有活跃 manager，该停的停、该恢复的恢复
FOUNDATION_EXPORT void DGSensorPolicyChanged(void);

// ---------------------------------------------------------------------------
// 摇一摇拦截（借鉴 ShakeShield 的思路）
// ---------------------------------------------------------------------------
//
//  摇一摇广告不经过 openURL，走的是 UIResponder 的 motionEnded:withEvent:，
//  所以必须单独 hook。策略上采用「启动后时间窗口」：
//  App 刚启动的前 N 秒最容易触发摇一摇广告，之后放行，避免影响正常功能。

// 是否应该拦截摇一摇
FOUNDATION_EXPORT BOOL DGSensorShouldBlockShake(void);

// 摇一摇拦截是否启用（独立开关）
FOUNDATION_EXPORT BOOL DGShakeBlockEnabled(void);

// 启动时间窗口（秒），从偏好读，默认 15
FOUNDATION_EXPORT NSTimeInterval DGShakeBlockWindow(void);

// 记录本进程启动时刻（%ctor 里调）
FOUNDATION_EXPORT void DGShakeMarkLaunch(void);

