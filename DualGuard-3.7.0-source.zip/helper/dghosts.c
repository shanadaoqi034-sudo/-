//
//  dghosts.c — DualGuard hosts 写入助手（setuid root）
//
//  为什么需要它：
//    App 进程以 mobile 用户运行，/etc/hosts 是 root:wheel 644，
//    即使有 no-sandbox entitlement 也写不进去。
//    setuid root 的 helper 是标准解法。
//
//  安全设计（重要）：
//    * 只接受固定命令，不接受任意路径 —— 防止被其他程序滥用提权
//    * 所有输出写到 stdout，供 App 读取
//    * 写入前自动备份，写入失败自动回滚
//    * 不执行任何外部命令，不用 system()/popen()
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>

#define HOSTS_PATH      "/etc/hosts"
#define BACKUP_PATH     "/var/mobile/Library/Preferences/duguard_hosts.bak"
#define BEGIN_MARK      "# >>> DualGuard AdBlock Begin >>>"
#define END_MARK        "# <<< DualGuard AdBlock End <<<"

// 内置规则（与 App / tweak 保持一致）
static const char *kDomains[] = {
    // Google
    "doubleclick.net", "googleadservices.com", "googlesyndication.com",
    "google-analytics.com", "adservice.google.com",
    "pubads.g.doubleclick.net", "securepubads.g.doubleclick.net",
    "stats.g.doubleclick.net", "cm.g.doubleclick.net",
    // Meta
    "graph.facebook.com", "an.facebook.com", "connect.facebook.net",
    // 字节 / 穿山甲
    "pangle.io", "pangolin-sdk-toutiao.com", "pglstatp-toutiao.com",
    "gromore.pangle.io", "csjplatform.com", "bytedance.com",
    // 腾讯广点通
    "gdt.qq.com", "e.qq.com", "ad.qq.com", "pingjs.qq.com",
    "pingma.qq.com", "pgdt.gtimg.cn",
    // 阿里妈妈
    "alimama.com", "tanx.com", "mmstat.com", "simba.taobao.com",
    // 百度
    "cpro.baidu.com", "pos.baidu.com", "union.baidu.com", "cbjs.baidu.com",
    // 快手
    "adkwai.com", "ad.kuaishou.com",
    // 国际平台
    "applovin.com", "applvn.com", "unityads.unity3d.com",
    "vungle.com", "chartboost.com", "ironsrc.com", "supersonicads.com",
    "tapjoy.com", "inmobi.com", "mopub.com", "mintegral.com", "mbridg.cn",
    "admob.com", "adcolony.com", "fyber.com", "criteo.com",
    // 分析追踪
    "adjust.com", "appsflyer.com", "branch.io", "kochava.com",
    "umeng.com", "umengcloud.com", "talkingdata.com", "talkingdata.net",
    "bugly.qq.com", "growingio.com", "sensorsdata.cn",
    // 其他
    "mob.com", "mobads.baidu.com", "waps.cn",
    "union.360.cn", "show.360.cn",
    NULL
};

static char *read_file(const char *path, size_t *out_len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz < 0) { fclose(f); return NULL; }

    char *buf = malloc(sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t rd = fread(buf, 1, sz, f);
    buf[rd] = '\0';
    fclose(f);
    if (out_len) *out_len = rd;
    return buf;
}

static int write_file(const char *path, const char *content, size_t len) {
    if (!content || len == 0) return -1;
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return -1;
    size_t written = 0;
    while (written < len) {
        ssize_t n = write(fd, content + written, len - written);
        if (n <= 0) { close(fd); return -1; }
        written += (size_t)n;
    }
    close(fd);
    chmod(path, 0644);
    return 0;
}

// 从 hosts 内容里移除我们的标记块
static char *strip_block(const char *src) {
    if (!src) return strdup("");
    const char *b = strstr(src, BEGIN_MARK);
    if (!b) return strdup(src);
    const char *e = strstr(src, END_MARK);
    if (!e || e < b) return strdup(src);
    e += strlen(END_MARK);
    while (*e == '\n') e++;

    size_t head_len = (size_t)(b - src);
    size_t tail_len = strlen(e);
    char *out = malloc(head_len + tail_len + 1);
    if (!out) return NULL;
    memcpy(out, src, head_len);
    memcpy(out + head_len, e, tail_len);
    out[head_len + tail_len] = '\0';
    return out;
}

static char *build_block(void) {
    size_t cap = 1024 * 64;
    char *buf = malloc(cap);
    if (!buf) return NULL;
    size_t pos = 0;

    pos += snprintf(buf + pos, cap - pos,
                    "%s\n# Managed by DualGuard\n", BEGIN_MARK);

    for (int i = 0; kDomains[i]; i++) {
        if (pos + 256 >= cap) break;
        pos += snprintf(buf + pos, cap - pos, "0.0.0.0 %s\n", kDomains[i]);
        pos += snprintf(buf + pos, cap - pos, "0.0.0.0 www.%s\n", kDomains[i]);
    }

    pos += snprintf(buf + pos, cap - pos, "%s\n", END_MARK);
    return buf;
}

// ---------------------------------------------------------------------------

static void usage(void) {
    fprintf(stderr,
            "dghosts — DualGuard hosts helper\n"
            "usage: dghosts <command>\n"
            "  enable     apply ad-block rules\n"
            "  disable    remove ad-block rules\n"
            "  status     print current status\n"
            "  rules      print rule count\n");
}

static int cmd_status(void) {
    size_t len = 0;
    char *content = read_file(HOSTS_PATH, &len);
    if (!content) {
        printf("error cannot-read-hosts\n");
        return 1;
    }
    int active = strstr(content, BEGIN_MARK) != NULL;
    printf("%s\n", active ? "enabled" : "disabled");
    free(content);
    return 0;
}

static int cmd_rules(void) {
    size_t len = 0;
    char *content = read_file(HOSTS_PATH, &len);
    if (!content) { printf("0\n"); return 1; }
    const char *b = strstr(content, BEGIN_MARK);
    const char *e = strstr(content, END_MARK);
    int count = 0;
    if (b && e && e > b) {
        const char *p = b;
        while (p < e) {
            const char *nl = strchr(p, '\n');
            if (!nl || nl > e) break;
            if (nl > p && *p != '#') count++;
            p = nl + 1;
        }
    }
    printf("%d\n", count);
    free(content);
    return 0;
}

static int cmd_enable(void) {
    size_t len = 0;
    char *content = read_file(HOSTS_PATH, &len);
    if (!content) {
        fprintf(stderr, "cannot read %s\n", HOSTS_PATH);
        return 1;
    }

    // 备份
    if (access(BACKUP_PATH, F_OK) != 0) {
        write_file(BACKUP_PATH, content, len);
    }

    char *cleaned = strip_block(content);
    free(content);
    if (!cleaned) return 1;

    char *block = build_block();
    if (!block) { free(cleaned); return 1; }

    size_t clen = strlen(cleaned);
    size_t blen = strlen(block);
    char *next = malloc(clen + blen + 4);
    if (!next) { free(cleaned); free(block); return 1; }

    size_t pos = 0;
    memcpy(next, cleaned, clen);
    pos = clen;
    if (pos > 0 && next[pos - 1] != '\n') next[pos++] = '\n';
    next[pos++] = '\n';
    memcpy(next + pos, block, blen);
    pos += blen;

    int rc = write_file(HOSTS_PATH, next, pos);

    free(cleaned);
    free(block);
    free(next);

    if (rc != 0) {
        fprintf(stderr, "write failed: %s\n", strerror(errno));
        return 1;
    }
    printf("ok enabled\n");
    return 0;
}

static int cmd_disable(void) {
    size_t len = 0;
    char *content = read_file(HOSTS_PATH, &len);
    if (!content) {
        fprintf(stderr, "cannot read %s\n", HOSTS_PATH);
        return 1;
    }

    char *cleaned = strip_block(content);
    free(content);
    if (!cleaned) return 1;

    // 清理后为空，说明原文件只有我们的规则，写回最小可用 hosts
    if (strlen(cleaned) == 0) {
        free(cleaned);
        const char *minimal =
            "127.0.0.1\tlocalhost\n"
            "255.255.255.255\tbroadcasthost\n"
            "::1\tlocalhost\n";
        cleaned = strdup(minimal);
    }

    int rc = write_file(HOSTS_PATH, cleaned, strlen(cleaned));
    free(cleaned);

    if (rc != 0) {
        fprintf(stderr, "write failed: %s\n", strerror(errno));
        return 1;
    }
    printf("ok disabled\n");
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) { usage(); return 2; }

    const char *cmd = argv[1];

    // 安全检查：确认以 root 身份运行
    if (geteuid() != 0) {
        fprintf(stderr, "dghosts must run as root (setuid bit missing?)\n");
        return 3;
    }

    if (strcmp(cmd, "enable") == 0)  return cmd_enable();
    if (strcmp(cmd, "disable") == 0) return cmd_disable();
    if (strcmp(cmd, "status") == 0)  return cmd_status();
    if (strcmp(cmd, "rules") == 0)   return cmd_rules();

    usage();
    return 2;
}
