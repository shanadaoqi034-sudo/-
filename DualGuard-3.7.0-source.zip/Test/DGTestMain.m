//
//  DGTestMain.m — DualGuard 全功能自检
//
//  ⚠️ 仅供学习交流使用
//
//  覆盖测试：
//    T1  注入检测
//    T2  符号导出
//    T3  偏好读写
//    T4  传感器 hook
//    T5  跳转拦截
//    T6  权限
//    T7  DNS 拦截（新）
//    T8  广告跳过（新）
//    T9  设置 App 可达性（新）
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <notify.h>
#import <netdb.h>
#import <arpa/inet.h>

#define DG_PREFS_PATH  @"/var/mobile/Library/Preferences/com.deepseek.dualguard.plist"
#define DG_LOG_DIR     @"/var/mobile/Library/Logs"
#define DG_LOG_FILE    @"/var/mobile/Library/Logs/DualGuardTest.log"
#define DG_CHANGED     "com.deepseek.dualguard/changed"

#define KEY_ENABLED    @"Enabled"
#define KEY_SENSOR     @"SensorEnabled"
#define KEY_REDIRECT   @"RedirectEnabled"
#define KEY_STORE      @"BlockAppStore"
#define KEY_SAFARI     @"BlockSafari"
#define KEY_OTHERS     @"BlockOthers"
#define KEY_WEB        @"BlockWeb"
#define KEY_OTHERAPPS  @"BlockOtherApps"
#define KEY_ALLJUMPS   @"BlockAllJumps"
#define KEY_ADSKIP     @"AdSkipEnabled"
#define KEY_ADSKIP_AG  @"AdSkipAggressive"
#define KEY_DNS        @"DNSBlockEnabled"
#define KEY_SENSOR_PFX @"SensorBlocked."
#define KEY_ADSKIP_PFX @"AdSkip."

static NSMutableString *gLog = nil;
static int gPass = 0, gFail = 0, gWarn = 0;

static NSString *DGStamp(void) {
    static NSDateFormatter *fmt = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"HH:mm:ss.SSS";
    });
    return [fmt stringFromDate:[NSDate date]];
}

static void DGLog(NSString *format, ...) {
    va_list args;
    va_start(args, format);
    NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    NSString *line = [NSString stringWithFormat:@"[%@] %@\n", DGStamp(), msg];
    if (!gLog) gLog = [NSMutableString new];
    [gLog appendString:line];
    NSLog(@"[DGTest] %@", msg);
}

static void DGCheck(BOOL pass, NSString *name, NSString *detail) {
    if (pass) gPass++; else gFail++;
    DGLog(@"%@ %-22@ %@", pass ? @"✅" : @"❌", name, detail ?: @"");
}

static void DGWarn(NSString *name, NSString *detail) {
    gWarn++;
    DGLog(@"⚠️  %-22@ %@", name, detail ?: @"");
}

static NSMutableDictionary *DGReadPrefs(void) {
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:DG_PREFS_PATH];
    return [d mutableCopy] ?: [NSMutableDictionary dictionary];
}

static BOOL DGWritePrefs(NSDictionary *d) {
    BOOL ok = [d writeToFile:DG_PREFS_PATH atomically:YES];
    notify_post(DG_CHANGED);
    return ok;
}

// ---------------------------------------------------------------------------

@interface DGTestMain : UIViewController
@property (nonatomic) UITextView *textView;
@property (nonatomic) UIButton *runButton;
@end

@implementation DGTestMain

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.title = @"DualGuard 自检";

    self.textView = [[UITextView alloc] initWithFrame:CGRectZero];
    self.textView.editable = NO;
    self.textView.font = [UIFont fontWithName:@"Menlo" size:10] ?: [UIFont systemFontOfSize:10];
    self.textView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.textView];

    self.runButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.runButton setTitle:@"开始全部测试" forState:UIControlStateNormal];
    self.runButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    self.runButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.runButton addTarget:self action:@selector(runTests)
             forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.runButton];

    [NSLayoutConstraint activateConstraints:@[
        [self.runButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [self.runButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.runButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [self.runButton.heightAnchor constraintEqualToConstant:44],
        [self.textView.topAnchor constraintEqualToAnchor:self.runButton.bottomAnchor constant:8],
        [self.textView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:8],
        [self.textView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-8],
        [self.textView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
    ]];
}

- (void)runTests {
    gLog = [NSMutableString new];
    gPass = gFail = gWarn = 0;

    DGLog(@"==============================================");
    DGLog(@" DualGuard 全功能自检");
    DGLog(@"==============================================");
    DGLog(@"设备: %@ / iOS %@", UIDevice.currentDevice.model, UIDevice.currentDevice.systemVersion);
    DGLog(@"进程: %@", NSBundle.mainBundle.bundleIdentifier);
    DGLog(@"");

    [self t1_injection];
    [self t2_symbols];
    [self t3_prefs];
    [self t4_sensor];
    [self t5_redirect];
    [self t6_entitlements];
    [self t7_dns];
    [self t8_adskip];
    [self t9_settingsApp];

    DGLog(@"");
    DGLog(@"==============================================");
    DGLog(@" 汇总: 通过 %d   失败 %d   警告 %d", gPass, gFail, gWarn);
    DGLog(@"==============================================");

    [self writeLog];
    [self showResults];
}

// ---- T1 ---------------------------------------------------------------

- (void)t1_injection {
    DGLog(@"---- T1 注入 ----");
    BOOL found = NO;
    NSString *path = nil;
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *n = _dyld_get_image_name(i);
        if (n && strstr(n, "DualGuard.dylib")) {
            found = YES;
            path = [NSString stringWithUTF8String:n];
            break;
        }
    }
    DGCheck(found, @"dylib 已注入", path.lastPathComponent ?: @"未找到");
    if (!found) DGLog(@"  ⚠️ 后续 hook 测试都会失败，先解决注入问题");
}

// ---- T2 ---------------------------------------------------------------

- (void)t2_symbols {
    DGLog(@"");
    DGLog(@"---- T2 符号 ----");
    const char *syms[] = {
        "DGPreferences", "DGRedirectShouldBlock", "DGAdBlockInstall",
        "DGAdBlockIsAdDomain", "DGAdSkipStart", "DGSensorBlockedForCurrentProcess",
        NULL
    };
    int found = 0, total = 0;
    for (int i = 0; syms[i]; i++) {
        total++;
        if (dlsym(RTLD_DEFAULT, syms[i])) found++;
    }
    if (found == total) {
        DGCheck(YES, @"全部符号可解析", [NSString stringWithFormat:@"%d/%d", found, total]);
    } else {
        DGWarn(@"符号可见性", [NSString stringWithFormat:@"%d/%d（RTLD_LOCAL 下不可见属正常）", found, total]);
    }
}

// ---- T3 ---------------------------------------------------------------

- (void)t3_prefs {
    DGLog(@"");
    DGLog(@"---- T3 偏好 ----");
    NSDictionary *prefs = DGReadPrefs();
    DGLog(@"  当前 %lu 项", (unsigned long)prefs.count);

    NSMutableDictionary *p = [prefs mutableCopy];
    p[@"__DGProbe"] = @([[NSDate date] timeIntervalSince1970]);
    BOOL wrote = DGWritePrefs(p);
    DGCheck(wrote, @"偏好可写", wrote ? @"OK" : @"失败");

    if (wrote) {
        BOOL ok = DGReadPrefs()[@"__DGProbe"] != nil;
        DGCheck(ok, @"写入可回读", ok ? @"一致" : @"读不回");
        NSMutableDictionary *c = DGReadPrefs();
        [c removeObjectForKey:@"__DGProbe"];
        DGWritePrefs(c);
    }
}

// ---- T4 ---------------------------------------------------------------

- (void)t4_sensor {
    DGLog(@"");
    DGLog(@"---- T4 传感器 ----");

    CMMotionManager *m = [[CMMotionManager alloc] init];
    NSString *key = [KEY_SENSOR_PFX stringByAppendingString:NSBundle.mainBundle.bundleIdentifier];

    // 诊断 hook
    Class cls = objc_getClass("CMMotionManager");
    if (cls) {
        Method meth = class_getInstanceMethod(cls, sel_registerName("isAccelerometerAvailable"));
        if (meth) {
            IMP imp = method_getImplementation(meth);
            void *hookFn = dlsym(RTLD_DEFAULT, "DGHookedAccelAvailable");
            DGLog(@"  IMP=%p hookFn=%p %@", (void *)imp, hookFn,
                  (hookFn && imp == (IMP)hookFn) ? @"已替换" : @"未替换/不可见");
        }
    }

    // 未封锁
    NSMutableDictionary *p = DGReadPrefs();
    [p removeObjectForKey:key];
    p[KEY_ENABLED] = @YES;
    p[KEY_SENSOR] = @YES;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.3];

    BOOL before = m.isAccelerometerAvailable;
    DGLog(@"  未封锁: available=%@", before ? @"YES" : @"NO");
    DGCheck(before, @"未封锁时可用", nil);

    // 封锁
    p = DGReadPrefs();
    p[key] = @YES;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.3];

    BOOL after = m.isAccelerometerAvailable;
    DGLog(@"  已封锁: available=%@ data=%@", after ? @"YES" : @"NO",
          m.accelerometerData ? @"非nil" : @"nil");
    DGCheck(!after, @"封锁后不可用", after ? @"仍 YES" : @"已拦");
    DGCheck(m.accelerometerData == nil, @"封锁后无数据", nil);

    // 解封
    p = DGReadPrefs();
    [p removeObjectForKey:key];
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.3];
    DGCheck(m.isAccelerometerAvailable, @"解封后恢复", nil);
}

// ---- T5 ---------------------------------------------------------------

- (void)t5_redirect {
    DGLog(@"");
    DGLog(@"---- T5 跳转拦截 ----");
    UIApplication *app = UIApplication.sharedApplication;

    // 确认 hook 类存在
    const char *classes[] = {
        "SFSafariViewController", "ASWebAuthenticationSession",
        "SKStoreProductViewController", NULL
    };
    for (int i = 0; classes[i]; i++) {
        Class c = objc_getClass(classes[i]);
        DGLog(@"  类 %s: %@", classes[i], c ? @"存在" : @"未加载");
    }

    // App Store 拦截
    NSMutableDictionary *p = DGReadPrefs();
    p[KEY_ENABLED] = @YES;
    p[KEY_REDIRECT] = @YES;
    p[KEY_STORE] = @YES;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.3];

    NSURL *storeURL = [NSURL URLWithString:@"itms-apps://itunes.apple.com/app/id123"];
    BOOL blocked = ![app canOpenURL:storeURL];
    DGLog(@"  拦截开: canOpenURL(itms-apps)=%@", blocked ? @"NO(已拦)" : @"YES(未拦)");
    DGCheck(blocked, @"App Store 链接被拦", nil);

    // 关闭后
    p = DGReadPrefs();
    p[KEY_STORE] = @NO;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.3];

    BOOL allowed = [app canOpenURL:storeURL];
    if (allowed) {
        DGCheck(YES, @"关闭后放行", @"恢复");
    } else {
        DGWarn(@"关闭后放行", @"仍 NO，可能是系统限制而非 hook");
    }

    // 还原
    p = DGReadPrefs();
    p[KEY_STORE] = @YES;
    DGWritePrefs(p);
}

// ---- T6 ---------------------------------------------------------------

- (void)t6_entitlements {
    DGLog(@"");
    DGLog(@"---- T6 权限 ----");
    [[NSFileManager defaultManager] createDirectoryAtPath:DG_LOG_DIR
                              withIntermediateDirectories:YES attributes:nil error:NULL];
    NSString *probe = [DG_LOG_DIR stringByAppendingPathComponent:@".probe"];
    BOOL w = [[NSFileManager defaultManager]
              createFileAtPath:probe
                      contents:[@"x" dataUsingEncoding:NSUTF8StringEncoding]
                    attributes:nil];
    if (w) [[NSFileManager defaultManager] removeItemAtPath:probe error:NULL];
    DGCheck(w, @"沙盒外可写", w ? @"entitlements 生效" : @"no-sandbox 未生效");
    DGLog(@"  uid=%d euid=%d", getuid(), geteuid());
}

// ---- T7: DNS -----------------------------------------------------------

- (void)t7_dns {
    DGLog(@"");
    DGLog(@"---- T7 DNS 拦截 ----");

    // 检查 DGAdBlock 符号
    typedef BOOL (*IsAdFn)(const char *);
    typedef NSUInteger (*CountFn)(void);

    IsAdFn isAd = (IsAdFn)dlsym(RTLD_DEFAULT, "DGAdBlockIsAdDomain");
    CountFn ruleCount = (CountFn)dlsym(RTLD_DEFAULT, "DGAdBlockRuleCount");

    if (!isAd || !ruleCount) {
        DGWarn(@"DGAdBlock 符号", @"不可见（RTLD_LOCAL），改用行为测试");
    } else {
        NSUInteger n = ruleCount();
        DGLog(@"  规则数量: %lu", (unsigned long)n);
        DGCheck(n > 50, @"规则已加载", [NSString stringWithFormat:@"%lu 条", (unsigned long)n]);

        // 测试判定逻辑
        BOOL hit1 = isAd("doubleclick.net");
        BOOL hit2 = isAd("sub.doubleclick.net");
        BOOL miss = isAd("www.apple.com");
        DGLog(@"  doubleclick.net=%d sub.doubleclick.net=%d apple.com=%d", hit1, hit2, miss);
        DGCheck(hit1 && hit2 && !miss, @"域名匹配逻辑", nil);
    }

    // 行为测试：开启 DNS 后解析广告域名
    NSMutableDictionary *p = DGReadPrefs();
    p[KEY_ENABLED] = @YES;
    p[KEY_DNS] = @YES;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.4];

    struct addrinfo hints = {0};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo *res = NULL;

    int rc = getaddrinfo("doubleclick.net", "80", &hints, &res);
    BOOL intercepted = NO;
    if (rc == 0 && res) {
        struct sockaddr_in *sin = (struct sockaddr_in *)res->ai_addr;
        if (sin && sin->sin_addr.s_addr == htonl(INADDR_ANY)) {
            intercepted = YES;
        }
        freeaddrinfo(res);
    }
    DGLog(@"  getaddrinfo(doubleclick.net) rc=%d -> %@",
          rc, intercepted ? @"0.0.0.0 (已拦截)" : @"未拦截");
    DGCheck(intercepted, @"DNS 实际拦截生效",
            intercepted ? nil : @"返回了真实地址，hook 未生效或需重启 App");

    // 正常域名应能解析
    res = NULL;
    rc = getaddrinfo("www.apple.com", "80", &hints, &res);
    if (res) freeaddrinfo(res);
    DGLog(@"  getaddrinfo(www.apple.com) rc=%d（应为 0 或非 0 但非 0.0.0.0）", rc);
    DGCheck(rc == 0, @"正常域名不受影响", rc == 0 ? @"可解析" : @"解析失败（可能网络问题）");
}

// ---- T8: 广告跳过 -----------------------------------------------------

- (void)t8_adskip {
    DGLog(@"");
    DGLog(@"---- T8 广告跳过 ----");

    typedef void (*StartFn)(void);
    typedef NSUInteger (*ScanFn)(void);

    StartFn start = (StartFn)dlsym(RTLD_DEFAULT, "DGAdSkipStart");
    ScanFn scan = (ScanFn)dlsym(RTLD_DEFAULT, "DGAdSkipScanOnce");

    if (!start || !scan) {
        DGWarn(@"DGAdSkip 符号", @"不可见");
    } else {
        DGCheck(YES, @"DGAdSkip 符号可解析", nil);
    }

    // 开启本 App 的跳过
    NSMutableDictionary *p = DGReadPrefs();
    p[KEY_ENABLED] = @YES;
    p[KEY_ADSKIP] = @YES;
    p[[KEY_ADSKIP_PFX stringByAppendingString:NSBundle.mainBundle.bundleIdentifier]] = @YES;
    DGWritePrefs(p);
    [NSThread sleepForTimeInterval:0.4];

    if (scan) {
        NSUInteger n = scan();
        DGLog(@"  当前界面扫描到 %lu 个可点按钮", (unsigned long)n);
        DGCheck(YES, @"扫描可执行", [NSString stringWithFormat:@"%lu 个", (unsigned long)n]);
    }

    // 造一个假的「跳过」按钮，验证识别
    UIWindow *win = UIApplication.sharedApplication.windows.firstObject;
    if (win) {
        UIButton *fake = [UIButton buttonWithType:UIButtonTypeCustom];
        [fake setTitle:@"跳过" forState:UIControlStateNormal];
        fake.frame = CGRectMake(win.bounds.size.width - 100, 60, 80, 30);
        fake.backgroundColor = UIColor.systemRedColor;
        [fake setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        [win addSubview:fake];

        [NSThread sleepForTimeInterval:0.2];
        if (scan) {
            NSUInteger n2 = scan();
            DGLog(@"  加入假按钮后扫描 %lu 个", (unsigned long)n2);
            DGCheck(YES, @"假按钮可被扫描", [NSString stringWithFormat:@"%lu 个", (unsigned long)n2]);
        }
        [fake removeFromSuperview];
    }

    // 还原
    p = DGReadPrefs();
    [p removeObjectForKey:[KEY_ADSKIP_PFX stringByAppendingString:NSBundle.mainBundle.bundleIdentifier]];
    DGWritePrefs(p);
}

// ---- T9: 设置 App -----------------------------------------------------

- (void)t9_settingsApp {
    DGLog(@"");
    DGLog(@"---- T9 设置 App ----");

    NSString *candidates[] = {
        @"/var/jb/Applications/DualGuardSettings.app",
        @"/private/preboot/Cryptexes/OS/var/jb/Applications/DualGuardSettings.app",
    };
    BOOL found = NO;
    for (int i = 0; i < 2; i++) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:candidates[i]]) {
            found = YES;
            DGLog(@"  路径: %@", candidates[i]);
            break;
        }
    }
    if (!found) {
        // 用 LSApplicationWorkspace 查
        Class ws = NSClassFromString(@"LSApplicationWorkspace");
        if (ws) {
            id w = ((id(*)(id,SEL))objc_msgSend)(ws, sel_registerName("defaultWorkspace"));
            if ([w respondsToSelector:sel_registerName("applicationProxyForIdentifier:")]) {
                id proxy = ((id(*)(id,SEL,id))objc_msgSend)(w,
                    sel_registerName("applicationProxyForIdentifier:"),
                    @"com.deepseek.dualguard.settings");
                found = proxy != nil;
            }
        }
    }
    DGCheck(found, @"设置 App 已安装", found ? @"找到" : @"未找到，请重装");

    // helper
    NSArray *helperPaths = @[
        @"/var/jb/usr/libexec/dghosts",
        @"/private/preboot/Cryptexes/OS/var/jb/usr/libexec/dghosts",
    ];
    BOOL helperFound = NO;
    for (NSString *hp in helperPaths) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:hp]) {
            helperFound = YES;
            NSDictionary *attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:hp error:NULL];
            unsigned short mode = [attrs[NSFilePosixPermissions] unsignedShortValue];
            DGLog(@"  helper: %@ 权限=%04o setuid=%@", hp, mode, (mode & 04000) ? @"是" : @"否");
            break;
        }
    }
    DGWarn(@"helper 存在", helperFound ? @"已安装（hosts 方案已废弃，仅保留）" : @"未安装");
}

// ---- 输出 -------------------------------------------------------------

- (void)writeLog {
    [[NSFileManager defaultManager] createDirectoryAtPath:DG_LOG_DIR
                              withIntermediateDirectories:YES attributes:nil error:NULL];
    NSError *e = nil;
    if ([gLog writeToFile:DG_LOG_FILE atomically:YES
                 encoding:NSUTF8StringEncoding error:&e]) {
        DGLog(@"日志: %@", DG_LOG_FILE);
    } else {
        DGLog(@"日志写入失败: %@", e.localizedDescription);
    }
}

- (void)showResults {
    NSString *text = gLog ?: @"";
    NSMutableAttributedString *attr =
        [[NSMutableAttributedString alloc] initWithString:text];
    [attr addAttribute:NSFontAttributeName
                 value:[UIFont fontWithName:@"Menlo" size:9] ?: [UIFont systemFontOfSize:9]
                 range:NSMakeRange(0, attr.length)];

    [text enumerateSubstringsInRange:NSMakeRange(0, text.length)
                             options:NSStringEnumerationByLines
                          usingBlock:^(NSString *sub, NSRange r, NSRange er, BOOL *stop) {
        UIColor *c = nil;
        if ([sub containsString:@"❌"]) c = UIColor.systemRedColor;
        else if ([sub containsString:@"⚠️"]) c = UIColor.systemOrangeColor;
        else if ([sub containsString:@"✅"]) c = UIColor.systemGreenColor;
        if (c) [attr addAttribute:NSForegroundColorAttributeName value:c range:r];
    }];

    self.textView.attributedText = attr;
    [self.textView scrollRangeToVisible:NSMakeRange(0, 1)];
    [self.runButton setTitle:[NSString stringWithFormat:@"重测（通过 %d / 失败 %d）", gPass, gFail]
                    forState:UIControlStateNormal];
}

@end

// ---------------------------------------------------------------------------

@interface DGTestAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic) UIWindow *window;
@end

@implementation DGTestAppDelegate
- (BOOL)application:(UIApplication *)app
didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    DGTestMain *root = [[DGTestMain alloc] init];
    self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:root];
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(DGTestAppDelegate.class));
    }
}
