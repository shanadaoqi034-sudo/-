//
//  DGAdSkip.h — 广告自动跳过模块
//
//  设计目标：识别「跳过」按钮并自动点击，误点率尽量低。
//
//  三层识别（从严格到宽松）：
//    L1 文本精确匹配    "跳过" "Skip" "跳过广告" "Skip Ad" "关闭" "Close" "×"
//    L2 倒计时模式      "5s" "5秒" "3" "05" —— 广告跳过按钮常显示倒计时
//    L3 位置+尺寸启发   右上角、小尺寸、可点击的按钮
//
//  安全阀（防止误点）：
//    * 只处理「疑似广告容器」里的按钮，不在整个视图树乱点
//    * 同一按钮 3 秒内不重复点
//    * 忽略包含长文本的按钮（正常功能按钮文字通常较长）
//    * 忽略 UIAlertController / 系统弹窗
//    * 每个 App 有独立的开关
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// 启动广告监控（幂等）
FOUNDATION_EXPORT void DGAdSkipStart(void);

// 停止监控
FOUNDATION_EXPORT void DGAdSkipStop(void);

// 当前进程是否启用广告跳过
FOUNDATION_EXPORT BOOL DGAdSkipEnabledForCurrentProcess(void);

// 手动扫一次（调试用）
FOUNDATION_EXPORT NSUInteger DGAdSkipScanOnce(void);

// 最近跳过记录（调试用）
FOUNDATION_EXPORT NSArray<NSString *> *DGAdSkipRecentLog(void);
