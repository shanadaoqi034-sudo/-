//
//  DGSensor.m — 传感器屏蔽的状态与策略层
//
//

#import "DGSensor.h"
#import "DGCore.h"
#import "DGPerApp.h"
#import "DGLog.h"
#import <objc/runtime.h>
#import <stdatomic.h>

@implementation DGStream
@end

static NSHashTable *gManagers = nil;
static char kAccelerometerKey;
static char kMotionKey;
static __thread BOOL tRevoking = NO;
static __thread NSUInteger tForwardingDepth = 0;
static atomic_bool gLoggedFirstBlock = false;

void DGSensorSetup(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gManagers = [NSHashTable weakObjectsHashTable];
    });
}

BOOL DGSensorBlockedForCurrentProcess(void) {
    // ---- 诊断：每个分支都打印前几次，方便定位「为什么没生效」----
    //
    // 原实现只在「走到最后一步」时才打印判定链，
    // 如果前面任何一道闸返回 NO，用户看不到任何日志，
    // 只能感觉到「功能没效果」却无从排查。
    static atomic_int logCount = 0;
    int n = atomic_fetch_add(&logCount, 1);
    BOOL shouldLog = (n < 5);   // 前 5 次全打，之后静默

    BOOL masterOn = DGEnabled();
    if (!masterOn) {
        if (shouldLog) {
            NSLog(@"[DualGuard][Sensor] 判定中止：总开关关闭 (master=NO)");
        }
        return NO;
    }

    BOOL sensorOn = DGBool(DGKeySensorEnabled, YES);
    if (!sensorOn) {
        if (shouldLog) {
            NSLog(@"[DualGuard][Sensor] 判定中止：传感器模块关闭 (sensor=NO)");
        }
        return NO;
    }

    NSString *bid = DGBundleIdentifier();

    // 三层判定：全局 SensorEnabled → App master → App 的 sensor 键
    BOOL globalSensor = YES;   // 已在上面的闸里检查过
    BOOL blocked = DGPerAppFeatureOn(DGFeatureSensor, bid, globalSensor);

    if (shouldLog) {
        NSLog(@"[DualGuard][Sensor] 判定链: master=YES sensor=YES bid=%@", bid);
        NSLog(@"[DualGuard][Sensor]   查询键: %@ -> %@",
              DGPerAppKey(DGFeatureSensor, bid),
              blocked ? @"YES(屏蔽)" : @"NO(放行)");
        if (!blocked) {
            NSLog(@"[DualGuard][Sensor]   ⚠️ 该 App 未开启传感器屏蔽。"
                  @"请在设置 > App 配置 > 找到 %@ > 打开「传感器屏蔽」", bid);
        }
    }
    return blocked;
}

// ===========================================================================
//  按传感器类型分别判定（3.6.0）
// ===========================================================================
//
//  优先级：总闸 → 该传感器分项
//    总闸关（全局 SensorEnabled 或该 App 的 sensor 键）→ 全部放行
//    总闸开 → 看分项；分项没设过就跟随总闸（= 屏蔽）

NSString *DGSensorFeatureForKind(DGSensorKind kind) {
    switch (kind) {
        case DGSensorKindAccelerometer: return DGFeatureSensorAccel;
        case DGSensorKindGyro:          return DGFeatureSensorGyro;
        case DGSensorKindMagnetometer:  return DGFeatureSensorMag;
        case DGSensorKindDeviceMotion:  return DGFeatureSensorMotion;
        case DGSensorKindCompass:       return DGFeatureSensorCompass;
        case DGSensorKindLocation:      return DGFeatureSensorLocation;
    }
    return DGFeatureSensorAccel;
}

NSString *DGSensorNameForKind(DGSensorKind kind) {
    switch (kind) {
        case DGSensorKindAccelerometer: return @"加速度计";
        case DGSensorKindGyro:          return @"陀螺仪";
        case DGSensorKindMagnetometer:  return @"磁力计";
        case DGSensorKindDeviceMotion:  return @"设备姿态";
        case DGSensorKindCompass:       return @"指南针";
        case DGSensorKindLocation:      return @"定位";
    }
    return @"未知传感器";
}

// 该传感器的全局分项键（设置 App 主页那 6 个开关）
static NSString *DGSensorGlobalKeyForKind(DGSensorKind kind) {
    switch (kind) {
        case DGSensorKindAccelerometer: return DGKeySensorAccel;
        case DGSensorKindGyro:          return DGKeySensorGyro;
        case DGSensorKindMagnetometer:  return DGKeySensorMag;
        case DGSensorKindDeviceMotion:  return DGKeySensorMotion;
        case DGSensorKindCompass:       return DGKeySensorCompass;
        case DGSensorKindLocation:      return DGKeySensorLocation;
    }
    return DGKeySensorAccel;
}

BOOL DGSensorBlockedKind(DGSensorKind kind) {
    // ---- 第一层：总闸 ----
    //  总闸 = 全局 SensorEnabled + 该 App 的 sensor 键
    if (!DGSensorBlockedForCurrentProcess()) return NO;

    NSString *bid = DGBundleIdentifier();

    // ---- 第二层：全局分项（设置主页那 6 个开关）----
    NSString *globalKey = DGSensorGlobalKeyForKind(kind);
    BOOL globalOn = DGBool(globalKey, YES);
    if (!globalOn) {
        return NO;
    }

    // ---- 第三层：该 App 的分项 ----
    //  没设过 → 继承全局（= 开）
    NSString *feature = DGSensorFeatureForKind(kind);
    BOOL on = DGPerAppBool(feature, bid, YES);

    static atomic_int logCount = 0;
    int n = atomic_fetch_add(&logCount, 1);
    if (n < 12) {
        DGLog(@"传感器", @"%@ 全局=%@ App键=%@ → %@ (bid=%@)",
              DGSensorNameForKind(kind),
              globalOn ? @"开" : @"关",
              feature,
              on ? @"屏蔽" : @"放行", bid);
    }
    return on;
}

void DGSensorNoteBlocked(void) {
    if (atomic_exchange(&gLoggedFirstBlock, true)) return;
    NSLog(@"[DualGuard] Blocked CoreMotion request from %@", DGBundleIdentifier());
}

BOOL DGSensorIsForwarding(void)          { return tForwardingDepth > 0; }
void DGSensorEnterForwarding(void)       { tForwardingDepth++; }
void DGSensorLeaveForwarding(void)       { if (tForwardingDepth) tForwardingDepth--; }
BOOL DGSensorIsRevoking(void)            { return tRevoking; }
void DGSensorSetRevoking(BOOL revoking)  { tRevoking = revoking; }

DGStream *DGSensorStreamFor(CMMotionManager *manager, BOOL motion) {
    if (!manager) return nil;
    const void *key = motion ? &kMotionKey : &kAccelerometerKey;
    DGStream *stream = objc_getAssociatedObject(manager, key);
    if (!stream) {
        stream = [DGStream new];
        objc_setAssociatedObject(manager, key, stream, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        @synchronized (gManagers) { [gManagers addObject:manager]; }
    }
    return stream;
}

void DGSensorPolicyChanged(void) {
    DGSensorSetup();
    NSArray *snapshot = nil;
    @synchronized (gManagers) { snapshot = gManagers.allObjects; }
    for (CMMotionManager *manager in snapshot) {
        @synchronized (manager) {
            for (NSNumber *kind in @[@NO, @YES]) {
                BOOL motion = kind.boolValue;
                DGStream *stream = DGSensorStreamFor(manager, motion);
                if (!stream) continue;
                @try {
                    if (!DGSensorBlockedForCurrentProcess()) {
                        // 解禁：恢复之前被拦下的流
                        if (!stream.active && stream.resume) stream.resume();
                    } else if (stream.active) {
                        // 封锁：主动停流
                        DGSensorSetRevoking(YES);
                        if (motion) [manager stopDeviceMotionUpdates];
                        else [manager stopAccelerometerUpdates];
                        DGSensorSetRevoking(NO);
                    }
                } @catch (NSException *exception) {
                    DGSensorSetRevoking(NO);
                    NSLog(@"[DualGuard] policy update failed for %@: %@",
                          DGBundleIdentifier(), exception);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 摇一摇拦截
// ---------------------------------------------------------------------------
//
//  摇一摇广告是 iOS 上最常见的误触型广告：用户拿手机稍微晃动就跳到 App Store。
//  它不走 openURL，走的是 UIResponder 的 motionEnded:withEvent:。
//
//  策略：只拦 App 启动后的前 N 秒（默认 15 秒）。
//  理由：摇一摇广告几乎都在启动/切前台时触发；
//  之后放行可以保留「摇一摇撤销输入」这类正常功能。

static NSTimeInterval gLaunchTime = 0;

void DGShakeMarkLaunch(void) {
    gLaunchTime = [NSDate timeIntervalSinceReferenceDate];
}

BOOL DGShakeBlockEnabled(void) {
    if (!DGEnabled()) return NO;
    if (!DGBool(DGKeySensorEnabled, YES)) return NO;
    return DGBool(DGKeyShakeBlock, YES);
}

NSTimeInterval DGShakeBlockWindow(void) {
    id v = DGPreferences()[DGKeyShakeWindow];
    if (v) {
        double d = [v doubleValue];
        if (d > 0 && d <= 120) return d;
    }
    return 15.0;   // 默认 15 秒
}

BOOL DGSensorShouldBlockShake(void) {
    if (!DGShakeBlockEnabled()) return NO;

    // 该 App 的摇一摇开关（三层优先级）
    NSString *bid = DGBundleIdentifier();
    if (!DGPerAppFeatureOn(DGFeatureShake, bid, YES)) return NO;

    if (gLaunchTime <= 0) {
        // %ctor 没跑到（不该发生），保守起见按启动时刻算
        gLaunchTime = [NSDate timeIntervalSinceReferenceDate];
    }

    NSTimeInterval elapsed = [NSDate timeIntervalSinceReferenceDate] - gLaunchTime;
    BOOL within = elapsed < DGShakeBlockWindow();

    if (within) {
        static atomic_bool logged = false;
        if (!atomic_exchange(&logged, true)) {
            NSLog(@"[DualGuard] 摇一摇拦截生效 for %@（启动后 %.1fs 内，窗口 %.0fs）",
                  bid, elapsed, DGShakeBlockWindow());
        }
    }
    return within;
}
