//
//  DGHelper.h — 调用 setuid root helper
//

#import <Foundation/Foundation.h>

// helper 路径（rootless 下自动解析 jbroot）
FOUNDATION_EXPORT NSString *DGHelperPath(void);

// helper 是否可用（存在 + 可执行 + setuid 位）
FOUNDATION_EXPORT BOOL DGHelperAvailable(void);

// 执行 helper 命令，返回 stdout（失败返回 nil）
FOUNDATION_EXPORT NSString *DGHelperRun(NSString *command, int *exitCode);

// 诊断信息（给 UI 显示）
FOUNDATION_EXPORT NSString *DGHelperDiagnostics(void);
