//
//  DGAppConfigPage.m — 单个 App 的全功能配置页
//
//  ==========================================================================
//   设计
//  ==========================================================================
//
//  从「App 列表」点进某个 App，进入这一页，能看到这个 App 的**所有**功能开关：
//
//    总开关
//    ├─ 管辖此 App（关掉 = 这个 App 完全不受 DualGuard 影响）
//    │
//    ├─ 广告
//    │   ├─ DNS 广告拦截
//    │   └─ 广告自动跳过
//    │
//    ├─ 传感器
//    │   ├─ 传感器屏蔽
//    │   └─ 摇一摇拦截
//    │
//    └─ 跳转拦截
//        ├─ 跳转拦截（总）
//        ├─ 拦截 App Store
//        ├─ 拦截 Safari
//        ├─ 拦截其他浏览器
//        ├─ 拦截网页
//        ├─ 拦截其他 App
//        └─ 拦截所有外部跳转
//
//  每一项都是三态：继承全局 / 强制开 / 强制关。
//  点一下开关在「继承」和「反向」之间切换；长按或点右侧按钮清除覆盖。
//
//  简化实现：开关直接表示「这个 App 是否启用此功能」，
//  初始值 = 全局值。改了就是覆盖，有「恢复继承」按钮清除所有覆盖。
//

#import <UIKit/UIKit.h>

@class DGAppConfigPage;

@protocol DGAppConfigPageDelegate <NSObject>
- (void)appConfigPageDidChange:(DGAppConfigPage *)page;
@end

@interface DGAppConfigPage : UIViewController

- (instancetype)initWithBundleID:(NSString *)bundleID
                       appName:(NSString *)appName;

@property (nonatomic, weak) id<DGAppConfigPageDelegate> delegate;

@end
