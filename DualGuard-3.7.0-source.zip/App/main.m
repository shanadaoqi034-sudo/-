//
//  main.m — DualGuard 设置 App
//

#import <UIKit/UIKit.h>
#import "DGAppDelegate.h"
#import "DGLog.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        DGLogInit(@"DualGuardSettings");
        DGLog(@"main", @"进入 main()");

        Class cls = NSClassFromString(@"DGAppDelegate");
        DGLog(@"main", @"DGAppDelegate 类 %@", cls ? @"找到" : @"未找到");

        int rc = UIApplicationMain(argc, argv, nil, @"DGAppDelegate");
        DGLog(@"main", @"UIApplicationMain 返回 %d", rc);
        return rc;
    }
}
