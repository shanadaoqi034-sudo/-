//
//  DGLog.m — 统一诊断日志实现
//

#import "DGLog.h"
#import <sys/stat.h>
#import <pthread.h>

NSString * const DGLogDirectory = @"/rootfs/private/var/mobile/Documents/test";

static NSString *gLogPrefix = @"DualGuard";
static NSString *gLogPath = nil;
static NSLock *gLogLock = nil;
static dispatch_once_t gLogOnce;

static void DGLogSetup(void) {
    dispatch_once(&gLogOnce, ^{
        gLogLock = [NSLock new];
        gLogPath = [DGLogDirectory stringByAppendingPathComponent:
                    @"DualGuard.log"];
    });
}

// 确保目录存在
static BOOL DGLogEnsureDirectory(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL isDir = NO;
    if ([fm fileExistsAtPath:DGLogDirectory isDirectory:&isDir] && isDir) {
        return YES;
    }
    // 目录不存在就建（带中间目录）
    NSError *err = nil;
    BOOL ok = [fm createDirectoryAtPath:DGLogDirectory
            withIntermediateDirectories:YES
                             attributes:nil
                                  error:&err];
    if (!ok) {
        NSLog(@"[DGLog] 无法创建日志目录 %@: %@", DGLogDirectory, err);
    }
    return ok;
}

void DGLogInit(NSString *prefix) {
    DGLogSetup();
    if ([prefix isKindOfClass:[NSString class]] && prefix.length) {
        gLogPrefix = [prefix copy];
    }

    DGLogEnsureDirectory();

    // 写一条分隔，标记新进程启动
    DGLog(@"INIT", @"===== %@ 进程启动 pid=%d =====",
          NSProcessInfo.processInfo.processName,
          (int)NSProcessInfo.processInfo.processIdentifier);
}

void DGLog(NSString *module, NSString *format, ...) {
    DGLogSetup();

    if (![format isKindOfClass:[NSString class]]) return;
    if (![module isKindOfClass:[NSString class]]) module = @"?";

    va_list args;
    va_start(args, format);
    NSString *body = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    if (!body) body = @"(格式化失败)";

    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"HH:mm:ss.SSS";
    NSString *ts = [df stringFromDate:[NSDate date]];

    NSString *line = [NSString stringWithFormat:@"[%@] [%@] [%@] %@\n",
                      ts, gLogPrefix, module, body];

    // 同时输出到系统日志（有 log 工具时能看到）
    NSLog(@"[%@][%@] %@", gLogPrefix, module, body);

    if (!gLogLock) return;
    [gLogLock lock];

    DGLogEnsureDirectory();

    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:gLogPath]) {
        [line writeToFile:gLogPath atomically:YES
                 encoding:NSUTF8StringEncoding error:NULL];
        // 建完文件后放开写权限，方便用户在 Filza 里看
        chmod(gLogPath.fileSystemRepresentation, 0644);
    } else {
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:gLogPath];
        if (fh) {
            @try {
                [fh seekToEndOfFile];
                [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [fh closeFile];
            } @catch (NSException *e) {
                NSLog(@"[DGLog] 写日志失败: %@", e);
            }
        }
    }

    [gLogLock unlock];
}

void DGLogFlush(void) {
    // 每行都是立即写盘的，这里只做一个空操作保持接口完整
}

void DGLogClear(void) {
    DGLogSetup();
    if (!gLogLock) return;
    [gLogLock lock];
    [[NSFileManager defaultManager] removeItemAtPath:gLogPath error:NULL];
    [gLogLock unlock];
}
