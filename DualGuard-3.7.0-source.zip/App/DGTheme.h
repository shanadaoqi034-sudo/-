//
//  DGTheme.h — 二次元风格主题 + 屏幕适配
//
//  目标设备：iPhone 15 Pro (iPhone16,1)
//    物理分辨率 1179 × 2556 px
//    逻辑分辨率 393 × 852 pt @3x
//    灵动岛机型，安全区顶部 59pt / 底部 34pt
//
//  设计原则：
//    * 所有尺寸从屏幕宽度推导，不写死像素
//    * 用 safeAreaInsets 处理刘海/灵动岛
//    * 支持任意宽度（393 是基准，其他尺寸按比例缩放）
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DGTheme : NSObject

// ===========================================================================
//  屏幕适配
// ===========================================================================

// 基准设计宽度（iPhone 15 Pro）
+ (CGFloat)designWidth;              // 393

// 当前屏幕逻辑宽度
+ (CGFloat)screenWidth;
+ (CGFloat)screenHeight;

// 缩放系数：当前宽度 / 393。
// 393 上返回 1.0，375（iPhone SE/13 mini）上约 0.954，430（Pro Max）上约 1.094
+ (CGFloat)scale;

// 按基准值缩放后的尺寸（带上下限，避免极端屏幕过小/过大）
+ (CGFloat)scaled:(CGFloat)value;

// 常用间距（已适配）
+ (CGFloat)contentMargin;            // 卡片左右外边距 16 * scale
+ (CGFloat)cardCornerRadius;         // 18 * scale
+ (CGFloat)cardInnerPadding;         // 卡片内左右留白 16
+ (CGFloat)rowMinHeight;             // 行最小高度 52
+ (CGFloat)sectionSpacing;           // 分组之间间距 24
+ (CGFloat)sectionHeaderHeight;      // 分组标题高度 44

// ===========================================================================
//  颜色
// ===========================================================================

+ (UIColor *)primaryPink;            // #FF7EB3
+ (UIColor *)primaryBlue;            // #7EC8FF
+ (UIColor *)accentCyan;             // #5CE1E6
+ (UIColor *)accentPurple;           // #B48EFF
+ (UIColor *)accentYellow;           // #FFD166

+ (UIColor *)backgroundDark;         // #1A1A2E
+ (UIColor *)backgroundLight;        // #FFF5F9
+ (UIColor *)cardDark;               // #252540
+ (UIColor *)cardLight;              // #FFFFFF

+ (UIColor *)textPrimary;
+ (UIColor *)textSecondary;
+ (UIColor *)textTertiary;

+ (UIColor *)background;
+ (UIColor *)cardBackground;

// 渐变（樱粉 → 淡紫 → 天蓝）
+ (CAGradientLayer *)mainGradientLayer;

// ===========================================================================
//  字体（圆体，中文走苹方圆）
// ===========================================================================

+ (UIFont *)roundedFontOfSize:(CGFloat)size weight:(UIFontWeight)weight;

+ (UIFont *)fontHeroTitle;           // 32 bold
+ (UIFont *)fontSectionTitle;        // 17 semibold
+ (UIFont *)fontRowLabel;            // 15 regular
+ (UIFont *)fontFooter;              // 13 regular
+ (UIFont *)fontBadge;               // 12 semibold
+ (UIFont *)fontNumber;              // 等宽数字

// ===========================================================================
//  装饰
// ===========================================================================

+ (void)applyCardStyleToView:(UIView *)view;

// 给内容视图套一个负责阴影的外层容器（圆角在内容层，阴影在容器层）
+ (UIView *)wrapCardForShadow:(UIView *)content;

@end

NS_ASSUME_NONNULL_END
