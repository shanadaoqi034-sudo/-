//
//  DGLog.h — 统一诊断日志
//
//  ==========================================================================
//   日志位置
//  ==========================================================================
//
//  真实路径：/rootfs/private/var/mobile/Documents/test/
//
//  ---- 为什么不写 /var/mobile/Documents/ ----
//
//  这台设备是 roothide（Relaxin）。它会把 /var/mobile 重定向到
//  AppGroup 容器里：
//
//    /var/mobile  →  /rootfs/private/var/mobile/Containers/Shared/
//                    AppGroup/.jbroot-B7BA5119268440A7/var/mobile
//
//  所以从 App 进程里写 /var/mobile/Documents/xxx.log，实际落到的是
//  重定向后的位置，用户用 Filza 在 /var/mobile/Documents/ 看不到
//  （Filza 显示的是真实物理路径）。
//
//  两个位置的 inode 完全不同（实测 10287 vs 223475169），确实是两个目录。
//
//  ---- 所以 ----
//
//  必须用真实路径 /rootfs/private/var/mobile/Documents/test/，
//  这样 App 写的日志和用户在 Filza 看到的是同一个文件。
//
//  权限已验证：该目录是 mobile:mobile drwxr-xr-x，
//  App 沙盒进程（uid 501 = mobile）可写。
//
//  ==========================================================================
//   用法
//  ==========================================================================
//
//    DGLogInit(@"DualGuard");          // 启动时调一次
//    DGLog(@"模块名", @"内容 %@", 值);  // 任意位置记录
//    DGLogFlush();                      // 可选，立即落盘
//
//  日志文件：
//    /rootfs/private/var/mobile/Documents/test/DualGuard.log
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 日志目录（真实物理路径）
FOUNDATION_EXPORT NSString * const DGLogDirectory;

// 初始化。prefix 会出现在每行开头，方便区分是哪个插件写的。
FOUNDATION_EXPORT void DGLogInit(NSString *prefix);

// 记一条日志。支持格式化。
FOUNDATION_EXPORT void DGLog(NSString *module, NSString *format, ...)
    NS_FORMAT_FUNCTION(2, 3);

// 立即落盘（平时不需要，进程退出前或关键节点可调）
FOUNDATION_EXPORT void DGLogFlush(void);

// 清空当前日志文件
FOUNDATION_EXPORT void DGLogClear(void);

NS_ASSUME_NONNULL_END
