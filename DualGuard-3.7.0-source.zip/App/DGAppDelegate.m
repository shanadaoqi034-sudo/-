//
//  DGAppDelegate.m
//

#import "DGAppDelegate.h"
#import "DGSettingsRoot.h"
#import "DGLog.h"

@implementation DGAppDelegate

- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    DGLogInit(@"DualGuardSettings");
    DGLog(@"启动", @"didFinishLaunching 开始");
    DGLog(@"启动", @"屏幕 %.0f x %.0f pt",
          UIScreen.mainScreen.bounds.size.width,
          UIScreen.mainScreen.bounds.size.height);
    DGLog(@"启动", @"日志目录: %@", DGLogDirectory);

    @try {
        self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
        DGLog(@"启动", @"UIWindow 创建成功");
    } @catch (NSException *e) {
        DGLog(@"启动", @"✗ UIWindow 创建失败: %@", e);
        return YES;
    }

    @try {
        DGSettingsRoot *root = [[DGSettingsRoot alloc] init];
        DGLog(@"启动", @"DGSettingsRoot 创建成功");

        UINavigationController *nav = [[UINavigationController alloc]
                                       initWithRootViewController:root];
        DGLog(@"启动", @"UINavigationController 创建成功");

        self.window.rootViewController = nav;
        [self.window makeKeyAndVisible];
        DGLog(@"启动", @"窗口已显示，启动完成");
    } @catch (NSException *e) {
        DGLog(@"启动", @"✗ 根控制器创建失败: %@", e);
    }

    return YES;
}

@end
