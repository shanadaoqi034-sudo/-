//
//  DGHelper.m — 调用 setuid root helper
//

#import "DGHelper.h"
#import <spawn.h>
#import <sys/wait.h>
#import <sys/stat.h>
#import <unistd.h>
#import <fcntl.h>

extern char **environ;

// rootless 环境下的 jbroot 前缀
static NSString *DGJBPath(NSString *relative) {
    // 候选路径，按优先级
    NSMutableArray *candidates = [NSMutableArray array];

    // 1) 标准 rootless 前缀
    char resolved[PATH_MAX] = {0};
    if (realpath("/var/jb", resolved) && resolved[0]) {
        [candidates addObject:[NSString stringWithFormat:@"%s%@", resolved, relative]];
    }
    // 2) 直接 /var/jb
    [candidates addObject:[@"/var/jb" stringByAppendingString:relative]];
    // 3) 非 rootless
    [candidates addObject:relative];

    for (NSString *p in candidates) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:p]) return p;
    }
    return candidates.firstObject;
}

NSString *DGHelperPath(void) {
    return DGJBPath(@"/usr/libexec/dghosts");
}

BOOL DGHelperAvailable(void) {
    NSString *path = DGHelperPath();
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:path]) return NO;
    if (![fm isExecutableFileAtPath:path]) return NO;

    // 检查 setuid 位
    NSDictionary *attrs = [fm attributesOfItemAtPath:path error:NULL];
    NSNumber *perms = attrs[NSFilePosixPermissions];
    if (!perms) return NO;
    unsigned short mode = perms.unsignedShortValue;
    return (mode & S_ISUID) != 0;
}

NSString *DGHelperRun(NSString *command, int *exitCode) {
    NSString *path = DGHelperPath();
    if (!path) {
        if (exitCode) *exitCode = -1;
        return nil;
    }

    // 用管道接 stdout
    int pipefd[2];
    if (pipe(pipefd) != 0) {
        if (exitCode) *exitCode = -1;
        return nil;
    }

    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDERR_FILENO);
    posix_spawn_file_actions_addclose(&actions, pipefd[0]);
    posix_spawn_file_actions_addclose(&actions, pipefd[1]);

    const char *argv[] = { path.UTF8String, command.UTF8String, NULL };

    pid_t pid = 0;
    int rc = posix_spawn(&pid, path.UTF8String, &actions, NULL,
                         (char *const *)argv, environ);
    posix_spawn_file_actions_destroy(&actions);
    close(pipefd[1]);

    if (rc != 0) {
        close(pipefd[0]);
        if (exitCode) *exitCode = -1;
        NSLog(@"[DualGuard] posix_spawn 失败: %d", rc);
        return nil;
    }

    NSMutableData *data = [NSMutableData data];
    char buf[4096];
    ssize_t n;
    while ((n = read(pipefd[0], buf, sizeof(buf))) > 0) {
        [data appendBytes:buf length:(NSUInteger)n];
    }
    close(pipefd[0]);

    int status = 0;
    waitpid(pid, &status, 0);
    if (exitCode) {
        *exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    }

    NSString *out = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return [out stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

NSString *DGHelperDiagnostics(void) {
    NSMutableString *s = [NSMutableString string];
    NSString *path = DGHelperPath();
    [s appendFormat:@"helper 路径: %@\n", path];

    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL exists = [fm fileExistsAtPath:path];
    [s appendFormat:@"存在: %@\n", exists ? @"是" : @"否"];

    if (exists) {
        NSDictionary *attrs = [fm attributesOfItemAtPath:path error:NULL];
        NSNumber *perms = attrs[NSFilePosixPermissions];
        unsigned short mode = perms.unsignedShortValue;
        [s appendFormat:@"权限: %04o\n", mode];
        [s appendFormat:@"setuid: %@\n", (mode & S_ISUID) ? @"是" : @"否"];
        [s appendFormat:@"属主 uid: %@\n", attrs[NSFileOwnerAccountID]];
        [s appendFormat:@"可执行: %@\n", [fm isExecutableFileAtPath:path] ? @"是" : @"否"];
    }

    [s appendFormat:@"当前 uid: %d  euid: %d\n", getuid(), geteuid()];
    return s;
}
