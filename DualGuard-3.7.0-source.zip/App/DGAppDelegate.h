//
//  DGAppDelegate.h — App 委托
//

#import <UIKit/UIKit.h>

@interface DGAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end
