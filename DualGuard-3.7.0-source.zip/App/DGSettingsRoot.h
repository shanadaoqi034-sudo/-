//
//  DGSettingsRoot.h — 设置 App 根控制器
//
//  用 UIScrollView + UIStackView 纯 Auto Layout 构建，不用 UITableView。
//  原因见 .m 文件头部注释。
//

#import <UIKit/UIKit.h>

@interface DGSettingsRoot : UIViewController
@end
