//
//  DGTheme.m — 二次元风格主题 + 屏幕适配实现
//

#import "DGTheme.h"

// 基准设备：iPhone 15 Pro，逻辑宽度 393pt
static const CGFloat kDGDesignWidth = 393.0;

@implementation DGTheme

#pragma mark - 屏幕适配

+ (CGFloat)designWidth { return kDGDesignWidth; }

+ (CGFloat)screenWidth {
    if (@available(iOS 13.0, *)) {
        // 用 windowScene 拿真实屏幕尺寸，比 UIScreen.bounds 在多窗口下更准
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                return ((UIWindowScene *)scene).screen.bounds.size.width;
            }
        }
    }
    return UIScreen.mainScreen.bounds.size.width;
}

+ (CGFloat)screenHeight {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                return ((UIWindowScene *)scene).screen.bounds.size.height;
            }
        }
    }
    return UIScreen.mainScreen.bounds.size.height;
}

+ (CGFloat)scale {
    CGFloat w = [self screenWidth];
    if (w <= 0) return 1.0;
    CGFloat s = w / kDGDesignWidth;
    // 限制在 0.85 ~ 1.25，避免极端屏幕把 UI 拉变形
    if (s < 0.85) s = 0.85;
    if (s > 1.25) s = 1.25;
    return s;
}

+ (CGFloat)scaled:(CGFloat)value {
    return round(value * [self scale]);
}

+ (CGFloat)contentMargin     { return [self scaled:16]; }
+ (CGFloat)cardCornerRadius  { return [self scaled:18]; }
+ (CGFloat)cardInnerPadding  { return [self scaled:16]; }
+ (CGFloat)rowMinHeight      { return [self scaled:52]; }
+ (CGFloat)sectionSpacing    { return [self scaled:24]; }
+ (CGFloat)sectionHeaderHeight { return [self scaled:44]; }

#pragma mark - 颜色

+ (UIColor *)primaryPink {
    return [UIColor colorWithRed:1.00 green:0.494 blue:0.702 alpha:1.0];
}
+ (UIColor *)primaryBlue {
    return [UIColor colorWithRed:0.494 green:0.784 blue:1.00 alpha:1.0];
}
+ (UIColor *)accentCyan {
    return [UIColor colorWithRed:0.361 green:0.882 blue:0.902 alpha:1.0];
}
+ (UIColor *)accentPurple {
    return [UIColor colorWithRed:0.706 green:0.557 blue:1.00 alpha:1.0];
}
+ (UIColor *)accentYellow {
    return [UIColor colorWithRed:1.00 green:0.820 blue:0.400 alpha:1.0];
}

+ (UIColor *)backgroundDark {
    return [UIColor colorWithRed:0.102 green:0.102 blue:0.180 alpha:1.0];
}
+ (UIColor *)backgroundLight {
    return [UIColor colorWithRed:1.00 green:0.961 blue:0.976 alpha:1.0];
}
+ (UIColor *)cardDark {
    return [UIColor colorWithRed:0.145 green:0.145 blue:0.251 alpha:1.0];
}
+ (UIColor *)cardLight { return [UIColor whiteColor]; }

+ (UIColor *)textPrimary {
    if (@available(iOS 13.0, *)) return [UIColor labelColor];
    return [UIColor blackColor];
}
+ (UIColor *)textSecondary {
    if (@available(iOS 13.0, *)) return [UIColor secondaryLabelColor];
    return [UIColor darkGrayColor];
}
+ (UIColor *)textTertiary {
    if (@available(iOS 13.0, *)) return [UIColor tertiaryLabelColor];
    return [UIColor lightGrayColor];
}

+ (BOOL)isDark {
    if (@available(iOS 13.0, *)) {
        return UITraitCollection.currentTraitCollection.userInterfaceStyle
               == UIUserInterfaceStyleDark;
    }
    return NO;
}

+ (UIColor *)background {
    return [self isDark] ? [self backgroundDark] : [self backgroundLight];
}
+ (UIColor *)cardBackground {
    return [self isDark] ? [self cardDark] : [self cardLight];
}

#pragma mark - 渐变

+ (CAGradientLayer *)mainGradientLayer {
    CAGradientLayer *g = [CAGradientLayer layer];

    // ---- 必须先把 UIColor 存进局部变量 ----
    //
    // 崩溃原因：原来写的是
    //     g.colors = @[ (id)[self primaryPink].CGColor, ... ];
    //
    // [self primaryPink] 返回一个 autorelease 的临时 UIColor，
    // .CGColor 从它上面取出 CGColorRef。把 CGColorRef 桥接成 id 放进
    // NSArray 时，NSArray 只会对「ObjC 对象」做 retain —— CGColorRef 不是
    // ObjC 对象，不会被 retain。
    //
    // 方法返回后临时 UIColor 被释放，它的 CGColor 跟着失效，
    // 数组里留下野指针。CAGradientLayer 真正渲染时读到野指针 → 段错误。
    //
    // 这就是 A3（无渐变）能启动、A4（有渐变）崩溃的原因。
    //
    // 修法：用局部变量持有 UIColor，保证 CGColor 在赋值期间有效；
    // 赋值完 CAGradientLayer 自己会 retain 这些 CGColor。
    UIColor *c1 = [self primaryPink];
    UIColor *c2 = [self accentPurple];
    UIColor *c3 = [self primaryBlue];

    g.colors = @[
        (id)c1.CGColor,
        (id)c2.CGColor,
        (id)c3.CGColor,
    ];
    g.locations = @[@0.0, @0.5, @1.0];
    g.startPoint = CGPointMake(0.0, 0.0);
    g.endPoint = CGPointMake(1.0, 1.0);
    return g;
}

#pragma mark - 字体

+ (UIFont *)roundedFontOfSize:(CGFloat)size weight:(UIFontWeight)weight {
    UIFont *base = [UIFont systemFontOfSize:size weight:weight];
    if (@available(iOS 13.0, *)) {
        UIFontDescriptor *desc = [base.fontDescriptor
            fontDescriptorWithDesign:UIFontDescriptorSystemDesignRounded];
        if (desc) {
            UIFont *rounded = [UIFont fontWithDescriptor:desc size:size];
            if (rounded) return rounded;
        }
    }
    return base;
}

+ (UIFont *)fontHeroTitle    { return [self roundedFontOfSize:32 weight:UIFontWeightBold]; }
+ (UIFont *)fontSectionTitle { return [self roundedFontOfSize:17 weight:UIFontWeightSemibold]; }
+ (UIFont *)fontRowLabel     { return [self roundedFontOfSize:15 weight:UIFontWeightRegular]; }
+ (UIFont *)fontFooter       { return [self roundedFontOfSize:13 weight:UIFontWeightRegular]; }
+ (UIFont *)fontBadge        { return [self roundedFontOfSize:12 weight:UIFontWeightSemibold]; }
+ (UIFont *)fontNumber       { return [UIFont monospacedDigitSystemFontOfSize:15
                                                                       weight:UIFontWeightMedium]; }

#pragma mark - 装饰

+ (void)applyCardStyleToView:(UIView *)view {
    if (!view) return;

    // ---- 圆角和阴影的冲突 ----
    //
    // layer.masksToBounds = YES  → 圆角生效，但阴影被裁掉
    // layer.masksToBounds = NO   → 阴影显示，但圆角不裁剪内容
    //
    // 一个 layer 不可能同时满足。正确做法是两层：
    //   外层 container：负责阴影（masksToBounds = NO）
    //   内层 content  ：负责圆角 + 裁剪（masksToBounds = YES）
    //
    // 这里直接把传进来的 view 当内容层，圆角和裁剪都开，
    // 阴影交给调用方用容器实现（见 DGSettingsRoot 的 makeCardContainer）。
    view.backgroundColor = [self cardBackground];
    view.layer.cornerRadius = [self cardCornerRadius];
    view.layer.cornerCurve = kCACornerCurveContinuous;
    view.layer.masksToBounds = YES;      // 圆角必须裁剪
    view.layer.borderWidth = 0.5;
    view.layer.borderColor = [self isDark]
        ? [[self primaryPink] colorWithAlphaComponent:0.22].CGColor
        : [[self primaryPink] colorWithAlphaComponent:0.15].CGColor;
}

// 给内容视图套一个负责阴影的外层容器，返回容器。
// 用法：card = [DGTheme wrapCardForShadow:stack];
+ (UIView *)wrapCardForShadow:(UIView *)content {
    if (!content) return nil;

    UIView *container = [[UIView alloc] init];
    container.translatesAutoresizingMaskIntoConstraints = NO;
    container.backgroundColor = UIColor.clearColor;

    // 阴影在外层
    container.layer.shadowColor = [UIColor blackColor].CGColor;
    container.layer.shadowOpacity = [self isDark] ? 0.28 : 0.07;
    container.layer.shadowRadius = [self scaled:10];
    container.layer.shadowOffset = CGSizeMake(0, [self scaled:3]);
    container.layer.masksToBounds = NO;

    content.translatesAutoresizingMaskIntoConstraints = NO;
    [container addSubview:content];

    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:container.topAnchor],
        [content.leadingAnchor constraintEqualToAnchor:container.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:container.trailingAnchor],
        [content.bottomAnchor constraintEqualToAnchor:container.bottomAnchor],
    ]];

    return container;
}

@end
