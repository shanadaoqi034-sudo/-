//
//  DGSettingsRoot.m — DualGuard 设置界面（重写版）
//
//  ==========================================================================
//   设计约束（按 A1→A3 的实测结论）
//  ==========================================================================
//
//  A1（纯 UILabel）        ✅ 能启动
//  A2（+ DGTheme）         ✅ 能启动
//  A3（+ ScrollView/Stack）✅ 能启动
//  A4（+ CAGradientLayer） ❌ 崩溃 → CGColor 野指针
//
//  所以这版从 A3 的骨架出发，逐块添加，每块都按已验证安全的方式写：
//
//    1. 骨架：UIScrollView + 纵向 UIStackView（A3 验证过）
//    2. 渐变：UIColor 先存局部变量，再取 CGColor（修掉野指针）
//    3. 行：自定义 UIView + 约束，不用 accessoryView、不用 sizeToFit
//    4. 不用 UITableView（避免 cell 复用和手画圆角）
//
//  ==========================================================================
//   结构
//  ==========================================================================
//
//  ScrollView
//  └── rootStack（纵向）
//      ├── heroView      渐变头图
//      ├── contentStack  内容区（左右 16pt 内缩）
//      │   ├── 分组标题
//      │   ├── card      卡片（纵向 StackView）
//      │   │   ├── row   switch 行
//      │   │   ├── sep   分隔线
//      │   │   └── row   stepper 行
//      │   └── footer    说明文字
//      └── spacer        底部留白
//

#import "DGSettingsRoot.h"
#import "DGHelper.h"
#import "DGTheme.h"
#import "DGLog.h"
#import "DGAppConfigPage.h"
#import "DGPerApp.h"
#import <objc/message.h>
#import <notify.h>
#import <dlfcn.h>

// ---- 配置文件的真实物理路径 ----
//
// 这台设备是 roothide，/var/mobile 会被重定向到 AppGroup 容器：
//   /var/mobile  →  /rootfs/private/var/mobile/Containers/Shared/
//                   AppGroup/.jbroot-B7BA5119268440A7/var/mobile
//
// 而 CFPreferences 走的是真实物理路径 /rootfs/private/var/mobile/。
// 结果同一个逻辑路径落到两个不同的物理文件，两边数据分裂 ——
// 这就是「设置里关了开关但功能还在」的根因。
//
// 实测两份文件：
//   /var/mobile/...                        25785 字节  607 键  RedirectEnabled=True
//   /rootfs/private/var/mobile/...         31772 字节  602 键  RedirectEnabled=False
//   两者 inode 不同（223747797 vs 223747779），确实是两个文件。
//
// 现在统一用真实物理路径，两边读写同一份。
#define DG_PREFS_PATH @"/rootfs/private/var/mobile/Library/Preferences/com.deepseek.dualguard.plist"

// 兜底：如果真实路径不可用（比如别的越狱环境），用标准路径
#define DG_PREFS_PATH_FALLBACK @"/var/mobile/Library/Preferences/com.deepseek.dualguard.plist"
#define DG_KEY_ENABLED          @"Enabled"
#define DG_KEY_SENSOR           @"SensorEnabled"
#define DG_KEY_REDIRECT         @"RedirectEnabled"
#define DG_KEY_BLOCK_STORE      @"BlockAppStore"
#define DG_KEY_BLOCK_SAFARI     @"BlockSafari"
#define DG_KEY_BLOCK_OTHERS     @"BlockOthers"
#define DG_KEY_BLOCK_WEB        @"BlockWeb"
#define DG_KEY_BLOCK_OTHERAPPS  @"BlockOtherApps"
#define DG_KEY_BLOCK_ALLJUMPS   @"BlockAllJumps"
#define DG_KEY_ADSKIP           @"AdSkipEnabled"
#define DG_KEY_ADSKIP_AGGR      @"AdSkipAggressive"
#define DG_KEY_ADSKIP_PREFIX    @"AdSkip."
#define DG_KEY_DNSBLOCK         @"DNSBlockEnabled"
#define DG_KEY_SHAKE            @"ShakeBlockEnabled"
#define DG_KEY_SHAKE_WINDOW     @"ShakeWindow"
#define DG_KEY_SENSOR_PREFIX    @"SensorBlocked."

// ---- 传感器细分（3.6.0）----
#define DG_KEY_SENSOR_ACCEL     @"SensorAccelEnabled"
#define DG_KEY_SENSOR_GYRO      @"SensorGyroEnabled"
#define DG_KEY_SENSOR_MAG       @"SensorMagEnabled"
#define DG_KEY_SENSOR_MOTION    @"SensorMotionEnabled"
#define DG_KEY_SENSOR_COMPASS   @"SensorCompassEnabled"
#define DG_KEY_SENSOR_LOCATION  @"SensorLocationEnabled"

// ---- 权限伪装（3.7.0）----
#define DGKeyPermEnabled        @"PermFakeEnabled"
#define DGKeyPermPhotos         @"PermFakePhotos"
#define DGKeyPermContacts       @"PermFakeContacts"
#define DGKeyPermCalendar       @"PermFakeCalendar"
#define DGKeyPermReminders      @"PermFakeReminders"
#define DGKeyPermMicrophone     @"PermFakeMicrophone"
#define DGKeyPermCamera         @"PermFakeCamera"
#define DGKeyPermLocation       @"PermFakeLocation"
#define DGKeyPermBluetooth      @"PermFakeBluetooth"
#define DGKeyPermHealth         @"PermFakeHealth"
#define DGKeyPermNotifications  @"PermFakeNotifications"


#define DG_CHANGED_NOTIFY       "com.deepseek.dualguard/changed"

// ===========================================================================
//  偏好（走 CFPreferences，不直写文件）
// ===========================================================================

// ===========================================================================
//  偏好读写
// ===========================================================================
//
//  ---- 为什么设置 App 不能只用 CFPreferences ----
//
//  设置 App 的 ent.plist 里有 com.apple.private.security.no-container = true，
//  它不创建沙盒容器。实测 /var/mobile/Containers/Data/Application/ 里
//  没有 DualGuardSettings 的容器目录。
//
//  在这种「无容器」进程里，CFPreferencesSetAppValue 写不进去 —— cfprefsd
//  不知道这个进程属于哪个容器，写入会被丢弃或落到别处。
//
//  这就是「总开关关了但配置没变」的根因：
//  用户点了开关 → CFPreferencesSetAppValue → 静默失败 → plist 里还是 True。
//
//  ---- 现在怎么做 ----
//
//  读：先试 CFPreferences（拿到 tweak 侧写入的最新值），
//      读不到就直读文件。
//  写：直写文件，然后 post 一个 Darwin 通知让 cfprefsd 和所有进程重读。
//
//  这样设置 App（无容器）和 tweak（在 App 进程里，有容器）都能正确工作。
//

// ---- 配置迁移 ----
//
// 之前因为路径重定向，配置分裂成了两份。第一次运行时把两份合并，
// 以「最近修改的那份」为准，然后删掉另一份，避免继续分裂。
//
// 迁移只做一次（用标记文件判断）。
static void DGMigrateSplitConfigOnce(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSFileManager *fm = [NSFileManager defaultManager];

        NSString *real = DG_PREFS_PATH;
        NSString *std  = DG_PREFS_PATH_FALLBACK;

        BOOL hasReal = [fm fileExistsAtPath:real];
        BOOL hasStd  = [fm fileExistsAtPath:std];

        // 只有一份或都没有，不用迁移
        if (hasReal == hasStd) return;

        // 只有标准路径有 → 搬到真实路径
        if (hasStd && !hasReal) {
            NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:std];
            if ([d isKindOfClass:[NSDictionary class]] && d.count) {
                [d writeToFile:real atomically:YES];
                [fm removeItemAtPath:std error:NULL];
                NSLog(@"[DualGuard] 配置已从标准路径迁移到真实路径（%lu 键）",
                      (unsigned long)d.count);
            }
        }
        // 只有真实路径有 → 删掉标准路径那份残留（如果有）
        else if (hasReal && !hasStd) {
            // 什么都不用做
        }
    });
}

// 从文件读（真实路径优先，标准路径兜底）
static NSDictionary *DGReadFromFile(void) {
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:DG_PREFS_PATH];
    if ([d isKindOfClass:[NSDictionary class]] && d.count) return d;

    d = [NSDictionary dictionaryWithContentsOfFile:DG_PREFS_PATH_FALLBACK];
    if ([d isKindOfClass:[NSDictionary class]] && d.count) return d;

    return nil;
}

// 实际要写入的路径（哪个存在写哪个，都不存在就建真实路径）
static NSString *DGWritePath(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:DG_PREFS_PATH]) return DG_PREFS_PATH;

    // 真实路径不存在，但它的父目录存在 → 用真实路径
    NSString *dir = [DG_PREFS_PATH stringByDeletingLastPathComponent];
    BOOL isDir = NO;
    if ([fm fileExistsAtPath:dir isDirectory:&isDir] && isDir) return DG_PREFS_PATH;

    return DG_PREFS_PATH_FALLBACK;
}

static NSMutableDictionary *DGReadPrefs(void) {
    DGMigrateSplitConfigOnce();

    // 优先文件：设置 App 自己写的就是文件，能立刻读到最新值
    NSDictionary *fileDict = DGReadFromFile();
    if (fileDict.count) return [fileDict mutableCopy];

    // 文件没有就试 CFPreferences
    NSMutableDictionary *out = [NSMutableDictionary dictionary];
    CFStringRef appID = CFSTR("com.deepseek.dualguard");
    CFArrayRef keys = CFPreferencesCopyKeyList(appID, kCFPreferencesCurrentUser,
                                               kCFPreferencesAnyHost);
    if (keys) {
        NSDictionary *d = CFBridgingRelease(CFPreferencesCopyMultiple(keys, appID,
                                                                     kCFPreferencesCurrentUser,
                                                                     kCFPreferencesAnyHost));
        if ([d isKindOfClass:[NSDictionary class]]) [out addEntriesFromDictionary:d];
        CFRelease(keys);
    }
    return out;
}

static void DGWritePrefs(NSDictionary *dict) {
    if (![dict isKindOfClass:[NSDictionary class]] || !dict.count) return;

    // ---- 1. 直写文件（真实物理路径）----
    NSString *path = DGWritePath();

    BOOL ok = [dict writeToFile:path atomically:YES];
    if (!ok) {
        ok = [dict writeToFile:path atomically:NO];
    }
    if (!ok) {
        NSLog(@"[DualGuard] ✗ 配置写入失败: %@", path);
        return;
    }

    // 权限：mobile 可读写，cfprefsd 和 tweak 都要能读
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm setAttributes:@{NSFilePosixPermissions: @(0600)} ofItemAtPath:path error:NULL];

    // ---- 2. 同步到 cfprefsd ----
    //
    // tweak 跑在第三方 App 里，那边有容器，会用 CFPreferences 读。
    // 所以要把文件里的值也推进 cfprefsd，两边才一致。
    CFStringRef appID = CFSTR("com.deepseek.dualguard");
    for (NSString *k in dict) {
        if (![k isKindOfClass:[NSString class]]) continue;
        CFPreferencesSetAppValue((__bridge CFStringRef)k,
                                 (__bridge CFPropertyListRef)dict[k], appID);
    }
    CFPreferencesAppSynchronize(appID);

    // ---- 3. 通知所有进程重读 ----
    notify_post(DG_CHANGED_NOTIFY);
}

static BOOL DGPrefBool(NSDictionary *d, NSString *key, BOOL fallback) {
    if (!key.length || ![d isKindOfClass:[NSDictionary class]]) return fallback;
    id v = d[key];
    return v ? [v boolValue] : fallback;
}


// ===========================================================================
//  已安装 App
// ===========================================================================

static NSArray *DGInstalledApps(void) {
    NSMutableArray *result = [NSMutableArray array];
    dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices", RTLD_LAZY);

    Class wsClass = NSClassFromString(@"LSApplicationWorkspace");
    if (!wsClass) return result;
    SEL selDefault = sel_registerName("defaultWorkspace");
    if (![wsClass respondsToSelector:selDefault]) return result;
    id ws = ((id (*)(id, SEL))objc_msgSend)(wsClass, selDefault);
    if (!ws) return result;

    SEL selAll = sel_registerName("allInstalledApplications");
    if (![ws respondsToSelector:selAll]) return result;
    id all = ((id (*)(id, SEL))objc_msgSend)(ws, selAll);
    if (![all isKindOfClass:[NSArray class]]) return result;

    for (id proxy in (NSArray *)all) {
        @autoreleasepool {
            SEL selBid = sel_registerName("bundleIdentifier");
            if (![proxy respondsToSelector:selBid]) continue;
            id bidObj = ((id (*)(id, SEL))objc_msgSend)(proxy, selBid);
            if (![bidObj isKindOfClass:[NSString class]]) continue;
            NSString *bid = (NSString *)bidObj;
            if (!bid.length) continue;
            if ([bid hasPrefix:@"com.apple."]) continue;
            if ([bid hasPrefix:@"com.deepseek."]) continue;

            NSString *name = nil;
            SEL selName = sel_registerName("localizedName");
            if ([proxy respondsToSelector:selName]) {
                id n = ((id (*)(id, SEL))objc_msgSend)(proxy, selName);
                if ([n isKindOfClass:[NSString class]] && [(NSString *)n length]) {
                    name = (NSString *)n;
                }
            }
            if (!name) name = bid;
            [result addObject:@{@"id": bid, @"name": name}];
        }
    }
    [result sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] localizedStandardCompare:b[@"name"]];
    }];
    return result;
}

// ===========================================================================
//  渐变头图（CGColor 已修正）
// ===========================================================================

@interface DGHeroView : UIView
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UILabel *badgeLabel;
- (void)setBadgeText:(NSString *)text;
@end

@implementation DGHeroView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    // ---- 渐变 ----
    //
    // CGColor 必须先由 UIColor 局部变量持有。
    // 直接写 (id)[someColor].CGColor 会拿到野指针 —— 这是 A4 崩溃的原因。
    UIColor *pink   = [DGTheme primaryPink];
    UIColor *purple = [DGTheme accentPurple];
    UIColor *blue   = [DGTheme primaryBlue];

    _gradientLayer = [CAGradientLayer layer];
    _gradientLayer.colors = @[
        (id)pink.CGColor,
        (id)purple.CGColor,
        (id)blue.CGColor,
    ];
    _gradientLayer.locations = @[@0.0, @0.5, @1.0];
    _gradientLayer.startPoint = CGPointMake(0.0, 0.0);
    _gradientLayer.endPoint = CGPointMake(1.0, 1.0);
    [self.layer insertSublayer:_gradientLayer atIndex:0];

    // ---- 标题 ----
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.text = @"DualGuard";
    _titleLabel.font = [DGTheme fontHeroTitle];
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_titleLabel];

    // ---- 副标题 ----
    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.text = @"广告拦截 · 跳转防护 · 传感器控制";
    _subtitleLabel.font = [DGTheme fontFooter];
    _subtitleLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.88];
    _subtitleLabel.numberOfLines = 1;
    _subtitleLabel.adjustsFontSizeToFitWidth = YES;
    _subtitleLabel.minimumScaleFactor = 0.8;
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_subtitleLabel];

    // ---- 徽标 ----
    _badgeLabel = [[UILabel alloc] init];
    _badgeLabel.font = [DGTheme fontBadge];
    _badgeLabel.textColor = [UIColor whiteColor];
    _badgeLabel.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.22];
    _badgeLabel.textAlignment = NSTextAlignmentCenter;
    _badgeLabel.layer.cornerRadius = [DGTheme scaled:10];
    _badgeLabel.layer.cornerCurve = kCACornerCurveContinuous;
    _badgeLabel.clipsToBounds = YES;
    _badgeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_badgeLabel];

    CGFloat m = [DGTheme contentMargin];
    CGFloat pad = [DGTheme scaled:4];

    [NSLayoutConstraint activateConstraints:@[
        [_titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:m],
        [_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:self.trailingAnchor constant:-m],
        [_titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:[DGTheme scaled:16]],

        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_subtitleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:self.trailingAnchor constant:-m],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:pad],

        [_badgeLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_badgeLabel.topAnchor constraintEqualToAnchor:_subtitleLabel.bottomAnchor
                                              constant:[DGTheme scaled:10]],
        [_badgeLabel.heightAnchor constraintEqualToConstant:[DGTheme scaled:22]],
        [_badgeLabel.bottomAnchor constraintEqualToAnchor:self.bottomAnchor
                                                 constant:-[DGTheme scaled:16]],
    ]];

    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // 渐变层跟随尺寸变化
    _gradientLayer.frame = self.bounds;
}

- (void)setBadgeText:(NSString *)text {
    _badgeLabel.text = text.length
        ? [NSString stringWithFormat:@"  %@  ", text]
        : nil;
}

@end

// ===========================================================================
//  行视图
// ===========================================================================
//
//  一行 = 标题（左）+ 控件（右），全部约束，不用 frame。
//  右侧控件贴右，标题右边界不越过控件，长标题自动换行。
//

typedef NS_ENUM(NSInteger, DGRowKind) {
    DGRowKindSwitch = 0,
    DGRowKindStepper,
    DGRowKindLink,
    DGRowKindButton,
};

@interface DGRowView : UIView
@property (nonatomic) DGRowKind kind;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UISwitch *toggle;
@property (nonatomic, strong) UIStepper *stepper;
@property (nonatomic, strong) UILabel *valueLabel;
@property (nonatomic, strong) UILabel *badgeLabel;
@property (nonatomic, strong) NSString *key;
@property (nonatomic, strong) NSString *action;
@property (nonatomic, copy) void (^onToggle)(BOOL on);
@property (nonatomic, copy) void (^onStep)(double value);
@property (nonatomic, copy) void (^onTap)(void);
@end

@implementation DGRowView

- (instancetype)initWithKind:(DGRowKind)kind title:(NSString *)title {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;

    _kind = kind;
    self.translatesAutoresizingMaskIntoConstraints = NO;

    CGFloat pad = [DGTheme cardInnerPadding];
    CGFloat minH = [DGTheme rowMinHeight];

    // ---- 标题 ----
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.text = title;
    _titleLabel.font = [DGTheme fontRowLabel];
    _titleLabel.textColor = [DGTheme textPrimary];
    _titleLabel.numberOfLines = 0;
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [_titleLabel setContentCompressionResistancePriority:UILayoutPriorityDefaultHigh
                                                 forAxis:UILayoutConstraintAxisHorizontal];
    [self addSubview:_titleLabel];

    // ---- 右侧控件 ----
    UIView *rightView = nil;

    switch (kind) {
        case DGRowKindSwitch: {
            _toggle = [[UISwitch alloc] init];
            _toggle.onTintColor = [DGTheme primaryPink];
            _toggle.translatesAutoresizingMaskIntoConstraints = NO;
            [_toggle addTarget:self action:@selector(handleToggle:)
              forControlEvents:UIControlEventValueChanged];
            [self addSubview:_toggle];
            rightView = _toggle;
            break;
        }
        case DGRowKindStepper: {
            // 数值 label：宽度约束固定，不用 sizeToFit
            _valueLabel = [[UILabel alloc] init];
            _valueLabel.text = @"0";
            _valueLabel.font = [DGTheme fontNumber];
            _valueLabel.textColor = [DGTheme primaryPink];
            _valueLabel.textAlignment = NSTextAlignmentRight;
            _valueLabel.translatesAutoresizingMaskIntoConstraints = NO;
            [_valueLabel setContentCompressionResistancePriority:UILayoutPriorityRequired
                                                         forAxis:UILayoutConstraintAxisHorizontal];
            [_valueLabel setContentHuggingPriority:UILayoutPriorityRequired
                                           forAxis:UILayoutConstraintAxisHorizontal];
            [_valueLabel.widthAnchor constraintEqualToConstant:[DGTheme scaled:36]].active = YES;

            _stepper = [[UIStepper alloc] init];
            _stepper.translatesAutoresizingMaskIntoConstraints = NO;
            [_stepper addTarget:self action:@selector(handleStep:)
               forControlEvents:UIControlEventValueChanged];

            UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[_valueLabel, _stepper]];
            stack.axis = UILayoutConstraintAxisHorizontal;
            stack.spacing = [DGTheme scaled:8];
            stack.alignment = UIStackViewAlignmentCenter;
            stack.translatesAutoresizingMaskIntoConstraints = NO;
            [self addSubview:stack];
            rightView = stack;
            break;
        }
        case DGRowKindLink: {
            _badgeLabel = [[UILabel alloc] init];
            _badgeLabel.font = [DGTheme fontBadge];
            _badgeLabel.textColor = [UIColor whiteColor];
            _badgeLabel.backgroundColor = [DGTheme primaryPink];
            _badgeLabel.textAlignment = NSTextAlignmentCenter;
            _badgeLabel.layer.cornerRadius = [DGTheme scaled:9];
            _badgeLabel.layer.cornerCurve = kCACornerCurveContinuous;
            _badgeLabel.clipsToBounds = YES;
            _badgeLabel.translatesAutoresizingMaskIntoConstraints = NO;
            _badgeLabel.hidden = YES;
            [_badgeLabel.widthAnchor constraintGreaterThanOrEqualToConstant:[DGTheme scaled:20]].active = YES;
            [_badgeLabel.heightAnchor constraintEqualToConstant:[DGTheme scaled:18]].active = YES;

            UIImageView *chevron = [[UIImageView alloc] initWithImage:
                [UIImage systemImageNamed:@"chevron.right"]];
            chevron.tintColor = [DGTheme textTertiary];
            chevron.contentMode = UIViewContentModeScaleAspectFit;
            chevron.translatesAutoresizingMaskIntoConstraints = NO;
            [chevron.widthAnchor constraintEqualToConstant:[DGTheme scaled:8]].active = YES;
            [chevron.heightAnchor constraintEqualToConstant:[DGTheme scaled:13]].active = YES;

            UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[_badgeLabel, chevron]];
            stack.axis = UILayoutConstraintAxisHorizontal;
            stack.spacing = [DGTheme scaled:6];
            stack.alignment = UIStackViewAlignmentCenter;
            stack.translatesAutoresizingMaskIntoConstraints = NO;
            [self addSubview:stack];
            rightView = stack;

            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self action:@selector(handleTap)];
            [self addGestureRecognizer:tap];
            self.userInteractionEnabled = YES;
            break;
        }
        case DGRowKindButton: {
            _titleLabel.textAlignment = NSTextAlignmentCenter;
            _titleLabel.textColor = [DGTheme primaryPink];
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self action:@selector(handleTap)];
            [self addGestureRecognizer:tap];
            self.userInteractionEnabled = YES;
            break;
        }
    }

    // ---- 布局 ----
    NSMutableArray *cs = [NSMutableArray array];
    [cs addObject:[self.heightAnchor constraintGreaterThanOrEqualToConstant:minH]];
    [cs addObject:[_titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:pad]];
    [cs addObject:[_titleLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]];
    [cs addObject:[_titleLabel.topAnchor constraintGreaterThanOrEqualToAnchor:self.topAnchor
                                                                   constant:[DGTheme scaled:12]]];
    [cs addObject:[_titleLabel.bottomAnchor constraintLessThanOrEqualToAnchor:self.bottomAnchor
                                                                    constant:-[DGTheme scaled:12]]];

    if (rightView) {
        [cs addObject:[rightView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-pad]];
        [cs addObject:[rightView.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]];
        [cs addObject:[_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:rightView.leadingAnchor
                                                                          constant:-[DGTheme scaled:8]]];
    } else {
        [cs addObject:[_titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-pad]];
    }

    [NSLayoutConstraint activateConstraints:cs];
    return self;
}

- (void)handleToggle:(UISwitch *)sender {
    if (self.onToggle) self.onToggle(sender.on);
}

- (void)handleStep:(UIStepper *)sender {
    _valueLabel.text = [NSString stringWithFormat:@"%.0f", sender.value];
    if (self.onStep) self.onStep(sender.value);
}

- (void)handleTap {
    if (self.onTap) self.onTap();
}

- (void)setBadgeText:(NSString *)text {
    if (!_badgeLabel) return;
    if (text.length) {
        _badgeLabel.text = text;
        _badgeLabel.hidden = NO;
    } else {
        _badgeLabel.hidden = YES;
    }
}

// 加副标题（App 列表用）
- (void)setSubtitle:(NSString *)text {
    if (!text.length) return;
    if (!_subtitleLabel) {
        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.font = [DGTheme fontFooter];
        _subtitleLabel.textColor = [DGTheme textTertiary];
        _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_subtitleLabel];
        [NSLayoutConstraint activateConstraints:@[
            [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
            [_subtitleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:self.trailingAnchor
                                                                    constant:-[DGTheme cardInnerPadding]],
            [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:2],
        ]];
        // 标题不再垂直居中，改成靠上
        for (NSLayoutConstraint *c in self.constraints) {
            if (c.firstItem == _titleLabel && c.firstAttribute == NSLayoutAttributeCenterY) {
                c.active = NO;
                break;
            }
        }
        [_titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor
                                              constant:[DGTheme scaled:10]].active = YES;
    }
    _subtitleLabel.text = text;
}

@end

// ===========================================================================
//  主界面
// ===========================================================================

@interface DGSettingsRoot () <DGAppConfigPageDelegate, UISearchBarDelegate>
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) UIStackView *rootStack;
@property (nonatomic, strong) UIStackView *contentStack;
@property (nonatomic, strong) DGHeroView *hero;
@property (nonatomic, strong) NSArray *allApps;
@property (nonatomic) BOOL showingAppList;
@property (nonatomic) BOOL showingAdAppList;
@property (nonatomic, strong) UIStackView *currentCard;
// 搜索框放在 rootStack 里（不在 contentStack 里），
// reload 重建列表时它不会被销毁，输入焦点和键盘都不会掉。
@property (nonatomic, strong) UIView *appSearchBox;
@property (nonatomic, strong) UISearchBar *appSearchBar;
@property (nonatomic, copy) NSString *appQuery;
@end

@implementation DGSettingsRoot

- (BOOL)isInListMode {
    return self.showingAppList || self.showingAdAppList;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    DGLog(@"界面", @"viewDidLoad 开始");
    self.view.backgroundColor = [DGTheme background];
    self.title = @"DualGuard";

    // 导航栏透明
    if (self.navigationController) {
        UINavigationBarAppearance *ap = [[UINavigationBarAppearance alloc] init];
        [ap configureWithTransparentBackground];
        ap.titleTextAttributes = @{
            NSFontAttributeName: [DGTheme fontSectionTitle],
            NSForegroundColorAttributeName: [DGTheme textPrimary],
        };
        self.navigationController.navigationBar.standardAppearance = ap;
        self.navigationController.navigationBar.scrollEdgeAppearance = ap;
        self.navigationController.navigationBar.prefersLargeTitles = NO;
    }

    // ---- ScrollView ----
    self.scroll = [[UIScrollView alloc] init];
    self.scroll.translatesAutoresizingMaskIntoConstraints = NO;
    self.scroll.alwaysBounceVertical = YES;
    self.scroll.showsVerticalScrollIndicator = YES;
    [self.view addSubview:self.scroll];

    // ---- 根 StackView ----
    self.rootStack = [[UIStackView alloc] init];
    self.rootStack.axis = UILayoutConstraintAxisVertical;
    self.rootStack.spacing = 0;
    self.rootStack.alignment = UIStackViewAlignmentFill;
    self.rootStack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.scroll addSubview:self.rootStack];

    [NSLayoutConstraint activateConstraints:@[
        [self.scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],

        [self.rootStack.topAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.topAnchor],
        [self.rootStack.leadingAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.leadingAnchor],
        [self.rootStack.trailingAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.trailingAnchor],
        [self.rootStack.bottomAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.bottomAnchor],
        [self.rootStack.widthAnchor constraintEqualToAnchor:self.scroll.frameLayoutGuide.widthAnchor],
    ]];

    // ---- Hero ----
    self.hero = [[DGHeroView alloc] initWithFrame:CGRectZero];
    self.hero.translatesAutoresizingMaskIntoConstraints = NO;
    [self.rootStack addArrangedSubview:self.hero];

    // ---- App 搜索框（默认隐藏，只在选 App 的列表里出现）----
    UIView *searchBox = [[UIView alloc] init];
    searchBox.translatesAutoresizingMaskIntoConstraints = NO;

    self.appSearchBar = [[UISearchBar alloc] init];
    self.appSearchBar.delegate = self;
    self.appSearchBar.searchBarStyle = UISearchBarStyleMinimal;
    self.appSearchBar.placeholder = @"搜索 App 名称或 Bundle ID";
    self.appSearchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.appSearchBar.autocorrectionType = UITextAutocorrectionTypeNo;
    self.appSearchBar.translatesAutoresizingMaskIntoConstraints = NO;
    [searchBox addSubview:self.appSearchBar];

    CGFloat sMargin = [DGTheme contentMargin];
    [NSLayoutConstraint activateConstraints:@[
        [self.appSearchBar.leadingAnchor constraintEqualToAnchor:searchBox.leadingAnchor
                                                       constant:sMargin],
        [self.appSearchBar.trailingAnchor constraintEqualToAnchor:searchBox.trailingAnchor
                                                        constant:-sMargin],
        [self.appSearchBar.topAnchor constraintEqualToAnchor:searchBox.topAnchor],
        [self.appSearchBar.bottomAnchor constraintEqualToAnchor:searchBox.bottomAnchor],
    ]];

    self.appSearchBox = searchBox;
    searchBox.hidden = YES;
    [self.rootStack addArrangedSubview:searchBox];

    // ---- 内容区 ----
    CGFloat margin = [DGTheme contentMargin];
    self.contentStack = [[UIStackView alloc] init];
    self.contentStack.axis = UILayoutConstraintAxisVertical;
    self.contentStack.spacing = 0;
    self.contentStack.alignment = UIStackViewAlignmentFill;
    self.contentStack.translatesAutoresizingMaskIntoConstraints = NO;
    self.contentStack.layoutMargins = UIEdgeInsetsMake(0, margin, 0, margin);
    self.contentStack.layoutMarginsRelativeArrangement = YES;
    [self.rootStack addArrangedSubview:self.contentStack];

    // ---- 底部留白 ----
    UIView *spacer = [[UIView alloc] init];
    spacer.translatesAutoresizingMaskIntoConstraints = NO;
    [spacer.heightAnchor constraintEqualToConstant:[DGTheme scaled:32]].active = YES;
    [self.rootStack addArrangedSubview:spacer];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reload)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];

    DGLog(@"界面", @"viewDidLoad 完成，开始构建内容");
    [self reload];
    DGLog(@"界面", @"viewDidLoad 全部完成");
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reload];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// ===========================================================================
//  构建
// ===========================================================================

- (void)reload {
    if (!self.isViewLoaded) return;
    DGLog(@"界面", @"reload 开始（列表模式=%d）", (int)[self isInListMode]);

    // 搜索框只在 App 列表里显示
    self.appSearchBox.hidden = ![self isInListMode];
    if (![self isInListMode] && self.appSearchBar.text.length) {
        self.appSearchBar.text = @"";
        self.appQuery = nil;
    }

    for (UIView *v in [self.contentStack.arrangedSubviews copy]) {
        [self.contentStack removeArrangedSubview:v];
        [v removeFromSuperview];
    }

    if ([self isInListMode]) {
        [self buildAppList];
        return;
    }

    NSDictionary *prefs = DGReadPrefs();

    BOOL masterOn   = DGPrefBool(prefs, DG_KEY_ENABLED, YES);
    BOOL dnsOn      = DGPrefBool(prefs, DG_KEY_DNSBLOCK, NO);
    BOOL adSkipOn   = DGPrefBool(prefs, DG_KEY_ADSKIP, NO);
    BOOL shakeOn    = DGPrefBool(prefs, DG_KEY_SHAKE, YES);
    BOOL redirectOn = DGPrefBool(prefs, DG_KEY_REDIRECT, YES);
    BOOL sensorOn   = DGPrefBool(prefs, DG_KEY_SENSOR, YES);


    // 徽标
    if (masterOn) {
        NSUInteger active = 0;
        if (dnsOn) active++;
        if (adSkipOn) active++;
        if (shakeOn) active++;
        if (redirectOn) active++;
        if (sensorOn) active++;
        [self.hero setBadgeText:[NSString stringWithFormat:@"%lu 个模块运行中",
                                 (unsigned long)active]];
    } else {
        [self.hero setBadgeText:@"已全部关闭"];
    }

    __weak typeof(self) ws = self;

    // ---- 总开关 ----
    [self addSection:@"总开关" color:[DGTheme primaryPink]
              footer:@"关闭后，以下所有功能都不生效。"];
    [self addSwitch:@"启用 DualGuard" key:DG_KEY_ENABLED value:masterOn];
    [self endSection];

    // ---- 按 App 配置（统一入口）----
    NSUInteger overrideCount = DGPerAppOverrideCount();
    [self addSection:@"按 App 配置" color:[DGTheme accentPurple]
              footer:@"进入后可以选一个 App，单独设置它的每一项功能。\n"
                     @"比如：让某个 App 完全放行跳转，但保留广告拦截。"];
    [self addLink:@"配置 App"
            badge:(overrideCount ? [NSString stringWithFormat:@"%lu", (unsigned long)overrideCount] : nil)
           action:^{
        typeof(self) ss = ws;
        if (!ss) return;
        ss.showingAppList = YES;
        ss.showingAdAppList = NO;
        ss.title = @"选择 App";
        // 每次进来都从完整列表开始，不带上次的搜索词
        ss.appQuery = nil;
        ss.appSearchBar.text = @"";
        ss.navigationItem.rightBarButtonItem = [ss backItem];
        if (!ss.allApps) ss.allApps = DGInstalledApps();
        [ss reload];
    }];
    [self endSection];

    // ---- DNS ----
    [self addSection:@"DNS 广告拦截" color:[DGTheme accentCyan]
              footer:@"从域名解析层阻止广告，对任何 App 都有效，不需要 root。\n"
                     @"开启后需要重启目标 App 才会生效。\n\n"
                     @"拦截记录写在日志里（DNS拦截 关键字），\n"
                     @"路径：/var/mobile/Documents/test/DualGuard.log"];
    [self addSwitch:@"启用 DNS 拦截" key:DG_KEY_DNSBLOCK value:dnsOn];
    [self addLink:@"查看规则数" badge:nil action:^{
        // 设置 App 自己进程里的规则条数（只是展示，说明规则表已加载）
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *logPath = @"/rootfs/private/var/mobile/Documents/test/DualGuard.log";
        NSString *msg;
        if ([fm fileExistsAtPath:logPath]) {
            NSDictionary *attr = [fm attributesOfItemAtPath:logPath error:NULL];
            unsigned long long sz = [attr fileSize];
            msg = [NSString stringWithFormat:
                   @"日志文件 %.1f KB\n\n点开 Filza 到\n"
                   @"/var/mobile/Documents/test/\n查看 DualGuard.log",
                   sz / 1024.0];
        } else {
            msg = @"日志还没生成。\n\n先打开一个有广告的 App，\n"
                   @"触发一次拦截后再回来看。";
        }
        UIAlertController *a = [UIAlertController
                                alertControllerWithTitle:@"DNS 拦截日志"
                                                 message:msg
                                          preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"好"
                                              style:UIAlertActionStyleDefault
                                            handler:nil]];
        [ws presentViewController:a animated:YES completion:nil];
    }];
    [self endSection];

    // ---- 广告跳过 ----
    [self addSection:@"广告自动跳过" color:[DGTheme accentPurple]
              footer:@"先确认屏幕上确实有广告，再在广告里找跳过按钮。\n"
                     @"找不到广告证据时一个都不点，避免误触正常界面。"];
    [self addSwitch:@"启用自动跳过" key:DG_KEY_ADSKIP value:adSkipOn];
    [self addSwitch:@"激进模式" key:DG_KEY_ADSKIP_AGGR
              value:DGPrefBool(prefs, DG_KEY_ADSKIP_AGGR, NO)];
    [self endSection];

    // ---- 摇一摇 ----
    double win = 15;
    id wv = prefs[DG_KEY_SHAKE_WINDOW];
    if (wv) {
        double d = [wv doubleValue];
        if (d > 0 && d <= 120) win = d;
    }
    [self addSection:@"摇一摇拦截" color:[DGTheme accentYellow]
              footer:[NSString stringWithFormat:
                      @"「摇一摇」广告是误触重灾区：拿手机稍一晃就跳到 App Store。\n"
                      @"本功能只拦 App 启动后前 %.0f 秒，之后放行。", win]];
    [self addSwitch:@"拦截摇一摇跳转" key:DG_KEY_SHAKE value:shakeOn];
    [self addStepper:@"拦截时长（秒）" value:win min:5 max:60 step:5
              onStep:^(double v) {
        NSMutableDictionary *p = DGReadPrefs();
        p[DG_KEY_SHAKE_WINDOW] = @(v);
        DGWritePrefs(p);
    }];
    [self endSection];

    // ---- 跳转拦截 ----
    [self addSection:@"跳转拦截" color:[DGTheme primaryBlue]
              footer:@"阻止 App 自动跳转到 App Store、网页或外部应用。"];
    [self addSwitch:@"启用跳转拦截" key:DG_KEY_REDIRECT value:redirectOn];
    [self addSwitch:@"拦截 App Store" key:DG_KEY_BLOCK_STORE
              value:DGPrefBool(prefs, DG_KEY_BLOCK_STORE, YES)];
    [self addSwitch:@"拦截 Safari" key:DG_KEY_BLOCK_SAFARI
              value:DGPrefBool(prefs, DG_KEY_BLOCK_SAFARI, YES)];
    [self addSwitch:@"拦截其他浏览器" key:DG_KEY_BLOCK_OTHERS
              value:DGPrefBool(prefs, DG_KEY_BLOCK_OTHERS, NO)];
    [self addSwitch:@"拦截网页跳转" key:DG_KEY_BLOCK_WEB
              value:DGPrefBool(prefs, DG_KEY_BLOCK_WEB, NO)];
    [self addSwitch:@"拦截其他 App 跳转" key:DG_KEY_BLOCK_OTHERAPPS
              value:DGPrefBool(prefs, DG_KEY_BLOCK_OTHERAPPS, NO)];
    [self addSwitch:@"拦截所有外部跳转" key:DG_KEY_BLOCK_ALLJUMPS
              value:DGPrefBool(prefs, DG_KEY_BLOCK_ALLJUMPS, NO)];
    [self endSection];

    // ---- 传感器 ----
    [self addSection:@"传感器屏蔽" color:[DGTheme accentCyan]
              footer:@"「总开关」关掉则下面全部放行。\n"
                     @"指南针走的是定位接口，和运动传感器不是同一条路径，\n"
                     @"所以单独列出来。"];
    [self addSwitch:@"启用传感器屏蔽" key:DG_KEY_SENSOR value:sensorOn];
    [self addSwitch:@"加速度计" key:DG_KEY_SENSOR_ACCEL
              value:DGPrefBool(prefs, DG_KEY_SENSOR_ACCEL, YES)];
    [self addSwitch:@"陀螺仪" key:DG_KEY_SENSOR_GYRO
              value:DGPrefBool(prefs, DG_KEY_SENSOR_GYRO, YES)];
    [self addSwitch:@"磁力计" key:DG_KEY_SENSOR_MAG
              value:DGPrefBool(prefs, DG_KEY_SENSOR_MAG, YES)];
    [self addSwitch:@"设备姿态" key:DG_KEY_SENSOR_MOTION
              value:DGPrefBool(prefs, DG_KEY_SENSOR_MOTION, YES)];
    [self addSwitch:@"指南针" key:DG_KEY_SENSOR_COMPASS
              value:DGPrefBool(prefs, DG_KEY_SENSOR_COMPASS, YES)];
    [self addSwitch:@"定位航向" key:DG_KEY_SENSOR_LOCATION
              value:DGPrefBool(prefs, DG_KEY_SENSOR_LOCATION, YES)];
    [self endSection];

    // ---- 权限伪装 ----
    BOOL permOn = DGPrefBool(prefs, DGKeyPermEnabled, NO);
    [self addSection:@"权限伪装" color:[DGTheme accentPurple]
              footer:@"让 App 以为已经拿到权限，系统授权框不会弹。\n"
                     @"但 App 读到的数据是空的 —— 相册没照片、通讯录没联系人。\n\n"
                     @"和「拒绝权限」的区别：App 不会显示「无权限」引导页，\n"
                     @"界面照常能用，只是里面没内容。\n\n"
                     @"⚠️ 这是假授权，不是安全边界。防的是正常 App 过度采集，\n"
                     @"防不住有代码执行能力的针对性攻击。"];
    [self addSwitch:@"启用权限伪装" key:DGKeyPermEnabled value:permOn];
    [self addSwitch:@"相册" key:DGKeyPermPhotos
              value:DGPrefBool(prefs, DGKeyPermPhotos, YES)];
    [self addSwitch:@"通讯录" key:DGKeyPermContacts
              value:DGPrefBool(prefs, DGKeyPermContacts, YES)];
    [self addSwitch:@"日历" key:DGKeyPermCalendar
              value:DGPrefBool(prefs, DGKeyPermCalendar, YES)];
    [self addSwitch:@"提醒事项" key:DGKeyPermReminders
              value:DGPrefBool(prefs, DGKeyPermReminders, YES)];
    [self addSwitch:@"麦克风" key:DGKeyPermMicrophone
              value:DGPrefBool(prefs, DGKeyPermMicrophone, YES)];
    [self addSwitch:@"摄像头" key:DGKeyPermCamera
              value:DGPrefBool(prefs, DGKeyPermCamera, YES)];
    [self addSwitch:@"定位" key:DGKeyPermLocation
              value:DGPrefBool(prefs, DGKeyPermLocation, YES)];
    [self addSwitch:@"蓝牙" key:DGKeyPermBluetooth
              value:DGPrefBool(prefs, DGKeyPermBluetooth, YES)];
    [self addSwitch:@"健康" key:DGKeyPermHealth
              value:DGPrefBool(prefs, DGKeyPermHealth, YES)];
    [self addSwitch:@"通知" key:DGKeyPermNotifications
              value:DGPrefBool(prefs, DGKeyPermNotifications, YES)];
    [self endSection];

    // ---- 快捷操作 ----
    [self addSection:@"快捷操作" color:[DGTheme accentPurple]
              footer:@"「全部启用」会打开所有拦截开关。「重置」会清空所有 App 的单独设置。"];
    [self addButton:@"全部启用" destructive:NO action:^{ [ws applyAllEnabled:YES]; }];
    [self addButton:@"全部关闭" destructive:NO action:^{ [ws applyAllEnabled:NO]; }];
    [self addButton:@"重置所有配置" destructive:YES action:^{ [ws confirmReset]; }];
    [self endSection];

    // ---- 关于 ----
    [self addSection:@"关于" color:[DGTheme textSecondary]
              footer:@"DualGuard 3.7.0\n\n"
                     @"作者 QQ：2836226951\n"
                     @"交流群：724179606\n\n"
                     @"本软件仅供学习交流使用。\n"
                     @"改动配置后需重启对应 App 才会生效。"];
    [self endSection];

    DGLog(@"界面", @"reload 完成，共 %lu 个视图",
          (unsigned long)self.contentStack.arrangedSubviews.count);
}

// ---- 分组构建 ----

- (void)addSection:(NSString *)title color:(UIColor *)color footer:(NSString *)footer {
    // 分组之间留白（第一个不加）
    if (self.contentStack.arrangedSubviews.count > 0) {
        UIView *gap = [[UIView alloc] init];
        gap.translatesAutoresizingMaskIntoConstraints = NO;
        [gap.heightAnchor constraintEqualToConstant:[DGTheme scaled:8]].active = YES;
        [self.contentStack addArrangedSubview:gap];
    }

    // 标题行：色条 + 文字
    UIView *headBox = [[UIView alloc] init];
    headBox.translatesAutoresizingMaskIntoConstraints = NO;

    UIView *bar = [[UIView alloc] init];
    bar.backgroundColor = color ?: [DGTheme primaryPink];
    bar.layer.cornerRadius = 2;
    bar.translatesAutoresizingMaskIntoConstraints = NO;
    [headBox addSubview:bar];

    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.font = [DGTheme fontSectionTitle];
    label.textColor = [DGTheme textPrimary];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    [headBox addSubview:label];

    [NSLayoutConstraint activateConstraints:@[
        [bar.leadingAnchor constraintEqualToAnchor:headBox.leadingAnchor],
        [bar.centerYAnchor constraintEqualToAnchor:label.centerYAnchor],
        [bar.widthAnchor constraintEqualToConstant:[DGTheme scaled:3]],
        [bar.heightAnchor constraintEqualToConstant:[DGTheme scaled:16]],

        [label.leadingAnchor constraintEqualToAnchor:bar.trailingAnchor constant:[DGTheme scaled:8]],
        [label.trailingAnchor constraintLessThanOrEqualToAnchor:headBox.trailingAnchor],
        [label.topAnchor constraintEqualToAnchor:headBox.topAnchor constant:[DGTheme scaled:20]],
        [label.bottomAnchor constraintEqualToAnchor:headBox.bottomAnchor constant:-[DGTheme scaled:8]],
    ]];

    [self.contentStack addArrangedSubview:headBox];

    // 卡片
    UIStackView *card = [[UIStackView alloc] init];
    card.axis = UILayoutConstraintAxisVertical;
    card.spacing = 0;
    card.alignment = UIStackViewAlignmentFill;
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DGTheme cardBackground];
    card.layer.cornerRadius = [DGTheme cardCornerRadius];
    card.layer.cornerCurve = kCACornerCurveContinuous;
    card.layer.masksToBounds = YES;
    card.layer.borderWidth = 0.5;
    // borderColor 直接赋给 CALayer setter，setter 会 retain，安全
    card.layer.borderColor = [[DGTheme primaryPink] colorWithAlphaComponent:0.15].CGColor;

    [self.contentStack addArrangedSubview:card];
    self.currentCard = card;

    // 说明文字
    if (footer.length) {
        UILabel *fl = [[UILabel alloc] init];
        fl.text = footer;
        fl.font = [DGTheme fontFooter];
        fl.textColor = [DGTheme textSecondary];
        fl.numberOfLines = 0;
        fl.translatesAutoresizingMaskIntoConstraints = NO;

        UIView *box = [[UIView alloc] init];
        box.translatesAutoresizingMaskIntoConstraints = NO;
        [box addSubview:fl];

        CGFloat inset = [DGTheme scaled:6];
        [NSLayoutConstraint activateConstraints:@[
            [fl.leadingAnchor constraintEqualToAnchor:box.leadingAnchor constant:inset],
            [fl.trailingAnchor constraintEqualToAnchor:box.trailingAnchor constant:-inset],
            [fl.topAnchor constraintEqualToAnchor:box.topAnchor constant:[DGTheme scaled:8]],
            [fl.bottomAnchor constraintEqualToAnchor:box.bottomAnchor constant:-[DGTheme scaled:4]],
        ]];
        [self.contentStack addArrangedSubview:box];
    }
}

- (void)endSection {
    self.currentCard = nil;
}

// 往卡片加一行，自动插分隔线
- (void)appendRow:(UIView *)row {
    if (!self.currentCard || !row) return;

    if (self.currentCard.arrangedSubviews.count > 0) {
        UIView *sepBox = [[UIView alloc] init];
        sepBox.translatesAutoresizingMaskIntoConstraints = NO;

        UIView *sep = [[UIView alloc] init];
        sep.backgroundColor = [[DGTheme textTertiary] colorWithAlphaComponent:0.22];
        sep.translatesAutoresizingMaskIntoConstraints = NO;
        [sepBox addSubview:sep];

        CGFloat pad = [DGTheme cardInnerPadding];
        [NSLayoutConstraint activateConstraints:@[
            [sep.leadingAnchor constraintEqualToAnchor:sepBox.leadingAnchor constant:pad],
            [sep.trailingAnchor constraintEqualToAnchor:sepBox.trailingAnchor constant:-pad],
            [sep.topAnchor constraintEqualToAnchor:sepBox.topAnchor],
            [sep.bottomAnchor constraintEqualToAnchor:sepBox.bottomAnchor],
            [sepBox.heightAnchor constraintEqualToConstant:0.5],
        ]];
        [self.currentCard addArrangedSubview:sepBox];
    }

    [self.currentCard addArrangedSubview:row];
}

// ---- 具体行 ----

- (void)addSwitch:(NSString *)title key:(NSString *)key value:(BOOL)value {
    DGRowView *row = [[DGRowView alloc] initWithKind:DGRowKindSwitch title:title];
    row.key = key;
    row.toggle.on = value;
    __weak typeof(self) ws = self;
    row.onToggle = ^(BOOL on) {
        NSMutableDictionary *p = DGReadPrefs();
        p[key] = @(on);
        DGWritePrefs(p);
        if ([key isEqualToString:DG_KEY_ENABLED]) [ws reload];
    };
    [self appendRow:row];
}

- (void)addStepper:(NSString *)title value:(double)value
               min:(double)min max:(double)max step:(double)step
            onStep:(void (^)(double))onStep {
    DGRowView *row = [[DGRowView alloc] initWithKind:DGRowKindStepper title:title];
    row.stepper.minimumValue = min;
    row.stepper.maximumValue = max;
    row.stepper.stepValue = step;
    row.stepper.value = value;
    row.valueLabel.text = [NSString stringWithFormat:@"%.0f", value];
    row.onStep = onStep;
    [self appendRow:row];
}

- (void)addLink:(NSString *)title badge:(NSString *)badge action:(void (^)(void))action {
    DGRowView *row = [[DGRowView alloc] initWithKind:DGRowKindLink title:title];
    [row setBadgeText:badge];
    row.onTap = action;
    [self appendRow:row];
}

- (void)addButton:(NSString *)title destructive:(BOOL)destructive action:(void (^)(void))action {
    DGRowView *row = [[DGRowView alloc] initWithKind:DGRowKindButton title:title];
    if (destructive) row.titleLabel.textColor = [UIColor systemRedColor];
    row.onTap = action;
    [self appendRow:row];
}

// ---- App 列表 ----

- (void)buildAppList {
    // 统一的 App 列表：点任意一项进入该 App 的全功能配置页
    [self addSection:@"选择 App"
               color:[DGTheme primaryPink]
              footer:@"点击任意 App 进入它的配置页，可以单独开关每一项功能。"];

    __weak typeof(self) ws = self;

    NSArray *apps = [self filteredApps];

    if (apps.count == 0) {
        NSString *q = [self.appQuery
                       stringByTrimmingCharactersInSet:
                       [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        BOOL searching = (q.length > 0);
        UILabel *empty = [[UILabel alloc] init];
        empty.text = searching ? @"没有匹配的 App" : @"没有找到可设置的 App";
        empty.font = [DGTheme fontFooter];
        empty.textColor = [DGTheme textTertiary];
        empty.textAlignment = NSTextAlignmentCenter;
        empty.translatesAutoresizingMaskIntoConstraints = NO;
        [empty.heightAnchor constraintEqualToConstant:[DGTheme scaled:60]].active = YES;
        [self.currentCard addArrangedSubview:empty];
        [self endSection];
        return;
    }

    // 搜索结果数量提示
    if (self.appQuery.length) {
        UILabel *hint = [[UILabel alloc] init];
        hint.text = [NSString stringWithFormat:@"找到 %lu 个 App",
                     (unsigned long)apps.count];
        hint.font = [DGTheme fontFooter];
        hint.textColor = [DGTheme textTertiary];
        hint.translatesAutoresizingMaskIntoConstraints = NO;
        UIView *hbox = [[UIView alloc] init];
        hbox.translatesAutoresizingMaskIntoConstraints = NO;
        [hbox addSubview:hint];
        CGFloat hi = [DGTheme scaled:6];
        [NSLayoutConstraint activateConstraints:@[
            [hint.leadingAnchor constraintEqualToAnchor:hbox.leadingAnchor constant:hi],
            [hint.topAnchor constraintEqualToAnchor:hbox.topAnchor constant:[DGTheme scaled:2]],
            [hint.bottomAnchor constraintEqualToAnchor:hbox.bottomAnchor constant:-[DGTheme scaled:6]],
        ]];
        [self.currentCard addArrangedSubview:hbox];
    }

    for (NSDictionary *app in apps) {
        NSString *bid = app[@"id"];
        NSString *name = app[@"name"];
        if (!bid.length) continue;

        // 显示这个 App 有几项自定义
        BOOL hasOverride = DGPerAppHasAnyOverride(bid);

        DGRowView *row = [[DGRowView alloc] initWithKind:DGRowKindLink title:name];
        [row setSubtitle:hasOverride ? [bid stringByAppendingString:@"  ·  已自定义"] : bid];

        if (hasOverride) {
            [row setBadgeText:@"改"];
        }

        row.onTap = ^{
            typeof(self) ss = ws;
            if (!ss) return;

            DGAppConfigPage *page = [[DGAppConfigPage alloc] initWithBundleID:bid
                                                                      appName:name];
            page.delegate = ss;
            [ss.navigationController pushViewController:page animated:YES];
        };

        [self appendRow:row];
    }

    [self endSection];
}

// ---- 搜索 ----

// 按名称或 bundle ID 过滤。空查询返回全部。
- (NSArray *)filteredApps {
    NSArray *all = self.allApps ?: @[];
    NSString *q = [self.appQuery
                   stringByTrimmingCharactersInSet:
                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (!q.length) return all;

    NSMutableArray *hit = [NSMutableArray array];
    for (NSDictionary *app in all) {
        NSString *name = app[@"name"] ?: @"";
        NSString *bid  = app[@"id"] ?: @"";
        // localizedCaseInsensitiveContainsString 对中文名也按字符匹配
        if ([name localizedCaseInsensitiveContainsString:q] ||
            [bid  localizedCaseInsensitiveContainsString:q]) {
            [hit addObject:app];
        }
    }
    return hit;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    self.appQuery = searchText;
    // 只重建列表，不动搜索框本身（它在 rootStack 里，不受 reload 影响）
    [self reload];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    // minimal 样式默认不显示取消按钮，编辑时才露出来
    [searchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    [searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    searchBar.text = @"";
    self.appQuery = nil;
    [searchBar resignFirstResponder];
    [self reload];
}

// ---- DGAppConfigPageDelegate ----

- (void)appConfigPageDidChange:(DGAppConfigPage *)page {
    // 从配置页返回后刷新列表（徽标可能变了）
    if ([self isInListMode]) [self reload];
}

// ---- 导航 ----

- (UIBarButtonItem *)backItem {
    return [[UIBarButtonItem alloc] initWithTitle:@"返回"
                                            style:UIBarButtonItemStylePlain
                                           target:self
                                           action:@selector(goBack)];
}

- (void)goBack {
    [self.appSearchBar resignFirstResponder];
    self.showingAppList = NO;
    self.showingAdAppList = NO;
    self.title = @"DualGuard";
    self.navigationItem.rightBarButtonItem = nil;
    [self reload];
}

// ---- 操作 ----

- (void)applyAllEnabled:(BOOL)on {
    NSMutableDictionary *p = DGReadPrefs();
    for (NSString *k in @[DG_KEY_ENABLED, DG_KEY_SENSOR, DG_KEY_REDIRECT,
                          DG_KEY_BLOCK_STORE, DG_KEY_BLOCK_SAFARI]) {
        p[k] = @(on);
    }
    DGWritePrefs(p);
    [self reload];
}

- (void)confirmReset {
    UIAlertController *a = [UIAlertController
        alertControllerWithTitle:@"重置所有配置"
                         message:@"会清空所有 App 的单独设置和所有开关状态，无法撤销。"
                  preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    __weak typeof(self) ws = self;
    [a addAction:[UIAlertAction actionWithTitle:@"重置"
                                          style:UIAlertActionStyleDestructive
                                        handler:^(UIAlertAction *act) {
        NSDictionary *old = DGReadPrefs();
        NSMutableDictionary *fresh = [NSMutableDictionary dictionary];
        for (NSString *k in old) {
            if (![k hasPrefix:DG_KEY_SENSOR_PREFIX] && ![k hasPrefix:DG_KEY_ADSKIP_PREFIX]) {
                fresh[k] = old[k];
            }
        }
        DGWritePrefs(fresh);
        [ws reload];
    }]];
    [self presentViewController:a animated:YES completion:nil];
}

@end
