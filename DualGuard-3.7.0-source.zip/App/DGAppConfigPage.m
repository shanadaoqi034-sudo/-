//
//  DGAppConfigPage.m — 单个 App 的全功能配置页
//

#import "DGAppConfigPage.h"
#import "DGTheme.h"
#import "DGLog.h"
#import "DGPerApp.h"
#import "DGCore.h"
#import "DGPermission.h"

#define DG_KEY_ENABLED          @"Enabled"
#define DG_KEY_SENSOR           @"SensorEnabled"

// ---- 传感器细分（3.6.0）----
#define DG_KEY_SENSOR_ACCEL     @"SensorAccelEnabled"
#define DG_KEY_SENSOR_GYRO      @"SensorGyroEnabled"
#define DG_KEY_SENSOR_MAG       @"SensorMagEnabled"
#define DG_KEY_SENSOR_MOTION    @"SensorMotionEnabled"
#define DG_KEY_SENSOR_COMPASS   @"SensorCompassEnabled"
#define DG_KEY_SENSOR_LOCATION  @"SensorLocationEnabled"

// ---- 权限伪装（3.7.0）----
#define DGKeyPermEnabled        @"PermFakeEnabled"
#define DGKeyPermPhotos         @"PermFakePhotos"
#define DGKeyPermContacts       @"PermFakeContacts"
#define DGKeyPermCalendar       @"PermFakeCalendar"
#define DGKeyPermReminders      @"PermFakeReminders"
#define DGKeyPermMicrophone     @"PermFakeMicrophone"
#define DGKeyPermCamera         @"PermFakeCamera"
#define DGKeyPermLocation       @"PermFakeLocation"
#define DGKeyPermBluetooth      @"PermFakeBluetooth"
#define DGKeyPermHealth         @"PermFakeHealth"
#define DGKeyPermNotifications  @"PermFakeNotifications"


#define DG_KEY_REDIRECT         @"RedirectEnabled"
#define DG_KEY_BLOCK_STORE      @"BlockAppStore"
#define DG_KEY_BLOCK_SAFARI     @"BlockSafari"
#define DG_KEY_BLOCK_OTHERS     @"BlockOthers"
#define DG_KEY_BLOCK_WEB        @"BlockWeb"
#define DG_KEY_BLOCK_OTHERAPPS  @"BlockOtherApps"
#define DG_KEY_BLOCK_ALLJUMPS   @"BlockAllJumps"
#define DG_KEY_ADSKIP           @"AdSkipEnabled"
#define DG_KEY_DNSBLOCK         @"DNSBlockEnabled"
#define DG_KEY_SHAKE            @"ShakeBlockEnabled"

// ===========================================================================
//  行视图
// ===========================================================================

typedef NS_ENUM(NSInteger, DGCfgRowKind) {
    DGCfgRowKindSwitch = 0,
    DGCfgRowKindButton,
    DGCfgRowKindInfo,
};

@interface DGCfgRow : UIView
@property (nonatomic) DGCfgRowKind kind;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UISwitch *toggle;
@property (nonatomic, strong) NSString *feature;
@property (nonatomic, strong) NSString *globalKey;
@property (nonatomic, copy) void (^onToggle)(BOOL on);
@property (nonatomic, copy) void (^onTap)(void);
@end

@implementation DGCfgRow

- (instancetype)initWithKind:(DGCfgRowKind)kind title:(NSString *)title {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;

    _kind = kind;
    self.translatesAutoresizingMaskIntoConstraints = NO;

    CGFloat pad = [DGTheme cardInnerPadding];
    CGFloat minH = [DGTheme rowMinHeight];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.text = title;
    _titleLabel.font = [DGTheme fontRowLabel];
    _titleLabel.textColor = [DGTheme textPrimary];
    _titleLabel.numberOfLines = 0;
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [_titleLabel setContentCompressionResistancePriority:UILayoutPriorityDefaultHigh
                                                 forAxis:UILayoutConstraintAxisHorizontal];
    [self addSubview:_titleLabel];

    UIView *rightView = nil;

    if (kind == DGCfgRowKindSwitch) {
        _toggle = [[UISwitch alloc] init];
        _toggle.onTintColor = [DGTheme primaryPink];
        _toggle.translatesAutoresizingMaskIntoConstraints = NO;
        [_toggle addTarget:self action:@selector(handleToggle:)
          forControlEvents:UIControlEventValueChanged];
        [self addSubview:_toggle];
        rightView = _toggle;
    } else if (kind == DGCfgRowKindButton) {
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.textColor = [DGTheme primaryPink];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                       initWithTarget:self action:@selector(handleTap)];
        [self addGestureRecognizer:tap];
        self.userInteractionEnabled = YES;
    } else {
        _titleLabel.font = [DGTheme fontFooter];
        _titleLabel.textColor = [DGTheme textSecondary];
    }

    NSMutableArray *cs = [NSMutableArray array];
    [cs addObject:[self.heightAnchor constraintGreaterThanOrEqualToConstant:minH]];
    [cs addObject:[_titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:pad]];
    [cs addObject:[_titleLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]];
    [cs addObject:[_titleLabel.topAnchor constraintGreaterThanOrEqualToAnchor:self.topAnchor
                                                                   constant:[DGTheme scaled:12]]];
    [cs addObject:[_titleLabel.bottomAnchor constraintLessThanOrEqualToAnchor:self.bottomAnchor
                                                                    constant:-[DGTheme scaled:12]]];

    if (rightView) {
        [cs addObject:[rightView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-pad]];
        [cs addObject:[rightView.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]];
        [cs addObject:[_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:rightView.leadingAnchor
                                                                          constant:-[DGTheme scaled:8]]];
    } else {
        [cs addObject:[_titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-pad]];
    }

    [NSLayoutConstraint activateConstraints:cs];
    return self;
}

- (void)handleToggle:(UISwitch *)sender {
    if (self.onToggle) self.onToggle(sender.on);
}

- (void)handleTap {
    if (self.onTap) self.onTap();
}

- (void)setSubtitle:(NSString *)text {
    if (!text.length) return;
    if (!_subtitleLabel) {
        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.font = [DGTheme fontFooter];
        _subtitleLabel.textColor = [DGTheme textTertiary];
        _subtitleLabel.numberOfLines = 0;
        _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_subtitleLabel];
        [NSLayoutConstraint activateConstraints:@[
            [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
            [_subtitleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:self.trailingAnchor
                                                                    constant:-[DGTheme cardInnerPadding]],
            [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:2],
            [_subtitleLabel.bottomAnchor constraintLessThanOrEqualToAnchor:self.bottomAnchor
                                                                  constant:-[DGTheme scaled:10]],
        ]];
        for (NSLayoutConstraint *c in self.constraints) {
            if (c.firstItem == _titleLabel && c.firstAttribute == NSLayoutAttributeCenterY) {
                c.active = NO;
                break;
            }
        }
        [_titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor
                                              constant:[DGTheme scaled:10]].active = YES;
    }
    _subtitleLabel.text = text;
}

@end

// ===========================================================================
//  配置页
// ===========================================================================

@interface DGAppConfigPage ()
@property (nonatomic, strong) NSString *bundleID;
@property (nonatomic, strong) NSString *appName;
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) UIStackView *rootStack;
@property (nonatomic, strong) UIStackView *contentStack;
@property (nonatomic, strong) UIStackView *currentCard;
@end

@implementation DGAppConfigPage

- (instancetype)initWithBundleID:(NSString *)bundleID appName:(NSString *)appName {
    self = [super init];
    if (!self) return nil;
    _bundleID = [bundleID copy];
    _appName = [appName copy];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = self.appName.length ? self.appName : self.bundleID;
    self.view.backgroundColor = [DGTheme background];

    DGLog(@"App配置", @"打开 %@ (%@)", self.appName, self.bundleID);

    self.scroll = [[UIScrollView alloc] init];
    self.scroll.translatesAutoresizingMaskIntoConstraints = NO;
    self.scroll.alwaysBounceVertical = YES;
    [self.view addSubview:self.scroll];

    self.rootStack = [[UIStackView alloc] init];
    self.rootStack.axis = UILayoutConstraintAxisVertical;
    self.rootStack.spacing = 0;
    self.rootStack.alignment = UIStackViewAlignmentFill;
    self.rootStack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.scroll addSubview:self.rootStack];

    [NSLayoutConstraint activateConstraints:@[
        [self.scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],

        [self.rootStack.topAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.topAnchor],
        [self.rootStack.leadingAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.leadingAnchor],
        [self.rootStack.trailingAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.trailingAnchor],
        [self.rootStack.bottomAnchor constraintEqualToAnchor:self.scroll.contentLayoutGuide.bottomAnchor],
        [self.rootStack.widthAnchor constraintEqualToAnchor:self.scroll.frameLayoutGuide.widthAnchor],
    ]];

    CGFloat margin = [DGTheme contentMargin];
    self.contentStack = [[UIStackView alloc] init];
    self.contentStack.axis = UILayoutConstraintAxisVertical;
    self.contentStack.spacing = 0;
    self.contentStack.alignment = UIStackViewAlignmentFill;
    self.contentStack.translatesAutoresizingMaskIntoConstraints = NO;
    self.contentStack.layoutMargins = UIEdgeInsetsMake(0, margin, 0, margin);
    self.contentStack.layoutMarginsRelativeArrangement = YES;
    [self.rootStack addArrangedSubview:self.contentStack];

    UIView *spacer = [[UIView alloc] init];
    spacer.translatesAutoresizingMaskIntoConstraints = NO;
    [spacer.heightAnchor constraintEqualToConstant:[DGTheme scaled:32]].active = YES;
    [self.rootStack addArrangedSubview:spacer];

    [self buildUI];
}

- (void)buildUI {
    __weak typeof(self) ws = self;

    // ---- 头部信息 ----
    [self addSection:@"App 信息" color:[DGTheme primaryBlue] footer:nil];
    DGCfgRow *info = [[DGCfgRow alloc] initWithKind:DGCfgRowKindInfo title:self.appName ?: self.bundleID];
    [info setSubtitle:self.bundleID];
    [self appendRow:info];
    [self endSection];

    // ---- 总开关 ----
    [self addSection:@"总开关" color:[DGTheme primaryPink]
              footer:@"关掉后，这个 App 完全不受 DualGuard 影响（所有功能放行）。"];
    [self addSwitch:@"管辖此 App" feature:DGFeatureMaster
            globalKey:DG_KEY_ENABLED
            globalVal:DGBool(DG_KEY_ENABLED, YES)];
    [self endSection];

    // ---- 广告 ----
    [self addSection:@"广告" color:[DGTheme accentCyan] footer:nil];
    [self addSwitch:@"DNS 广告拦截" feature:DGFeatureDNS
            globalKey:DG_KEY_DNSBLOCK
            globalVal:DGBool(DG_KEY_DNSBLOCK, NO)];
    [self addSwitch:@"广告自动跳过" feature:DGFeatureAdSkip
            globalKey:DG_KEY_ADSKIP
            globalVal:DGBool(DG_KEY_ADSKIP, NO)];
    [self endSection];

    // ---- 传感器 ----
    [self addSection:@"传感器" color:[DGTheme accentYellow]
              footer:@"总开关关掉则下面全部放行。\n指南针走定位接口，和运动传感器是两条路径。"];
    [self addSwitch:@"传感器屏蔽" feature:DGFeatureSensor
            globalKey:DG_KEY_SENSOR
            globalVal:DGBool(DG_KEY_SENSOR, YES)];
    [self addSwitch:@"加速度计" feature:DGFeatureSensorAccel
            globalKey:DG_KEY_SENSOR_ACCEL
            globalVal:DGBool(DG_KEY_SENSOR_ACCEL, YES)];
    [self addSwitch:@"陀螺仪" feature:DGFeatureSensorGyro
            globalKey:DG_KEY_SENSOR_GYRO
            globalVal:DGBool(DG_KEY_SENSOR_GYRO, YES)];
    [self addSwitch:@"磁力计" feature:DGFeatureSensorMag
            globalKey:DG_KEY_SENSOR_MAG
            globalVal:DGBool(DG_KEY_SENSOR_MAG, YES)];
    [self addSwitch:@"设备姿态" feature:DGFeatureSensorMotion
            globalKey:DG_KEY_SENSOR_MOTION
            globalVal:DGBool(DG_KEY_SENSOR_MOTION, YES)];
    [self addSwitch:@"指南针" feature:DGFeatureSensorCompass
            globalKey:DG_KEY_SENSOR_COMPASS
            globalVal:DGBool(DG_KEY_SENSOR_COMPASS, YES)];
    [self addSwitch:@"定位航向" feature:DGFeatureSensorLocation
            globalKey:DG_KEY_SENSOR_LOCATION
            globalVal:DGBool(DG_KEY_SENSOR_LOCATION, YES)];
    [self addSwitch:@"摇一摇拦截" feature:DGFeatureShake
            globalKey:DG_KEY_SHAKE
            globalVal:DGBool(DG_KEY_SHAKE, YES)];
    [self endSection];

    // ---- 跳转拦截 ----
    [self addSection:@"跳转拦截" color:[DGTheme primaryBlue]
              footer:@"每一项都能单独给这个 App 开关。比如只拦 App Store，放行网页。"];
    [self addSwitch:@"跳转拦截（总）" feature:DGFeatureRedirect
            globalKey:DG_KEY_REDIRECT
            globalVal:DGBool(DG_KEY_REDIRECT, YES)];
    [self addSwitch:@"拦截 App Store" feature:DGFeatureStore
            globalKey:DG_KEY_BLOCK_STORE
            globalVal:DGBool(DG_KEY_BLOCK_STORE, YES)];
    [self addSwitch:@"拦截 Safari" feature:DGFeatureSafari
            globalKey:DG_KEY_BLOCK_SAFARI
            globalVal:DGBool(DG_KEY_BLOCK_SAFARI, YES)];
    [self addSwitch:@"拦截其他浏览器" feature:DGFeatureBrowser
            globalKey:DG_KEY_BLOCK_OTHERS
            globalVal:DGBool(DG_KEY_BLOCK_OTHERS, NO)];
    [self addSwitch:@"拦截网页" feature:DGFeatureWeb
            globalKey:DG_KEY_BLOCK_WEB
            globalVal:DGBool(DG_KEY_BLOCK_WEB, NO)];
    [self addSwitch:@"拦截其他 App" feature:DGFeatureOtherApp
            globalKey:DG_KEY_BLOCK_OTHERAPPS
            globalVal:DGBool(DG_KEY_BLOCK_OTHERAPPS, NO)];
    [self addSwitch:@"拦截所有外部跳转" feature:DGFeatureAllJump
            globalKey:DG_KEY_BLOCK_ALLJUMPS
            globalVal:DGBool(DG_KEY_BLOCK_ALLJUMPS, NO)];
    [self endSection];

    // ---- 权限伪装 ----
    [self addSection:@"权限伪装" color:[DGTheme accentPurple]
              footer:@"让这个 App 以为有权限，实际读不到数据。\n"
                     @"总开关关掉则下面全部放行。"];
    [self addSwitch:@"权限伪装（总）" feature:DGFeaturePermPhotos
            globalKey:DGKeyPermEnabled
            globalVal:DGBool(DGKeyPermEnabled, NO)];
    [self addSwitch:@"相册" feature:DGFeaturePermPhotos
            globalKey:DGKeyPermPhotos
            globalVal:DGBool(DGKeyPermPhotos, YES)];
    [self addSwitch:@"通讯录" feature:DGFeaturePermContacts
            globalKey:DGKeyPermContacts
            globalVal:DGBool(DGKeyPermContacts, YES)];
    [self addSwitch:@"日历" feature:DGFeaturePermCalendar
            globalKey:DGKeyPermCalendar
            globalVal:DGBool(DGKeyPermCalendar, YES)];
    [self addSwitch:@"提醒事项" feature:DGFeaturePermReminders
            globalKey:DGKeyPermReminders
            globalVal:DGBool(DGKeyPermReminders, YES)];
    [self addSwitch:@"麦克风" feature:DGFeaturePermMicrophone
            globalKey:DGKeyPermMicrophone
            globalVal:DGBool(DGKeyPermMicrophone, YES)];
    [self addSwitch:@"摄像头" feature:DGFeaturePermCamera
            globalKey:DGKeyPermCamera
            globalVal:DGBool(DGKeyPermCamera, YES)];
    [self addSwitch:@"定位" feature:DGFeaturePermLocation
            globalKey:DGKeyPermLocation
            globalVal:DGBool(DGKeyPermLocation, YES)];
    [self addSwitch:@"蓝牙" feature:DGFeaturePermBluetooth
            globalKey:DGKeyPermBluetooth
            globalVal:DGBool(DGKeyPermBluetooth, YES)];
    [self addSwitch:@"健康" feature:DGFeaturePermHealth
            globalKey:DGKeyPermHealth
            globalVal:DGBool(DGKeyPermHealth, YES)];
    [self addSwitch:@"通知" feature:DGFeaturePermNotifications
            globalKey:DGKeyPermNotifications
            globalVal:DGBool(DGKeyPermNotifications, YES)];
    [self endSection];

    // ---- 操作 ----
    [self addSection:@"操作" color:[DGTheme accentPurple]
              footer:@"「恢复继承全局」会清除这个 App 的所有单独设置，全部改回跟随全局开关。"];
    DGCfgRow *resetRow = [[DGCfgRow alloc] initWithKind:DGCfgRowKindButton
                                                  title:@"恢复继承全局"];
    resetRow.onTap = ^{
        typeof(self) ss = ws;
        if (!ss) return;
        DGPerAppClearAll(ss.bundleID);
        DGLog(@"App配置", @"已清除 %@ 的所有覆盖", ss.bundleID);
        [ss rebuildUI];
        [ss.delegate appConfigPageDidChange:ss];
    };
    [self appendRow:resetRow];
    [self endSection];
}

- (void)rebuildUI {
    for (UIView *v in [self.contentStack.arrangedSubviews copy]) {
        [self.contentStack removeArrangedSubview:v];
        [v removeFromSuperview];
    }
    [self buildUI];
}

// ---- 构建辅助 ----

- (void)addSection:(NSString *)title color:(UIColor *)color footer:(NSString *)footer {
    if (self.contentStack.arrangedSubviews.count > 0) {
        UIView *gap = [[UIView alloc] init];
        gap.translatesAutoresizingMaskIntoConstraints = NO;
        [gap.heightAnchor constraintEqualToConstant:[DGTheme scaled:8]].active = YES;
        [self.contentStack addArrangedSubview:gap];
    }

    UIView *headBox = [[UIView alloc] init];
    headBox.translatesAutoresizingMaskIntoConstraints = NO;

    UIView *bar = [[UIView alloc] init];
    bar.backgroundColor = color ?: [DGTheme primaryPink];
    bar.layer.cornerRadius = 2;
    bar.translatesAutoresizingMaskIntoConstraints = NO;
    [headBox addSubview:bar];

    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.font = [DGTheme fontSectionTitle];
    label.textColor = [DGTheme textPrimary];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    [headBox addSubview:label];

    [NSLayoutConstraint activateConstraints:@[
        [bar.leadingAnchor constraintEqualToAnchor:headBox.leadingAnchor],
        [bar.centerYAnchor constraintEqualToAnchor:label.centerYAnchor],
        [bar.widthAnchor constraintEqualToConstant:[DGTheme scaled:3]],
        [bar.heightAnchor constraintEqualToConstant:[DGTheme scaled:16]],
        [label.leadingAnchor constraintEqualToAnchor:bar.trailingAnchor constant:[DGTheme scaled:8]],
        [label.trailingAnchor constraintLessThanOrEqualToAnchor:headBox.trailingAnchor],
        [label.topAnchor constraintEqualToAnchor:headBox.topAnchor constant:[DGTheme scaled:20]],
        [label.bottomAnchor constraintEqualToAnchor:headBox.bottomAnchor constant:-[DGTheme scaled:8]],
    ]];
    [self.contentStack addArrangedSubview:headBox];

    UIStackView *card = [[UIStackView alloc] init];
    card.axis = UILayoutConstraintAxisVertical;
    card.spacing = 0;
    card.alignment = UIStackViewAlignmentFill;
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [DGTheme cardBackground];
    card.layer.cornerRadius = [DGTheme cardCornerRadius];
    card.layer.cornerCurve = kCACornerCurveContinuous;
    card.layer.masksToBounds = YES;
    card.layer.borderWidth = 0.5;
    card.layer.borderColor = [[DGTheme primaryPink] colorWithAlphaComponent:0.15].CGColor;
    [self.contentStack addArrangedSubview:card];
    self.currentCard = card;

    if (footer.length) {
        UILabel *fl = [[UILabel alloc] init];
        fl.text = footer;
        fl.font = [DGTheme fontFooter];
        fl.textColor = [DGTheme textSecondary];
        fl.numberOfLines = 0;
        fl.translatesAutoresizingMaskIntoConstraints = NO;

        UIView *box = [[UIView alloc] init];
        box.translatesAutoresizingMaskIntoConstraints = NO;
        [box addSubview:fl];
        CGFloat inset = [DGTheme scaled:6];
        [NSLayoutConstraint activateConstraints:@[
            [fl.leadingAnchor constraintEqualToAnchor:box.leadingAnchor constant:inset],
            [fl.trailingAnchor constraintEqualToAnchor:box.trailingAnchor constant:-inset],
            [fl.topAnchor constraintEqualToAnchor:box.topAnchor constant:[DGTheme scaled:8]],
            [fl.bottomAnchor constraintEqualToAnchor:box.bottomAnchor constant:-[DGTheme scaled:4]],
        ]];
        [self.contentStack addArrangedSubview:box];
    }
}

- (void)endSection {
    self.currentCard = nil;
}

- (void)appendRow:(UIView *)row {
    if (!self.currentCard || !row) return;

    if (self.currentCard.arrangedSubviews.count > 0) {
        UIView *sepBox = [[UIView alloc] init];
        sepBox.translatesAutoresizingMaskIntoConstraints = NO;
        UIView *sep = [[UIView alloc] init];
        sep.backgroundColor = [[DGTheme textTertiary] colorWithAlphaComponent:0.22];
        sep.translatesAutoresizingMaskIntoConstraints = NO;
        [sepBox addSubview:sep];
        CGFloat pad = [DGTheme cardInnerPadding];
        [NSLayoutConstraint activateConstraints:@[
            [sep.leadingAnchor constraintEqualToAnchor:sepBox.leadingAnchor constant:pad],
            [sep.trailingAnchor constraintEqualToAnchor:sepBox.trailingAnchor constant:-pad],
            [sep.topAnchor constraintEqualToAnchor:sepBox.topAnchor],
            [sep.bottomAnchor constraintEqualToAnchor:sepBox.bottomAnchor],
            [sepBox.heightAnchor constraintEqualToConstant:0.5],
        ]];
        [self.currentCard addArrangedSubview:sepBox];
    }
    [self.currentCard addArrangedSubview:row];
}

// ---- 开关行 ----

- (void)addSwitch:(NSString *)title feature:(NSString *)feature
        globalKey:(NSString *)globalKey globalVal:(BOOL)globalVal {

    DGCfgRow *row = [[DGCfgRow alloc] initWithKind:DGCfgRowKindSwitch title:title];
    row.feature = feature;
    row.globalKey = globalKey;

    // 当前值：per-App 有覆盖就用覆盖，否则用全局
    BOOL current = DGPerAppBool(feature, self.bundleID, globalVal);
    row.toggle.on = current;

    // 副标题提示：显示是「跟随全局」还是「已单独设置」
    NSString *cfgKey = DGPerAppKey(feature, self.bundleID);
    BOOL hasOverride = (cfgKey != nil) && (DGPreferences()[cfgKey] != nil);
    if (hasOverride) {
        [row setSubtitle:[NSString stringWithFormat:@"已单独设置（全局：%@）",
                          globalVal ? @"开" : @"关"]];
    } else {
        [row setSubtitle:[NSString stringWithFormat:@"跟随全局（%@）",
                          globalVal ? @"开" : @"关"]];
    }

    __weak typeof(self) ws = self;
    row.onToggle = ^(BOOL on) {
        typeof(self) ss = ws;
        if (!ss) return;
        DGPerAppSet(feature, ss.bundleID, on);
        DGLog(@"App配置", @"%@ 的 %@ -> %@", ss.bundleID, feature, on ? @"开" : @"关");
        [ss.delegate appConfigPageDidChange:ss];
    };

    [self appendRow:row];
}

@end
