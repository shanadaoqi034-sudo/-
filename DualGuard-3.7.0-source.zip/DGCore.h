//
//  DGCore.h — 偏好存储层（跳转拦截 + 传感器屏蔽共用）
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString * const DGPreferencesDomain;   // com.deepseek.dualguard
FOUNDATION_EXPORT NSString * const DGChangedNotification;  // Darwin 通知名

// 当前进程的 bundle id
FOUNDATION_EXPORT NSString * DGBundleIdentifier(void);

// 偏好文件路径（/var/mobile/Library/Preferences/<domain>.plist）
FOUNDATION_EXPORT NSString * DGPreferencesFilePath(void);

// 整份偏好快照（带进程内缓存，收到 Darwin 通知后失效）
FOUNDATION_EXPORT NSDictionary * DGPreferences(void);
FOUNDATION_EXPORT void DGInvalidatePreferences(void);

// 读单个布尔值
FOUNDATION_EXPORT BOOL DGBool(NSString *key, BOOL fallback);

// 读「某 App 的某个前缀开关」：prefix + bundleID
FOUNDATION_EXPORT BOOL DGAppBool(NSString *prefix, NSString *bundleID, BOOL fallback);

// 写布尔值（仅供设置面板调用）
FOUNDATION_EXPORT void DGSetBool(NSString *key, BOOL value);

// 删除一个键（恢复继承全局用）
FOUNDATION_EXPORT void DGRemoveKey(NSString *key);

// 广播偏好变化
FOUNDATION_EXPORT void DGPostChanged(void);

// 开始监听 Darwin 通知（进程内只需调用一次）
FOUNDATION_EXPORT void DGStartObserving(void);

// 注册偏好变更回调（在 main queue 上调用）
FOUNDATION_EXPORT void DGRegisterChangeHandler(dispatch_block_t handler);

// 三个总开关的便捷读取
FOUNDATION_EXPORT BOOL DGEnabled(void);
FOUNDATION_EXPORT BOOL DGRedirectEnabled(void);
FOUNDATION_EXPORT BOOL DGSensorEnabled(void);

// 偏好键名
FOUNDATION_EXPORT NSString * const DGKeyEnabled;          // Enabled
FOUNDATION_EXPORT NSString * const DGKeyRedirectEnabled;  // RedirectEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorEnabled;    // SensorEnabled
FOUNDATION_EXPORT NSString * const DGKeyBlockAppStore;    // BlockAppStore
FOUNDATION_EXPORT NSString * const DGKeyBlockSafari;      // BlockSafari
FOUNDATION_EXPORT NSString * const DGKeyBlockOthers;      // BlockOthers
FOUNDATION_EXPORT NSString * const DGKeyBlockWeb;         // BlockWeb（SFSafariViewController 等进程内网页）
FOUNDATION_EXPORT NSString * const DGKeyBlockOtherApps;   // BlockOtherApps（其他 App 的 scheme 跳转）
FOUNDATION_EXPORT NSString * const DGKeyBlockAllJumps;    // BlockAllJumps（任何外部跳转）
FOUNDATION_EXPORT NSString * const DGKeyAdSkipEnabled;    // AdSkipEnabled（自动跳过广告）
FOUNDATION_EXPORT NSString * const DGKeyAdSkipAggressive; // AdSkipAggressive（激进模式）
FOUNDATION_EXPORT NSString * const DGKeyDNSBlock;         // DNSBlockEnabled（DNS 层拦截）
FOUNDATION_EXPORT NSString * const DGKeyShakeBlock;       // ShakeBlockEnabled（摇一摇拦截）
FOUNDATION_EXPORT NSString * const DGKeyShakeWindow;      // ShakeWindow（拦截时间窗口，秒）
FOUNDATION_EXPORT NSString * const DGKeySensorPrefix;

// ---- 传感器细分（3.6.0）----
FOUNDATION_EXPORT NSString * const DGKeySensorAccel;     // SensorAccelEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorGyro;      // SensorGyroEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorMag;       // SensorMagEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorMotion;    // SensorMotionEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorCompass;   // SensorCompassEnabled
FOUNDATION_EXPORT NSString * const DGKeySensorLocation;  // SensorLocationEnabled     // SensorBlocked.
