//
//  Tweak.xm — DualGuard 核心 hook
//
//  ⚠️ 仅供学习交流使用
//  作者 QQ：2836226951    交流群：724179606
//  使用本插件产生的一切后果由使用者自行承担。
//
//  功能：广告拦截（DNS + 自动跳过）/ 跳转拦截 / 传感器屏蔽
//
//  说明：本 tweak 编译为 arm64，注入第三方 App 进程。
//  系统进程（SpringBoard / Settings）是 arm64e，不在此范围内，
//  因此设置界面做成独立 App。
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
#import <CoreLocation/CoreLocation.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import <stdatomic.h>
#import <objc/message.h>
#import <SafariServices/SafariServices.h>
#import <AuthenticationServices/AuthenticationServices.h>
#import <StoreKit/StoreKit.h>
#import "DGCore.h"
#import "DGSensor.h"
#import "DGRedirect.h"
#import "DGAdSkip.h"
#import "DGAdBlock.h"
#import "DGLog.h"
#import "DGPermission.h"

// 权限伪装的 hook 在 DGPermissionHooks.xm
extern void DGInstallPermissionHooks(void);

// ===========================================================================
//  A. 传感器屏蔽
// ===========================================================================

%group SensorHooks

%hook CMMotionManager

// ---- accelerometer --------------------------------------------------------

- (void)startAccelerometerUpdates {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, NO);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{ CMMotionManager *m = weakSelf; if (m) [m startAccelerometerUpdates]; };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindAccelerometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        DGSensorEnterForwarding();
        @try { %orig; } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startAccelerometerUpdatesToQueue:(NSOperationQueue *)queue
                             withHandler:(CMAccelerometerHandler)handler {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, NO);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startAccelerometerUpdatesToQueue:queue withHandler:handler];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindAccelerometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        NSUInteger generation = stream.generation;
        CMAccelerometerHandler filtered = ^(CMAccelerometerData *data, NSError *error) {
            CMMotionManager *m = weakSelf;
            if (!m) return;
            @synchronized (m) {
                DGStream *current = DGSensorStreamFor(m, NO);
                if (!DGSensorBlockedKind(DGSensorKindAccelerometer)
                    && current.active
                    && current.generation == generation
                    && handler) {
                    handler(data, error);
                }
            }
        };
        DGSensorEnterForwarding();
        @try { %orig(queue, filtered); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)stopAccelerometerUpdates {
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, NO);
        stream.active = NO;
        stream.generation++;
        if (!DGSensorIsRevoking()) stream.resume = nil;
        %orig;
    }
}

- (CMAccelerometerData *)accelerometerData {
    if (DGSensorBlockedKind(DGSensorKindAccelerometer)) { DGSensorNoteBlocked(); return nil; }
    return %orig;
}

// ---- deviceMotion ---------------------------------------------------------

- (void)startDeviceMotionUpdates {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{ CMMotionManager *m = weakSelf; if (m) [m startDeviceMotionUpdates]; };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindDeviceMotion)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        DGSensorEnterForwarding();
        @try { %orig; } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startDeviceMotionUpdatesToQueue:(NSOperationQueue *)queue
                            withHandler:(CMDeviceMotionHandler)handler {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startDeviceMotionUpdatesToQueue:queue withHandler:handler];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindDeviceMotion)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        NSUInteger generation = stream.generation;
        CMDeviceMotionHandler filtered = ^(CMDeviceMotion *data, NSError *error) {
            CMMotionManager *m = weakSelf;
            if (!m) return;
            @synchronized (m) {
                DGStream *current = DGSensorStreamFor(m, YES);
                if (!DGSensorBlockedKind(DGSensorKindDeviceMotion)
                    && current.active
                    && current.generation == generation
                    && handler) {
                    handler(data, error);
                }
            }
        };
        DGSensorEnterForwarding();
        @try { %orig(queue, filtered); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startDeviceMotionUpdatesUsingReferenceFrame:(CMAttitudeReferenceFrame)referenceFrame {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startDeviceMotionUpdatesUsingReferenceFrame:referenceFrame];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindGyro)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        DGSensorEnterForwarding();
        @try { %orig(referenceFrame); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startDeviceMotionUpdatesUsingReferenceFrame:(CMAttitudeReferenceFrame)referenceFrame
                                            toQueue:(NSOperationQueue *)queue
                                        withHandler:(CMDeviceMotionHandler)handler {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startDeviceMotionUpdatesUsingReferenceFrame:referenceFrame
                                                          toQueue:queue
                                                      withHandler:handler];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindGyro)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        NSUInteger generation = stream.generation;
        CMDeviceMotionHandler filtered = ^(CMDeviceMotion *data, NSError *error) {
            CMMotionManager *m = weakSelf;
            if (!m) return;
            @synchronized (m) {
                DGStream *current = DGSensorStreamFor(m, YES);
                if (!DGSensorBlockedKind(DGSensorKindGyro)
                    && current.active
                    && current.generation == generation
                    && handler) {
                    handler(data, error);
                }
            }
        };
        DGSensorEnterForwarding();
        @try { %orig(referenceFrame, queue, filtered); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)stopDeviceMotionUpdates {
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        stream.active = NO;
        stream.generation++;
        if (!DGSensorIsRevoking()) stream.resume = nil;
        %orig;
    }
}

- (CMDeviceMotion *)deviceMotion {
    if (DGSensorBlockedKind(DGSensorKindDeviceMotion)) { DGSensorNoteBlocked(); return nil; }
    return %orig;
}

// ---- gyro -----------------------------------------------------------------

- (void)startGyroUpdates {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{ CMMotionManager *m = weakSelf; if (m) [m startGyroUpdates]; };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindMagnetometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        DGSensorEnterForwarding();
        @try { %orig; } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startGyroUpdatesToQueue:(NSOperationQueue *)queue withHandler:(CMGyroHandler)handler {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startGyroUpdatesToQueue:queue withHandler:handler];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindMagnetometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        NSUInteger generation = stream.generation;
        CMGyroHandler filtered = ^(CMGyroData *data, NSError *error) {
            CMMotionManager *m = weakSelf;
            if (!m) return;
            @synchronized (m) {
                DGStream *current = DGSensorStreamFor(m, YES);
                if (!DGSensorBlockedKind(DGSensorKindMagnetometer)
                    && current.active
                    && current.generation == generation
                    && handler) {
                    handler(data, error);
                }
            }
        };
        DGSensorEnterForwarding();
        @try { %orig(queue, filtered); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)stopGyroUpdates {
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        stream.active = NO;
        stream.generation++;
        if (!DGSensorIsRevoking()) stream.resume = nil;
        %orig;
    }
}

- (CMGyroData *)gyroData {
    if (DGSensorBlockedKind(DGSensorKindGyro)) { DGSensorNoteBlocked(); return nil; }
    return %orig;
}

// ---- magnetometer ---------------------------------------------------------

- (void)startMagnetometerUpdates {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{ CMMotionManager *m = weakSelf; if (m) [m startMagnetometerUpdates]; };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindMagnetometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        DGSensorEnterForwarding();
        @try { %orig; } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)startMagnetometerUpdatesToQueue:(NSOperationQueue *)queue
                            withHandler:(CMMagnetometerHandler)handler {
    if (DGSensorIsForwarding()) { %orig; return; }
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        __weak CMMotionManager *weakSelf = self;
        stream.resume = ^{
            CMMotionManager *m = weakSelf;
            if (m) [m startMagnetometerUpdatesToQueue:queue withHandler:handler];
        };
        stream.generation++;
        if (DGSensorBlockedKind(DGSensorKindMagnetometer)) { DGSensorNoteBlocked(); return; }
        stream.active = YES;
        NSUInteger generation = stream.generation;
        CMMagnetometerHandler filtered = ^(CMMagnetometerData *data, NSError *error) {
            CMMotionManager *m = weakSelf;
            if (!m) return;
            @synchronized (m) {
                DGStream *current = DGSensorStreamFor(m, YES);
                if (!DGSensorBlockedKind(DGSensorKindMagnetometer)
                    && current.active
                    && current.generation == generation
                    && handler) {
                    handler(data, error);
                }
            }
        };
        DGSensorEnterForwarding();
        @try { %orig(queue, filtered); } @finally { DGSensorLeaveForwarding(); }
    }
}

- (void)stopMagnetometerUpdates {
    @synchronized (self) {
        DGStream *stream = DGSensorStreamFor(self, YES);
        stream.active = NO;
        stream.generation++;
        if (!DGSensorIsRevoking()) stream.resume = nil;
        %orig;
    }
}

- (CMMagnetometerData *)magnetometerData {
    if (DGSensorBlockedKind(DGSensorKindMagnetometer)) { DGSensorNoteBlocked(); return nil; }
    return %orig;
}

// ---- 能力探测（不拦会让 App 以为能用，然后一直等数据）---------------------
//
// 注意：这些是 readonly property 的 getter，Logos 的 %hook 对它们不一定生效
// （@synthesize 生成的 getter 可能被内联优化）。所以这里不写 hook，
// 改在 %ctor 里用 method_setImplementation 动态替换，见下方 DGInstallAvailabilityHooks。

%end

// ---------------------------------------------------------------------------
//  摇一摇拦截
// ---------------------------------------------------------------------------
//
//  摇一摇广告不走 openURL，走 UIResponder 的 motion 回调。
//  必须同时 hook UIWindow 和 UIResponder：
//    UIWindow 覆盖窗口级处理
//    UIResponder 覆盖 VC/View 级处理（很多广告 SDK 自己实现）
//
//  策略见 DGSensorShouldBlockShake()：只拦启动后前 N 秒。

%hook UIWindow

// ---- 只 hook motionEnded，不碰 began / cancelled ----
//
// 之前的实现把 motionBegan / motionEnded / motionCancelled 全 hook 了，
// 每个都直接 return 吞掉事件、不调 %orig，在部分 App 里会闪退：
//
//   1. 摇一摇事件是成对的。App 在 motionBegan 里可能置了状态标志、
//      建了临时对象；began 被吞而它又从别的路径感知到摇动，
//      ended 时就会去访问没建好的资源。
//   2. UIResponder 是根类，hook 它会波及 App 自己重写了 motion 方法的类。
//      很多 App 的 VC 重写 motionEnded 做「摇一摇撤销输入」，
//      被拦掉后内部状态和 UI 不一致。
//   3. motionCancelled 被吞会让某些 App 的「摇动中」状态永远不复位。
//
// 现在只在确定是摇一摇、且还在时间窗口内时，才在窗口这一层吞掉 ended。
// 其余一律原样放行，事件链完整。
- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if (motion == UIEventSubtypeMotionShake && DGSensorShouldBlockShake()) {
        NSLog(@"[DualGuard] 拦下摇一摇 (UIWindow.motionEnded)");
        return;
    }
    %orig;
}

%end

%end

// ---------------------------------------------------------------------------
//  指南针 / 定位（CLLocationManager）
// ---------------------------------------------------------------------------
//
//  ⚠️ 这是 3.6.0 补的。之前完全没拦 ——
//
//  指南针不走 CMMotionManager，走的是 CoreLocation：
//
//      CLLocationManager.startUpdatingHeading  → CLHeading（磁北/真北角度）
//      CLLocationManager.startUpdatingLocation → CLLocation（含 course 航向）
//
//  所以只 hook CMMotionManager 是拦不到指南针的。
//  这也解释了为什么「屏蔽传感器」开着，指南针照样能读。
//
//  拦截方式：heading 直接不给回调，location 把 course 抹成 -1
//  （-1 是 CoreLocation 表示「航向无效」的标准值）。
//
//  注意：这里不拦 location 本身 —— 拦了会让地图、外卖、打车全废。
//  只抹掉航向信息（course / courseAccuracy），位置照常给。
//  要完全禁定位，用系统的「隐私 > 定位服务」，那是另一回事。

%group SensorExtraHooks

%hook CLLocationManager

// ---- 指南针 ----

- (void)startUpdatingHeading {
    if (DGSensorBlockedKind(DGSensorKindCompass)) {
        DGSensorNoteBlocked();
        DGLog(@"传感器", @"拦下 startUpdatingHeading (指南针) bid=%@", DGBundleIdentifier());
        return;
    }
    %orig;
}

- (void)startUpdatingHeadingToQueue:(NSOperationQueue *)queue {
    if (DGSensorBlockedKind(DGSensorKindCompass)) {
        DGSensorNoteBlocked();
        DGLog(@"传感器", @"拦下 startUpdatingHeadingToQueue (指南针)");
        return;
    }
    %orig;
}

- (CLHeading *)heading {
    if (DGSensorBlockedKind(DGSensorKindCompass)) {
        DGSensorNoteBlocked();
        return nil;
    }
    return %orig;
}

// ---- 定位里的航向 ----
//
//  delegate 回调里的 CLLocation 对象带 course 字段。
//  这里不拦回调，只在 App 读 location 时把 course 改掉 ——
//  但 CLLocation 是 immutable，没法改。
//  所以改在 delegate 这一层：把带 course 的对象换成 course=-1 的。
//
//  简化处理：直接拦 startUpdatingLocation 的「航向」语义不现实，
//  改为 hook CLLocation 的 course getter（见下面的分类）。

%end

// ---------------------------------------------------------------------------
//  CLLocation.course —— 定位数据里的航向
// ---------------------------------------------------------------------------
//
//  CLLocation 是 immutable，没法在 delegate 里改。
//  但 course / courseAccuracy 都是 property getter，可以直接 hook。
//
//  -1 是 CoreLocation 官方的「航向无效」值，App 拿到 -1 会认为
//  当前没有可用航向，不会拿去画指南针。
//
//  只影响航向，经纬度、速度、海拔照常返回 —— 地图导航不受影响。

%hook CLLocation

- (CLLocationDirection)course {
    if (DGSensorBlockedKind(DGSensorKindLocation)) {
        return -1.0;
    }
    return %orig;
}

- (CLLocationDirection)courseAccuracy {
    if (DGSensorBlockedKind(DGSensorKindLocation)) {
        return -1.0;
    }
    return %orig;
}

%end

%end

%group RedirectHooks

%hook UIApplication

// iOS 10+ 主入口
//
// ⚠️ 关键：拦截时返回 YES（假装成功），不是 NO。
//
// 为什么：
//   广告 SDK 的标准逻辑是
//     1. 先试 scheme 跳 App
//     2. 如果 completion(NO) 收到失败 → 降级打开网页落地页
//   所以返回 NO 等于告诉 SDK「这条路不通，请走网页」，
//   反而把广告推到浏览器里去了。
//
//   返回 YES 让 SDK 认为跳转已成功，它不会触发 fallback，
//   而实际上我们什么都没打开 —— 广告就这么静默消失了。
//
//   副作用：极少数 App 依赖真实返回值做后续逻辑，
//   但它拿到的 YES 只会让它继续正常流程，不会崩。
- (void)openURL:(NSURL *)url
        options:(NSDictionary<NSString *, id> *)options
completionHandler:(void (^)(BOOL success))completion {
    NSString *source = DGBundleIdentifier();
    NSString *target = DGRedirectTargetBundleFromURL(url);
    if (DGRedirectShouldBlock(source, target) ||
        DGRedirectShouldBlockScheme(source, url.scheme)) {
        DGRedirectLogBlock(source, target ?: url.scheme);
        // 返回 YES 骗过 SDK，阻止它降级到网页
        if (completion) completion(YES);
        return;
    }
    %orig;
}

// 老 API（很多 App 还在用）
// 同样返回 YES，理由见上。
- (BOOL)openURL:(NSURL *)url {
    NSString *source = DGBundleIdentifier();
    NSString *target = DGRedirectTargetBundleFromURL(url);
    if (DGRedirectShouldBlock(source, target) ||
        DGRedirectShouldBlockScheme(source, url.scheme)) {
        DGRedirectLogBlock(source, target ?: url.scheme);
        return YES;
    }
    return %orig;
}

// 探测类调用也要拦：否则 App 用 canOpenURL 判断「能跳」，
// 然后弹「正在打开 App Store」，用户点确认后才发现被拦。
- (BOOL)canOpenURL:(NSURL *)url {
    NSString *source = DGBundleIdentifier();
    NSString *target = DGRedirectTargetBundleFromURL(url);
    if (DGRedirectShouldBlock(source, target) ||
        DGRedirectShouldBlockScheme(source, url.scheme)) {
        // 同样返回 YES：告诉 SDK「能跳」，它就不会走网页 fallback。
        // 真正跳的时候会被 openURL 拦下（那边也返回 YES）。
        return YES;
    }
    return %orig;
}

%end

// ---------------------------------------------------------------------------
//  SKStoreProductViewController —— App 内弹 App Store 商品页
// ---------------------------------------------------------------------------
//
//  广告最常用的「跳转 App」方式之一：不跳出去，在 App 内 present 一个
//  App Store 商品详情页。用户点「获取」就直接装了。
//  完全不经过 openURL，只能 hook 这个类。

%hook SKStoreProductViewController

- (void)loadProductWithParameters:(NSDictionary<NSString *, id> *)parameters
                  completionBlock:(void (^)(BOOL result, NSError *error))block {
    NSString *source = DGBundleIdentifier();
    if (DGBool(DGKeyBlockAppStore, YES) && DGRedirectEnabled() &&
        !DGRedirectIsSourceBypassed(source)) {
        NSLog(@"[DualGuard] blocked SKStoreProductViewController from %@ (params=%@)",
              source, parameters);
        // 返回 YES 骗过 SDK，避免它降级到网页版 App Store
        if (block) block(YES, nil);
        return;
    }
    %orig;
}

%end

// 阻止它被 present
//
// ===========================================================================
//  为什么这里必须防 nil —— 一个真实闪退的根因
// ===========================================================================
//
//  现象：装了插件后，部分 App 点开屏广告直接闪退。
//
//  崩溃日志（KSCrash，App 自己的报告里抓到的原始异常）：
//
//      NSInvalidArgumentException
//      Application tried to present a nil modal view controller
//      on target <BaiduMobAdActionRootController: 0x140f351e0>
//
//  lastExceptionBacktrace 里能清楚看到调用链：
//
//      ... -[UIViewController presentViewController:animated:completion:]
//          DualGuard.dylib +28160            <- 我们
//          ... 广告 SDK ...
//
//  原因：上面拦 SFSafariViewController 的方式是「init 返回 nil」。
//  广告 SDK（百度这边是 BaiduMobAdActionRootController）拿到 nil 之后
//  不做判空，直接
//
//      [self presentViewController:safariVC animated:YES completion:nil];
//
//  UIKit 收到 nil 就抛 NSInvalidArgumentException，没人接住 → abort。
//
//  所以「返回 nil」这个策略本身没错（能有效阻止展示），
//  但必须替调用方补上它没做的判空。
//
//  另外还加了一层 @try/@catch 兜底：广告 SDK 传非 nil 但在错误的时机
//  present（比如「already presenting」）也会抛异常，这类同样不该让 App 崩。
// ===========================================================================

%hook UIViewController

- (void)presentViewController:(UIViewController *)viewControllerToPresent
                     animated:(BOOL)flag
                   completion:(void (^)(void))completion {

    // ---- 防线 1：nil 直接吞掉 ----
    //
    //  我们自己拦广告时会把 VC 变成 nil（SFSafariViewController init 返回 nil），
    //  广告 SDK 不判空就往 UIKit 送。这里拦住，App 就不会崩。
    //  对正常业务代码没有影响 —— 正常代码不会去 present 一个 nil。
    if (!viewControllerToPresent) {
        DGLog(@"跳转拦截", @"拦下了一次 present(nil)，避免 UIKit 抛异常");
        if (completion) completion();
        return;
    }

    // ---- 防线 2：App Store 商品页 ----
    if ([viewControllerToPresent isKindOfClass:NSClassFromString(@"SKStoreProductViewController")]) {
        NSString *source = DGBundleIdentifier();
        if (DGBool(DGKeyBlockAppStore, YES) && DGRedirectEnabled() &&
            !DGRedirectIsSourceBypassed(source)) {
            DGLog(@"跳转拦截", @"拦下 SKStoreProductViewController，来源 %@", source);
            if (completion) completion();
            return;
        }
    }

    // ---- 防线 3：兜底，异常不外泄 ----
    //
    //  广告 SDK 传了非 nil 的 VC，但在错误时机 present（重复 present、
    //  VC 已销毁、父 VC 不在窗口层级里……），UIKit 一样会抛异常。
    //  这类异常一旦没人接住就是 abort，对用户来说就是「点广告闪退」。
    //  宁可这次展示失败，也不让整个 App 挂掉。
    @try {
        %orig;
    } @catch (NSException *e) {
        DGLog(@"跳转拦截", @"present 抛异常已拦下: %@ — %@",
              e.name, e.reason);
        if (completion) completion();
    }
}

%end

// LSApplicationWorkspace 的私有入口
%hook LSApplicationWorkspace

- (BOOL)openSensitiveURL:(NSURL *)url withOptions:(id)options {
    NSString *source = DGBundleIdentifier();
    NSString *target = DGRedirectTargetBundleFromURL(url);
    if (DGRedirectShouldBlock(source, target)) {
        DGRedirectLogBlock(source, target);
        return YES;   // 假装成功，阻止 fallback
    }
    return %orig;
}

- (BOOL)openURL:(NSURL *)url withOptions:(id)options {
    NSString *source = DGBundleIdentifier();
    NSString *target = DGRedirectTargetBundleFromURL(url);
    if (DGRedirectShouldBlock(source, target)) {
        DGRedirectLogBlock(source, target);
        return YES;   // 假装成功，阻止 fallback
    }
    return %orig;
}

%end

// ---------------------------------------------------------------------------
//  SFSafariViewController —— 广告最常走的路径
// ---------------------------------------------------------------------------
//
//  它在 App 进程内 present 一个 Safari 界面，完全不经过 UIApplication.openURL，
//  所以只 hook openURL 拦不住。
//
//  拦截方式：让 init 返回 nil。调用方（广告 SDK）拿到 nil 后通常就放弃展示了。
//  风险：如果 App 正常功能也走这个（登录/条款），会被一起拦。
//  所以默认只拦「广告特征域名 + App Store 链接」，普通网页走独立开关。

%hook SFSafariViewController

- (instancetype)initWithURL:(NSURL *)url configuration:(id)configuration {
    NSString *source = DGBundleIdentifier();
    if (DGRedirectShouldBlockWebURL(source, url)) {
        NSLog(@"[DualGuard] blocked SFSafariViewController(%@) from %@",
              url.host ?: url.scheme ?: @"?", source);
        return nil;
    }
    return %orig;
}

- (instancetype)initWithURL:(NSURL *)url {
    NSString *source = DGBundleIdentifier();
    if (DGRedirectShouldBlockWebURL(source, url)) {
        NSLog(@"[DualGuard] blocked SFSafariViewController(%@) from %@",
              url.host ?: url.scheme ?: @"?", source);
        return nil;
    }
    return %orig;
}

%end

// ---------------------------------------------------------------------------
//  ASWebAuthenticationSession —— OAuth 容器，也常被广告滥用
// ---------------------------------------------------------------------------

%hook ASWebAuthenticationSession

- (instancetype)initWithURL:(NSURL *)url
          callbackURLScheme:(NSString *)callbackURLScheme
          completionHandler:(void (^)(NSURL *callbackURL, NSError *error))completionHandler {
    NSString *source = DGBundleIdentifier();
    if (DGRedirectShouldBlockWebURL(source, url)) {
        NSLog(@"[DualGuard] blocked ASWebAuthenticationSession(%@) from %@",
              url.host ?: url.scheme ?: @"?", source);
        return nil;
    }
    return %orig;
}

%end

%end

// ===========================================================================
//  C. 能力探测 hook（动态安装）
// ===========================================================================
//
//  CMMotionManager 的 isXxxAvailable 是 readonly property 的 getter，
//  由 @synthesize 生成，Logos 的 %hook 对它们不生效（实测确认）。
//  改用 method_setImplementation 直接替换 IMP。
//
//  为什么需要拦这个：很多 App 启动时先判断 isAccelerometerAvailable，
//  拿到 YES 才去 startUpdates。如果不拦，App 会以为能用，然后一直等数据，
//  表现为卡住或转圈，而不是干脆地降级。

typedef BOOL (*DGAvailabilityIMP)(id, SEL);
typedef id (*DGOBJCMsgSendId)(id, SEL);

static IMP gOrigAccelAvailable = NULL;
static IMP gOrigMotionAvailable = NULL;
static IMP gOrigGyroAvailable = NULL;
static IMP gOrigMagAvailable = NULL;

static IMP gOrigAccelActive = NULL;
static IMP gOrigMotionActive = NULL;
static IMP gOrigGyroActive = NULL;
static IMP gOrigMagActive = NULL;

static BOOL DGHookedAccelAvailable(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindAccelerometer)) return NO;
    return ((DGAvailabilityIMP)gOrigAccelAvailable)(self, _cmd);
}

static BOOL DGHookedMotionAvailable(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindDeviceMotion)) return NO;
    return ((DGAvailabilityIMP)gOrigMotionAvailable)(self, _cmd);
}

static BOOL DGHookedGyroAvailable(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindGyro)) return NO;
    return ((DGAvailabilityIMP)gOrigGyroAvailable)(self, _cmd);
}

static BOOL DGHookedMagAvailable(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindMagnetometer)) return NO;
    return ((DGAvailabilityIMP)gOrigMagAvailable)(self, _cmd);
}

// isXxxActive 也要拦：App 会用这个判断「是否已经在采集」，
// 不拦的话 App 可能认为还在运行，从而不去重启采集，表现为数据一直不来。
static BOOL DGHookedAccelActive(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindAccelerometer)) return NO;
    return ((DGAvailabilityIMP)gOrigAccelActive)(self, _cmd);
}

static BOOL DGHookedMotionActive(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindDeviceMotion)) return NO;
    return ((DGAvailabilityIMP)gOrigMotionActive)(self, _cmd);
}

static BOOL DGHookedGyroActive(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindGyro)) return NO;
    return ((DGAvailabilityIMP)gOrigGyroActive)(self, _cmd);
}

static BOOL DGHookedMagActive(id self, SEL _cmd) {
    if (DGSensorBlockedKind(DGSensorKindMagnetometer)) return NO;
    return ((DGAvailabilityIMP)gOrigMagActive)(self, _cmd);
}

static void DGInstallAvailabilityHooks(void) {
    Class cls = objc_getClass("CMMotionManager");
    if (!cls) {
        NSLog(@"[DualGuard] ❌ CMMotionManager not found, availability hooks skipped");
        return;
    }
    NSLog(@"[DualGuard] CMMotionManager = %p", (__bridge void *)cls);

    struct { const char *sel; IMP *orig; IMP replacement; } table[] = {
        // 能力探测
        { "isAccelerometerAvailable", &gOrigAccelAvailable, (IMP)DGHookedAccelAvailable },
        { "isDeviceMotionAvailable",  &gOrigMotionAvailable, (IMP)DGHookedMotionAvailable },
        { "isGyroAvailable",          &gOrigGyroAvailable, (IMP)DGHookedGyroAvailable },
        { "isMagnetometerAvailable",  &gOrigMagAvailable, (IMP)DGHookedMagAvailable },
        // 活跃状态（ShakeShield 同款，之前漏了）
        { "isAccelerometerActive",    &gOrigAccelActive, (IMP)DGHookedAccelActive },
        { "isDeviceMotionActive",     &gOrigMotionActive, (IMP)DGHookedMotionActive },
        { "isGyroActive",             &gOrigGyroActive, (IMP)DGHookedGyroActive },
        { "isMagnetometerActive",     &gOrigMagActive, (IMP)DGHookedMagActive },
    };

    int okCount = 0;
    for (size_t i = 0; i < sizeof(table) / sizeof(table[0]); i++) {
        SEL sel = sel_registerName(table[i].sel);
        Method m = class_getInstanceMethod(cls, sel);
        if (!m) {
            NSLog(@"[DualGuard] ⚠️ %s not found on CMMotionManager", table[i].sel);
            continue;
        }
        IMP before = method_getImplementation(m);
        *table[i].orig = before;
        method_setImplementation(m, table[i].replacement);
        IMP after = method_getImplementation(m);
        if (after == table[i].replacement) okCount++;
        NSLog(@"[DualGuard] %@ hooked -%s  IMP %p -> %p",
              (after == table[i].replacement) ? @"✅" : @"❌",
              table[i].sel, (void *)before, (void *)after);
    }
    NSLog(@"[DualGuard] 能力探测 hook 完成: %d/%zu", okCount, sizeof(table)/sizeof(table[0]));
}

// ===========================================================================
//  构造器
// ===========================================================================

%ctor {
    @autoreleasepool {
        // ===================================================================
        //  最早期：只做一件事 —— 判断该不该在这个进程里干活
        // ===================================================================
        //
        //  闪退的教训：之前的实现在判断之前就调了 DGStartObserving()、
        //  DGSensorSetup()、DGShakeMarkLaunch()。这些函数会：
        //    * notify_register_dispatch 注册通知（主队列可能还没准备好）
        //    * 初始化弱引用表
        //    * 读系统时间
        //  在设置 App 自己身上跑这些，虽然没有直接崩，但埋了雷。
        //
        //  现在的原则：先判断，不该干活的进程连一行代码都不多跑。
        //
        NSString *identifier = nil;
        BOOL isApp = NO;

        @try {
            identifier = DGBundleIdentifier();
            isApp = [NSBundle.mainBundle.bundlePath hasSuffix:@".app"];
        } @catch (NSException *e) {
            return;   // 连 bundle id 都拿不到，说明环境异常，直接放弃
        }

        DGLogInit(@"DualGuard");
        DGLog(@"ctor", @"注入进程: %@ (isApp=%d)", identifier, isApp);

        // ---- 排除设置 App 自身 ----
        //
        // 只排除设置 App，不能排除整个 com.deepseek.dualguard.* 前缀。
        //
        // 原因：自检 App（com.deepseek.dualguard.test）需要被 hook
        // 才能测试 T4 传感器、T5 跳转拦截这些功能。之前用前缀匹配
        // 把它一起排除了，导致自检的 T4/T5 永远失败。
        if ([identifier isEqualToString:@"com.deepseek.dualguard.settings"]) {
            DGLog(@"ctor", @"跳过：设置 App 自身");
            return;
        }

        // ---- 排除非 App 进程 ----
        if (!isApp || !identifier.length || [identifier isEqualToString:@"unknown"]) {
            DGLog(@"ctor", @"跳过：非 App 进程");
            return;
        }

        // ---- 排除系统进程 ----
        //
        // 系统进程是 arm64e，我们注入不进去，但 Filter 有时会误放进来。
        // 加一道保险，避免在不该在的地方 hook 系统类导致崩溃。
        if ([identifier hasPrefix:@"com.apple."]) {
            DGLog(@"ctor", @"跳过：系统进程");
            return;
        }

        // ===================================================================
        //  确认要干活了，才开始初始化
        // ===================================================================

        // 每一步都包 try-catch。任何一步失败都只是少一个功能，
        // 不能让整个进程崩掉。
        @try {
            DGStartObserving();
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] DGStartObserving failed: %@", e);
        }

        @try {
            DGSensorSetup();
            DGShakeMarkLaunch();
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] sensor setup failed: %@", e);
        }

        // ---- 传感器屏蔽 ----
        @try {
            %init(SensorHooks);
            %init(SensorExtraHooks);
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] SensorHooks init failed: %@", e);
        }

        // ---- 能力探测（动态 hook，Logos 对 property getter 无效）----
        @try {
            DGInstallAvailabilityHooks();
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] availability hooks failed: %@", e);
        }

        // ---- 跳转拦截 ----
        @try {
            %init(RedirectHooks);

            // 权限伪装：让 App 以为有权限，实际读不到数据
            @try {
                DGInstallPermissionHooks();
            } @catch (NSException *e) {
                DGLog(@"ctor", @"权限伪装安装失败: %@", e.reason);
            }
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] RedirectHooks init failed: %@", e);
        }

        // ---- 广告自动跳过 ----
        //
        // 延迟 2 秒启动：ctor 执行时 UI 还没起来。
        // 加 weak 保护，避免 App 退出后 block 还持有已释放的对象。
        //
        __weak typeof(NSClassFromString(@"UIApplication")) weakAppClass = nil;
        (void)weakAppClass;   // 占位，实际不需要捕获任何对象

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            @try {
                DGAdSkipStart();
            } @catch (NSException *e) {
                NSLog(@"[DualGuard] AdSkip start failed: %@", e);
            }
        });

        // ---- DNS 层广告拦截 ----
        //
        // hook getaddrinfo 影响面很大，放在最后，且包 try-catch。
        @try {
            DGAdBlockInstall();
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] DNS block install failed: %@", e);
        }

        // ---- 配置变更监听 ----
        @try {
            DGRegisterChangeHandler(^{
                @try {
                    DGSensorPolicyChanged();
                    if (DGAdSkipEnabledForCurrentProcess()) DGAdSkipStart();
                    else DGAdSkipStop();
                    if (DGAdBlockEnabled()) DGAdBlockInstall();
                } @catch (NSException *e) {
                    NSLog(@"[DualGuard] change handler failed: %@", e);
                }
            });
        } @catch (NSException *e) {
            NSLog(@"[DualGuard] register handler failed: %@", e);
        }

        DGLog(@"ctor", @"装配完成 sensor=%d redirect=%d adskip=%d dns=%d",
              DGSensorBlockedForCurrentProcess(),
              DGRedirectEnabled(),
              DGAdSkipEnabledForCurrentProcess(),
              DGAdBlockEnabled());

        NSLog(@"[DualGuard] armed for %@ (sensor=%d redirect=%d adskip=%d dns=%d)",
              identifier,
              DGSensorBlockedForCurrentProcess(),
              DGRedirectEnabled(),
              DGAdSkipEnabledForCurrentProcess(),
              DGAdBlockEnabled());
    }
}
