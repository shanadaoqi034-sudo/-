//
//  DGPermission.h — 权限伪装（让 App 以为拿到了权限，实际拿不到数据）
//
//  ⚠️ 仅供学习交流使用
//  作者 QQ：2836226951    交流群：724179606
//
//  ==========================================================================
//   这个模块干什么
//  ==========================================================================
//
//  和「拒绝权限」不一样：
//
//    拒绝权限  → App 弹系统框、用户点拒绝、App 显示「无权限」引导页
//                 用户看到的是「我用不了这个功能」
//
//    权限伪装  → App 问「有没有权限」，我们答「有」
//                 系统授权框根本不弹
//                 App 高高兴兴地去读数据，拿回来是空的
//                 用户看到的是「界面正常，但里面没东西」
//
//  为什么这么做：
//    * 不给真实数据（隐私）
//    * 又不让 App 进入「无权限」降级流程（体验）
//    * 不弹系统框（不打扰）
//
//  ==========================================================================
//   覆盖范围
//  ==========================================================================
//
//    相册     PHPhotoLibrary / PHAsset / PHAssetCollection / UIImagePickerController
//    通讯录   CNContactStore / ABAddressBook（旧 API）
//    日历     EKEventStore / EKEvent / EKReminder
//    提醒事项 EKEventStore（同上）
//    麦克风   AVAudioSession.recordPermission / requestRecordPermission
//    摄像头   AVCaptureDevice.authorizationStatusForMediaType:
//    定位     CLLocationManager.authorizationStatus
//    蓝牙     CBManager.authorization
//    健康     HKHealthStore.authorizationStatusForType:
//    通知     UNUserNotificationCenter.getNotificationSettings
//
//  ==========================================================================
//   实现策略
//  ==========================================================================
//
//  1) 授权查询类（authorizationStatus / requestAccess 的 completion）
//     一律返回「已授权」，让 App 走正常流程
//
//  2) 数据读取类（fetchAssets / enumerateContacts / fetchEvents）
//     返回空结果，App 拿到的是「有权限但没数据」
//
//  3) 数据写入类（保存照片 / 新建联系人）
//     假装成功，不真的写
//
//  ⚠️ 注意：这是「假授权」，不是安全边界。
//     有代码执行能力的恶意 App 可以绕过。它的用途是防正常 App 的
//     过度采集，不是防针对性攻击。
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 权限类型
typedef NS_ENUM(NSInteger, DGPermKind) {
    DGPermKindPhotos = 0,   // 相册
    DGPermKindContacts,     // 通讯录
    DGPermKindCalendar,     // 日历
    DGPermKindReminders,    // 提醒事项
    DGPermKindMicrophone,   // 麦克风
    DGPermKindCamera,       // 摄像头
    DGPermKindLocation,     // 定位
    DGPermKindBluetooth,    // 蓝牙
    DGPermKindHealth,       // 健康
    DGPermKindNotifications,// 通知
};

// 总开关是否打开（全局）
FOUNDATION_EXPORT BOOL DGPermissionEnabled(void);

// 某个权限对当前进程是否启用伪装
FOUNDATION_EXPORT BOOL DGPermissionFakeForKind(DGPermKind kind);

// 该权限对应的 per-App 特性名
FOUNDATION_EXPORT NSString *DGPermissionFeatureForKind(DGPermKind kind);

// 该权限的中文名（日志 / 界面用）
FOUNDATION_EXPORT NSString *DGPermissionNameForKind(DGPermKind kind);

// 记录一次伪装（写日志，前几次会打）
FOUNDATION_EXPORT void DGPermissionNoteFake(DGPermKind kind, NSString *detail);

// ---- per-App 特性名（给设置界面用）----
FOUNDATION_EXPORT NSString * const DGFeaturePermPhotos;
FOUNDATION_EXPORT NSString * const DGFeaturePermContacts;
FOUNDATION_EXPORT NSString * const DGFeaturePermCalendar;
FOUNDATION_EXPORT NSString * const DGFeaturePermReminders;
FOUNDATION_EXPORT NSString * const DGFeaturePermMicrophone;
FOUNDATION_EXPORT NSString * const DGFeaturePermCamera;
FOUNDATION_EXPORT NSString * const DGFeaturePermLocation;
FOUNDATION_EXPORT NSString * const DGFeaturePermBluetooth;
FOUNDATION_EXPORT NSString * const DGFeaturePermHealth;
FOUNDATION_EXPORT NSString * const DGFeaturePermNotifications;

// ---- 全局键 ----
FOUNDATION_EXPORT NSString * const DGKeyPermEnabled;
FOUNDATION_EXPORT NSString * const DGKeyPermPhotos;
FOUNDATION_EXPORT NSString * const DGKeyPermContacts;
FOUNDATION_EXPORT NSString * const DGKeyPermCalendar;
FOUNDATION_EXPORT NSString * const DGKeyPermReminders;
FOUNDATION_EXPORT NSString * const DGKeyPermMicrophone;
FOUNDATION_EXPORT NSString * const DGKeyPermCamera;
FOUNDATION_EXPORT NSString * const DGKeyPermLocation;
FOUNDATION_EXPORT NSString * const DGKeyPermBluetooth;
FOUNDATION_EXPORT NSString * const DGKeyPermHealth;
FOUNDATION_EXPORT NSString * const DGKeyPermNotifications;

NS_ASSUME_NONNULL_END
