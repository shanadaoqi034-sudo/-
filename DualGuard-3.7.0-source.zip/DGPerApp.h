//
//  DGPerApp.h — 按 App 单独配置
//
//  ==========================================================================
//   设计
//  ==========================================================================
//
//  每个 App 的每项功能都可以单独开关。存储用一个统一前缀 + 功能名 + bundleID：
//
//      AppCfg.<功能>.<bundleID> = @YES / @NO
//
//  功能名（与设置界面的模块一一对应）：
//
//      master      总开关（这个 App 是否受 DualGuard 管辖）
//      dns         DNS 广告拦截
//      adskip      广告自动跳过
//      shake       摇一摇拦截
//      sensor      传感器屏蔽
//      redirect    跳转拦截（总）
//      store       跳转拦截：App Store
//      safari      跳转拦截：Safari
//      browser     跳转拦截：其他浏览器
//      web         跳转拦截：网页
//      otherapp    跳转拦截：其他 App
//      alljump     跳转拦截：所有外部跳转
//
//  ---- 为什么用统一前缀 ----
//
//  旧版有三套互不相干的键：
//      SensorBlocked.<bid>      传感器
//      ShakeBypassed.<bid>      摇一摇（设置里根本没入口）
//      RedirectBypassed.<bid>   跳转（设置里也没入口）
//      AdSkip.<bid>             广告跳过
//
//  分散导致：
//    * 设置界面要写三套不同的读写逻辑
//    * 跳转拦截和摇一摇的 per-App 开关压根没做进界面
//    * 无法做「一个 App 一页，全功能配置」
//
//  现在统一成 AppCfg.* 前缀，读写都走同一套函数。
//
//  ---- 三层优先级 ----
//
//    1. 全局开关（Enabled / RedirectEnabled / ...）关掉 → 全部放行
//    2. 该 App 的 master 关掉 → 这个 App 全部放行
//    3. 该 App 的具体功能键 → 有值就用它，没值继承全局
//
//  这样既能「一键全关」，又能「只给某个 App 开绿灯」。
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 前缀
FOUNDATION_EXPORT NSString * const DGAppCfgPrefix;   // "AppCfg."

// 功能名常量
FOUNDATION_EXPORT NSString * const DGFeatureMaster;    // "master"
FOUNDATION_EXPORT NSString * const DGFeatureDNS;       // "dns"
FOUNDATION_EXPORT NSString * const DGFeatureAdSkip;    // "adskip"
FOUNDATION_EXPORT NSString * const DGFeatureShake;     // "shake"
FOUNDATION_EXPORT NSString * const DGFeatureSensor;    // "sensor"
FOUNDATION_EXPORT NSString * const DGFeatureRedirect;  // "redirect"
FOUNDATION_EXPORT NSString * const DGFeatureStore;     // "store"
FOUNDATION_EXPORT NSString * const DGFeatureSafari;    // "safari"
FOUNDATION_EXPORT NSString * const DGFeatureBrowser;   // "browser"
FOUNDATION_EXPORT NSString * const DGFeatureWeb;       // "web"
FOUNDATION_EXPORT NSString * const DGFeatureOtherApp;  // "otherapp"
FOUNDATION_EXPORT NSString * const DGFeatureAllJump;   // "alljump"

// ---- 传感器细分（3.6.0 新增）----
//
//  原来只有 DGFeatureSensor 一个总键，粒度太粗：
//  用户可能只想屏蔽指南针，不想屏蔽加速度计。
//  细分后每个传感器独立开关，总键仍然作为「一键全关」的总闸。
FOUNDATION_EXPORT NSString * const DGFeatureSensorAccel;  // "sensoraccel"  加速度计
FOUNDATION_EXPORT NSString * const DGFeatureSensorGyro;   // "sensorgyro"   陀螺仪
FOUNDATION_EXPORT NSString * const DGFeatureSensorMag;    // "sensormag"    磁力计
FOUNDATION_EXPORT NSString * const DGFeatureSensorMotion; // "sensormotion" 设备姿态
FOUNDATION_EXPORT NSString * const DGFeatureSensorCompass;// "sensorcompass" 指南针
FOUNDATION_EXPORT NSString * const DGFeatureSensorLocation; // "sensorloc"  定位/航向

// 拼出存储键：AppCfg.<feature>.<bundleID>
FOUNDATION_EXPORT NSString *DGPerAppKey(NSString *feature, NSString *bundleID);

// 读某个 App 的某项功能设置。
//   * 没设过 → 返回 fallback（调用方传全局值，实现「继承」）
//   * 设过   → 返回设置值
FOUNDATION_EXPORT BOOL DGPerAppBool(NSString *feature, NSString *bundleID, BOOL fallback);

// 写某个 App 的某项功能设置
FOUNDATION_EXPORT void DGPerAppSet(NSString *feature, NSString *bundleID, BOOL value);

// 清除某个 App 的某项设置（恢复继承全局）
FOUNDATION_EXPORT void DGPerAppClear(NSString *feature, NSString *bundleID);

// 清除某个 App 的所有设置
FOUNDATION_EXPORT void DGPerAppClearAll(NSString *bundleID);

// 某个 App 是否有任何自定义设置（界面用来显示「已自定义」标记）
FOUNDATION_EXPORT BOOL DGPerAppHasAnyOverride(NSString *bundleID);

// 统计有自定义设置的 App 数量（首页徽标用）
FOUNDATION_EXPORT NSUInteger DGPerAppOverrideCount(void);

// 列出所有有自定义设置的 bundleID
FOUNDATION_EXPORT NSArray<NSString *> *DGPerAppListOverridden(void);

// ---- 供 tweak 侧用的综合判定 ----
//
// 这些函数把「全局开关 + 该 App master + 该 App 具体设置」三层合起来算。
// tweak 的各个模块直接调这些，不用自己拼逻辑。
//

// 这个 App 是否受 DualGuard 管辖（总开关 && 该 App 的 master）
FOUNDATION_EXPORT BOOL DGPerAppMasterOn(NSString *bundleID);

// 某功能对这个 App 是否启用（考虑三层优先级）
FOUNDATION_EXPORT BOOL DGPerAppFeatureOn(NSString *feature, NSString *bundleID,
                                         BOOL globalValue);

NS_ASSUME_NONNULL_END
