//
//  DGAdBlock.m — DNS 层广告拦截（进程内 hook）
//
//  ⚠️ 仅供学习交流使用
//
//  为什么不用 /etc/hosts：
//    iOS 15+ 使用 SSV（签名系统卷），系统卷只读。
//    /etc/hosts 在系统卷上，即使 root 也写不了（EPERM）。
//
//  本模块 hook libsystem 的 DNS 解析函数：
//    getaddrinfo / gethostbyname / gethostbyname2
//    命中广告域名时返回 0.0.0.0 或 NULL，连接必然失败。
//
//  依赖：Substrate / ElleKit 的 MSHookFunction（设备上已装）
//

#import "DGAdBlock.h"
#import "DGLog.h"
#import "DGCore.h"
#import "DGPerApp.h"
#import <netdb.h>
#import <arpa/inet.h>
#import <string.h>
#import <stdatomic.h>
#import <pthread.h>
#import <dlfcn.h>

// ---------------------------------------------------------------------------
// 广告域名规则
// ---------------------------------------------------------------------------

static const char *kAdDomains[] = {
    // Google
    "doubleclick.net", "googleadservices.com", "googlesyndication.com",
    "google-analytics.com", "adservice.google.com",
    "pubads.g.doubleclick.net", "securepubads.g.doubleclick.net",
    "stats.g.doubleclick.net", "cm.g.doubleclick.net",
    "pagead2.googlesyndication.com", "partner.googleadservices.com",
    "tpc.googlesyndication.com", "afs.googlesyndication.com",
    // Meta
    "graph.facebook.com", "an.facebook.com", "connect.facebook.net",
    // 字节 / 穿山甲
    "pangle.io", "pangolin-sdk-toutiao.com", "pglstatp-toutiao.com",
    "gromore.pangle.io", "csjplatform.com", "bytedance.com",
    "ad.pangle.io", "log-api.pangle.io", "api-access.pangle.io",
    "bytecdn.cn",
    // 腾讯广点通
    "gdt.qq.com", "e.qq.com", "ad.qq.com", "pingjs.qq.com",
    "pingma.qq.com", "pgdt.gtimg.cn", "adsmind.gdtimg.com",
    // 阿里妈妈
    "alimama.com", "tanx.com", "mmstat.com", "simba.taobao.com",
    "atanx.alicdn.com", "h-adashx.ut.taobao.com",
    // 百度
    "cpro.baidu.com", "pos.baidu.com", "union.baidu.com", "cbjs.baidu.com",
    "dsp.baidu.com", "mobads.baidu.com",
    // 快手
    "adkwai.com", "ad.kuaishou.com", "kwaicdn.com",
    // 国际广告平台
    "applovin.com", "applvn.com", "unityads.unity3d.com",
    "auction.unityads.unity3d.com", "vungle.com", "kiwi.vungle.com",
    "chartboost.com", "he2.chartboost.com", "ironsrc.com",
    "supersonicads.com", "tapjoy.com", "inmobi.com", "mopub.com",
    "mintegral.com", "mbridg.cn", "admob.com", "adcolony.com",
    "fyber.com", "criteo.com", "adnxs.com", "rubiconproject.com",
    "pubmatic.com", "openx.net", "smartadserver.com", "casalemedia.com",
    "33across.com", "sharethrough.com", "pubnative.net", "smaato.net",
    "startapp.com",
    // 分析追踪
    "adjust.com", "appsflyer.com", "branch.io", "kochava.com",
    "singular.net", "tenjin.io", "bugly.qq.com",
    "umeng.com", "umengcloud.com", "talkingdata.com", "talkingdata.net",
    "growingio.com", "sensorsdata.cn", "mixpanel.com", "amplitude.com",
    "flurry.com", "newrelic.com", "crashlytics.com",
    // 国内推广
    "mob.com", "waps.cn", "dsp.360.cn", "union.360.cn", "show.360.cn",
    "ads.sohu.com", "ads.sina.com.cn", "tanx.com.cn",
    NULL
};

NSUInteger DGAdBlockRuleCount(void) {
    NSUInteger n = 0;
    for (int i = 0; kAdDomains[i]; i++) n++;
    return n;
}

// ---------------------------------------------------------------------------
// 域名匹配
// ---------------------------------------------------------------------------

BOOL DGAdBlockIsAdDomain(const char *host) {
    if (!host || !*host) return NO;

    struct in_addr a4;
    struct in6_addr a6;
    if (inet_pton(AF_INET, host, &a4) == 1) return NO;
    if (inet_pton(AF_INET6, host, &a6) == 1) return NO;

    size_t hlen = strlen(host);
    if (hlen > 512) return NO;

    for (int i = 0; kAdDomains[i]; i++) {
        const char *rule = kAdDomains[i];
        size_t rlen = strlen(rule);

        if (hlen == rlen) {
            if (strncasecmp(host, rule, rlen) == 0) return YES;
        } else if (hlen > rlen) {
            const char *suffix = host + (hlen - rlen);
            if (strncasecmp(suffix, rule, rlen) == 0 && *(suffix - 1) == '.') {
                return YES;
            }
        }
    }
    return NO;
}

// ---------------------------------------------------------------------------
// 统计
// ---------------------------------------------------------------------------

static atomic_uint gBlockedCount = 0;
static pthread_mutex_t gLogLock = PTHREAD_MUTEX_INITIALIZER;
static NSMutableArray<NSString *> *gRecentHosts = nil;

static void DGRecordBlock(const char *host) {
    if (host) {
        DGLog(@"DNS拦截", @"拦下 %s", host);
    }
    unsigned int total = atomic_fetch_add(&gBlockedCount, 1) + 1;

    pthread_mutex_lock(&gLogLock);
    if (!gRecentHosts) gRecentHosts = [NSMutableArray new];
    if (host) {
        NSString *h = [NSString stringWithUTF8String:host];
        if (h.length) {
            [gRecentHosts addObject:h];
            while (gRecentHosts.count > 50) [gRecentHosts removeObjectAtIndex:0];
        }
    }
    pthread_mutex_unlock(&gLogLock);

    // 只在前 10 次和每 50 次打日志，避免刷屏
    if (total <= 10 || total % 50 == 0) {
        NSLog(@"[DualGuard] DNS 拦截: %s (累计 %u 次)", host ?: "?", total);
    }
}

NSUInteger DGAdBlockBlockedCount(void) {
    return (NSUInteger)atomic_load(&gBlockedCount);
}

NSArray<NSString *> *DGAdBlockRecentHosts(void) {
    pthread_mutex_lock(&gLogLock);
    NSArray *copy = [gRecentHosts copy] ?: @[];
    pthread_mutex_unlock(&gLogLock);
    return copy;
}

void DGAdBlockResetStats(void) {
    atomic_store(&gBlockedCount, 0);
    pthread_mutex_lock(&gLogLock);
    [gRecentHosts removeAllObjects];
    pthread_mutex_unlock(&gLogLock);
}

// ---------------------------------------------------------------------------
// hook 实现
// ---------------------------------------------------------------------------

typedef int (*DGGetAddrInfoFn)(const char *, const char *,
                               const struct addrinfo *, struct addrinfo **);
typedef struct hostent *(*DGGethostbynameFn)(const char *);
typedef struct hostent *(*DGGethostbyname2Fn)(const char *, int);

static DGGetAddrInfoFn gOrigGetAddrInfo = NULL;
static DGGethostbynameFn gOrigGethostbyname = NULL;
static DGGethostbyname2Fn gOrigGethostbyname2 = NULL;

// 构造一个指向 0.0.0.0 的 addrinfo
static int DGBlockedAddrInfo(const struct addrinfo *hints, struct addrinfo **res) {
    struct addrinfo *ai = calloc(1, sizeof(struct addrinfo));
    if (!ai) return EAI_MEMORY;

    struct sockaddr_in *sin = calloc(1, sizeof(struct sockaddr_in));
    if (!sin) { free(ai); return EAI_MEMORY; }

    sin->sin_family = AF_INET;
    sin->sin_port = 0;
    sin->sin_addr.s_addr = htonl(INADDR_ANY);

    ai->ai_family = AF_INET;
    ai->ai_socktype = hints ? hints->ai_socktype : SOCK_STREAM;
    ai->ai_protocol = hints ? hints->ai_protocol : IPPROTO_TCP;
    ai->ai_addrlen = sizeof(struct sockaddr_in);
    ai->ai_addr = (struct sockaddr *)sin;
    ai->ai_next = NULL;

    *res = ai;
    return 0;
}

static int DGHookedGetAddrInfo(const char *node, const char *service,
                               const struct addrinfo *hints,
                               struct addrinfo **res) {
    if (node && DGAdBlockIsAdDomain(node)) {
        DGRecordBlock(node);
        return DGBlockedAddrInfo(hints, res);
    }
    if (!gOrigGetAddrInfo) return EAI_FAIL;
    return gOrigGetAddrInfo(node, service, hints, res);
}

static struct hostent *DGHookedGethostbyname(const char *name) {
    if (name && DGAdBlockIsAdDomain(name)) {
        DGRecordBlock(name);
        return NULL;
    }
    if (!gOrigGethostbyname) return NULL;
    return gOrigGethostbyname(name);
}

static struct hostent *DGHookedGethostbyname2(const char *name, int af) {
    if (name && DGAdBlockIsAdDomain(name)) {
        DGRecordBlock(name);
        return NULL;
    }
    if (!gOrigGethostbyname2) return NULL;
    return gOrigGethostbyname2(name, af);
}

// ---------------------------------------------------------------------------
// 用 MSHookFunction 安装
// ---------------------------------------------------------------------------

typedef void (*DGMSHookFunctionFn)(void *symbol, void *replace, void **result);

static DGMSHookFunctionFn DGFindHookFunction(void) {
    // 直接从已加载的镜像里找（Substrate / ElleKit）
    DGMSHookFunctionFn fn = (DGMSHookFunctionFn)dlsym(RTLD_DEFAULT, "MSHookFunction");
    if (fn) return fn;

    const char *libs[] = {
        "/var/jb/usr/lib/libsubstrate.dylib",
        "/var/jb/usr/lib/libellekit.dylib",
        "/usr/lib/libsubstrate.dylib",
        "/usr/lib/libellekit.dylib",
        "/var/jb/usr/lib/libhooker.dylib",
        NULL
    };

    for (int i = 0; libs[i]; i++) {
        void *h = dlopen(libs[i], RTLD_LAZY | RTLD_NOLOAD);
        if (!h) h = dlopen(libs[i], RTLD_LAZY);
        if (!h) continue;
        fn = (DGMSHookFunctionFn)dlsym(h, "MSHookFunction");
        if (fn) {
            NSLog(@"[DualGuard] MSHookFunction 来自 %s", libs[i]);
            return fn;
        }
    }
    return NULL;
}

// ---------------------------------------------------------------------------
// 对外接口
// ---------------------------------------------------------------------------

BOOL DGAdBlockEnabled(void) {
    if (!DGEnabled()) return NO;

    NSString *bid = DGBundleIdentifier();
    BOOL globalDNS = DGBool(DGKeyDNSBlock, NO);
    return DGPerAppFeatureOn(DGFeatureDNS, bid, globalDNS);
}

static BOOL gInstalled = NO;

void DGAdBlockInstall(void) {
    if (gInstalled) return;
    if (!DGAdBlockEnabled()) {
        return;
    }

    DGMSHookFunctionFn hookFn = DGFindHookFunction();
    if (!hookFn) {
        NSLog(@"[DualGuard] ⚠️ 找不到 MSHookFunction，DNS 拦截不可用");
        DGLog(@"DNS拦截", @"安装失败：找不到 MSHookFunction");
        return;
    }

    int hooked = 0;

    void *sym1 = dlsym(RTLD_DEFAULT, "getaddrinfo");
    if (sym1) {
        hookFn(sym1, (void *)DGHookedGetAddrInfo, (void **)&gOrigGetAddrInfo);
        hooked++;
        NSLog(@"[DualGuard] ✅ hooked getaddrinfo (%p -> orig %p)",
              sym1, (void *)gOrigGetAddrInfo);
    }

    void *sym2 = dlsym(RTLD_DEFAULT, "gethostbyname");
    if (sym2) {
        hookFn(sym2, (void *)DGHookedGethostbyname, (void **)&gOrigGethostbyname);
        hooked++;
    }

    void *sym3 = dlsym(RTLD_DEFAULT, "gethostbyname2");
    if (sym3) {
        hookFn(sym3, (void *)DGHookedGethostbyname2, (void **)&gOrigGethostbyname2);
        hooked++;
    }

    if (hooked > 0) {
        gInstalled = YES;
        NSLog(@"[DualGuard] ✅ DNS 拦截已启用：hook %d 个函数，规则 %lu 条",
              hooked, (unsigned long)DGAdBlockRuleCount());
        DGLog(@"DNS拦截", @"已启用 %@：hook %d 个函数，规则 %lu 条",
              DGBundleIdentifier(), hooked, (unsigned long)DGAdBlockRuleCount());
    } else {
        NSLog(@"[DualGuard] ⚠️ DNS hook 全部失败");
        DGLog(@"DNS拦截", @"安装失败：%d 个符号全部 hook 失败", 3);
    }
}
