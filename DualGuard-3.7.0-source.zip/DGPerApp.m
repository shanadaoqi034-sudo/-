//
//  DGPerApp.m — 按 App 单独配置实现
//

#import "DGPerApp.h"
#import "DGCore.h"
#import <notify.h>

NSString * const DGAppCfgPrefix = @"AppCfg.";

NSString * const DGFeatureMaster   = @"master";
NSString * const DGFeatureDNS      = @"dns";
NSString * const DGFeatureAdSkip   = @"adskip";
NSString * const DGFeatureShake    = @"shake";
NSString * const DGFeatureSensor   = @"sensor";
NSString * const DGFeatureRedirect = @"redirect";
NSString * const DGFeatureStore    = @"store";
NSString * const DGFeatureSafari   = @"safari";
NSString * const DGFeatureBrowser  = @"browser";
NSString * const DGFeatureWeb      = @"web";
NSString * const DGFeatureOtherApp = @"otherapp";
NSString * const DGFeatureAllJump  = @"alljump";

// 传感器细分（3.6.0）
NSString * const DGFeatureSensorAccel    = @"sensoraccel";
NSString * const DGFeatureSensorGyro     = @"sensorgyro";
NSString * const DGFeatureSensorMag      = @"sensormag";
NSString * const DGFeatureSensorMotion   = @"sensormotion";
NSString * const DGFeatureSensorCompass  = @"sensorcompass";
NSString * const DGFeatureSensorLocation = @"sensorloc";

NSString *DGPerAppKey(NSString *feature, NSString *bundleID) {
    if (![feature isKindOfClass:[NSString class]] || !feature.length) return nil;
    if (![bundleID isKindOfClass:[NSString class]] || !bundleID.length) return nil;
    return [NSString stringWithFormat:@"%@%@.%@", DGAppCfgPrefix, feature, bundleID];
}

BOOL DGPerAppBool(NSString *feature, NSString *bundleID, BOOL fallback) {
    NSString *key = DGPerAppKey(feature, bundleID);
    if (!key) return fallback;
    return DGBool(key, fallback);
}

void DGPerAppSet(NSString *feature, NSString *bundleID, BOOL value) {
    NSString *key = DGPerAppKey(feature, bundleID);
    if (!key) return;
    DGSetBool(key, value);
}

void DGPerAppClear(NSString *feature, NSString *bundleID) {
    NSString *key = DGPerAppKey(feature, bundleID);
    if (!key) return;
    DGRemoveKey(key);
}

void DGPerAppClearAll(NSString *bundleID) {
    if (!bundleID.length) return;
    NSString *suffix = [@"." stringByAppendingString:bundleID];
    NSDictionary *prefs = DGPreferences();
    for (NSString *k in prefs) {
        if (![k isKindOfClass:[NSString class]]) continue;
        if ([k hasPrefix:DGAppCfgPrefix] && [k hasSuffix:suffix]) {
            DGRemoveKey(k);
        }
    }
}

BOOL DGPerAppHasAnyOverride(NSString *bundleID) {
    if (!bundleID.length) return NO;
    NSString *suffix = [@"." stringByAppendingString:bundleID];
    NSDictionary *prefs = DGPreferences();
    for (NSString *k in prefs) {
        if (![k isKindOfClass:[NSString class]]) continue;
        if ([k hasPrefix:DGAppCfgPrefix] && [k hasSuffix:suffix]) return YES;
    }
    return NO;
}

NSUInteger DGPerAppOverrideCount(void) {
    NSMutableSet *ids = [NSMutableSet set];
    NSDictionary *prefs = DGPreferences();
    for (NSString *k in prefs) {
        if (![k isKindOfClass:[NSString class]]) continue;
        if (![k hasPrefix:DGAppCfgPrefix]) continue;

        // AppCfg.<feature>.<bundleID>
        NSString *rest = [k substringFromIndex:DGAppCfgPrefix.length];
        NSRange dot = [rest rangeOfString:@"."];
        if (dot.location == NSNotFound) continue;
        NSString *bid = [rest substringFromIndex:dot.location + 1];
        if (bid.length) [ids addObject:bid];
    }
    return ids.count;
}

NSArray<NSString *> *DGPerAppListOverridden(void) {
    NSMutableSet *ids = [NSMutableSet set];
    NSDictionary *prefs = DGPreferences();
    for (NSString *k in prefs) {
        if (![k isKindOfClass:[NSString class]]) continue;
        if (![k hasPrefix:DGAppCfgPrefix]) continue;
        NSString *rest = [k substringFromIndex:DGAppCfgPrefix.length];
        NSRange dot = [rest rangeOfString:@"."];
        if (dot.location == NSNotFound) continue;
        NSString *bid = [rest substringFromIndex:dot.location + 1];
        if (bid.length) [ids addObject:bid];
    }
    return ids.allObjects;
}

// ===========================================================================
//  综合判定
// ===========================================================================

BOOL DGPerAppMasterOn(NSString *bundleID) {
    // 第一层：全局总开关
    if (!DGEnabled()) return NO;

    // 第二层：该 App 的 master（默认继承全局 = 开）
    if (!bundleID.length) return YES;
    return DGPerAppBool(DGFeatureMaster, bundleID, YES);
}

BOOL DGPerAppFeatureOn(NSString *feature, NSString *bundleID, BOOL globalValue) {
    // 三层：全局 → App master → 具体功能
    if (!DGPerAppMasterOn(bundleID)) return NO;
    return DGPerAppBool(feature, bundleID, globalValue);
}
