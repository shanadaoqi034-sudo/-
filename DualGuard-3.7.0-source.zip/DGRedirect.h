//
//  DGRedirect.h — 跳转拦截模块
//
//  【拦截面】
//  在「发起方 App」进程内拦截，不依赖 SpringBoard（那是 arm64e，注入不了）。
//
//  覆盖的跳转方式：
//    1. UIApplication -openURL:options:completionHandler:   iOS 10+ 主入口
//    2. UIApplication -openURL:                            老 API
//    3. UIApplication -canOpenURL:                         探测（不拦会让 App 误判）
//    4. LSApplicationWorkspace -openSensitiveURL:withOptions:
//    5. SFSafariViewController -initWithURL:...            ★ 进程内开网页，广告最常用
//    6. ASWebAuthenticationSession -initWithURL:...        OAuth 容器，常被滥用
//
//  说明：SFSafariViewController 在 App 进程内 present，不走 openURL，
//  所以必须单独 hook，否则「拦截开了但网页照样弹出来」。
//

#import <Foundation/Foundation.h>

// 判定目标 bundle id 属于哪类，返回是否应拦
FOUNDATION_EXPORT BOOL DGRedirectShouldBlockTarget(NSString *targetBundleID, int *kind);

// 判定某 App 是否被加入放行白名单
FOUNDATION_EXPORT BOOL DGRedirectIsSourceBypassed(NSString *sourceBundleID);

// 综合判定：给定发起方和目标的 bundle id，是否拦截
FOUNDATION_EXPORT BOOL DGRedirectShouldBlock(NSString *sourceBundleID, NSString *targetBundleID);

// 从 URL 推断目标 bundle id（itms-apps:// / https://apps.apple.com 等）
FOUNDATION_EXPORT NSString *DGRedirectTargetBundleFromURL(NSURL *url);

// 按 URL scheme 判定是否拦截（用于 taobao:// pinduoduo:// 这类自定义 scheme）
FOUNDATION_EXPORT BOOL DGRedirectShouldBlockScheme(NSString *sourceBundleID, NSString *scheme);

// 判定一个网页 URL 是否该拦（用于 SFSafariViewController / ASWebAuthenticationSession）
//   sourceBundleID: 当前 App
//   url:            要打开的网页
//   返回 YES 表示拦截
FOUNDATION_EXPORT BOOL DGRedirectShouldBlockWebURL(NSString *sourceBundleID, NSURL *url);

// 判定网页 URL 是否属于「广告/推广」特征（纯域名启发式）
FOUNDATION_EXPORT BOOL DGRedirectURLLooksLikeAd(NSURL *url);

// 记录一条拦截日志
FOUNDATION_EXPORT void DGRedirectLogBlock(NSString *sourceBundleID, NSString *targetBundleID);
