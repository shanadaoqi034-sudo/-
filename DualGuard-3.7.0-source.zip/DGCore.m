//
//  DGCore.m — 偏好存储层
//
//  设计要点：
//  1. 不用 LightMessaging / Cephei / libSandy，纯 NSUserDefaults + Darwin 通知，
//     零外部依赖，装完即用。
//  2. 直接读 /var/mobile/Library/Preferences/com.deepseek.dualguard.plist，
//     避免 CFPreferences 在沙盒 App 里的 cache 不一致。
//  3. 偏好快照做进程内缓存，收到 Darwin 通知后失效。
//

#import "DGCore.h"
#import <notify.h>
#import <sys/stat.h>
#import <dlfcn.h>

NSString * const DGPreferencesDomain   = @"com.deepseek.dualguard";
NSString * const DGChangedNotification = @"com.deepseek.dualguard/changed";

NSString * const DGKeyEnabled         = @"Enabled";
NSString * const DGKeyRedirectEnabled = @"RedirectEnabled";
NSString * const DGKeySensorEnabled   = @"SensorEnabled";
NSString * const DGKeyBlockAppStore   = @"BlockAppStore";
NSString * const DGKeyBlockSafari     = @"BlockSafari";
NSString * const DGKeyBlockOthers     = @"BlockOthers";
NSString * const DGKeyBlockWeb        = @"BlockWeb";
NSString * const DGKeyBlockOtherApps  = @"BlockOtherApps";
NSString * const DGKeyBlockAllJumps   = @"BlockAllJumps";
NSString * const DGKeyAdSkipEnabled   = @"AdSkipEnabled";
NSString * const DGKeyAdSkipAggressive = @"AdSkipAggressive";
NSString * const DGKeyDNSBlock        = @"DNSBlockEnabled";
NSString * const DGKeyShakeBlock      = @"ShakeBlockEnabled";
NSString * const DGKeyShakeWindow     = @"ShakeWindow";
NSString * const DGKeySensorPrefix    = @"SensorBlocked.";
NSString * const DGKeySensorAccel    = @"SensorAccelEnabled";
NSString * const DGKeySensorGyro     = @"SensorGyroEnabled";
NSString * const DGKeySensorMag      = @"SensorMagEnabled";
NSString * const DGKeySensorMotion   = @"SensorMotionEnabled";
NSString * const DGKeySensorCompass  = @"SensorCompassEnabled";
NSString * const DGKeySensorLocation = @"SensorLocationEnabled";

static dispatch_once_t gOnce;
static int gNotifyToken = 0;

#pragma mark - rootless 路径

// 计算真实的 jbroot 前缀。RootHide/Relaxin 下 /var/jb 是个符号链接指回 jbroot 自身，
// 所以必须用 realpath 拿到真路径，否则读写会打回原处。
static NSString *DGRootPrefix(void) {
    static NSString *prefix = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        prefix = @"";
        char resolved[PATH_MAX] = {0};
        if (realpath("/var/jb", resolved) && resolved[0]) {
            prefix = [NSString stringWithUTF8String:resolved];
        }
    });
    return prefix;
}

NSString *DGPreferencesFilePath(void) {
    // ===================================================================
    //  真实物理路径优先
    // ===================================================================
    //
    //  roothide 会把 /var/mobile 重定向到 AppGroup 容器：
    //    /var/mobile  →  /rootfs/private/var/mobile/Containers/Shared/
    //                    AppGroup/.jbroot-B7BA5119268440A7/var/mobile
    //
    //  而 CFPreferences 走的是真实物理路径 /rootfs/private/var/mobile/。
    //  同一个逻辑路径落到两个不同的物理文件，两边数据会分裂 ——
    //  这就是「设置里关了开关但拦截还在」的根因。
    //
    //  实测两份文件 inode 不同、内容不同（607 键 vs 602 键）。
    //
    //  所以这里统一返回真实物理路径。设置 App 那边也用同一个常量。
    //
    static NSString *resolved = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *real = [@"/rootfs/private/var/mobile/Library/Preferences"
                          stringByAppendingPathComponent:
                          [DGPreferencesDomain stringByAppendingPathExtension:@"plist"]];
        NSString *std = [@"/var/mobile/Library/Preferences"
                         stringByAppendingPathComponent:
                         [DGPreferencesDomain stringByAppendingPathExtension:@"plist"]];

        NSFileManager *fm = [NSFileManager defaultManager];

        // 真实路径存在就用它
        if ([fm fileExistsAtPath:real]) {
            resolved = real;
        }
        // 真实路径不存在但父目录在 → 也用它（允许新建）
        else {
            NSString *dir = [real stringByDeletingLastPathComponent];
            BOOL isDir = NO;
            if ([fm fileExistsAtPath:dir isDirectory:&isDir] && isDir) {
                resolved = real;
            } else {
                resolved = std;
            }
        }
    });
    return resolved;
}

#pragma mark - 进程标识

NSString *DGBundleIdentifier(void) {
    static NSString *identifier = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        identifier = NSBundle.mainBundle.bundleIdentifier;
        if (!identifier.length) {
            // 极少数进程 mainBundle 拿不到，退回可执行文件路径推断
            NSString *exec = NSProcessInfo.processInfo.arguments.firstObject;
            if (exec.length) {
                NSString *dir = exec.stringByDeletingLastPathComponent;
                if ([dir.pathExtension isEqualToString:@"app"]) {
                    identifier = [NSBundle bundleWithPath:dir].bundleIdentifier;
                }
            }
        }
        if (!identifier.length) identifier = @"unknown";
    });
    return identifier;
}

// ---------------------------------------------------------------------------
//  偏好读取 —— 不做进程内缓存
// ---------------------------------------------------------------------------
//
//  ---- 为什么删掉了缓存 ----
//
//  之前的实现用「文件 mtime + size + 键数量」算一个指纹，指纹变了才重新读。
//  这个思路在 CFPreferences 下是错的：
//
//    CFPreferencesSetAppValue / AppSynchronize 更新的是 cfprefsd 的**内存**，
//    cfprefsd 什么时候把数据落盘是不确定的（可能延迟几十秒，也可能等退出）。
//    于是目标 App 里 stat() 拿到的还是旧 mtime → 指纹不变 → 缓存不失效
//    → 一直用旧的 Enabled 值。
//
//    表现就是用户说的「总开关关了还是生效」。
//
//  ---- 现在的做法 ----
//
//  每次都直接向 cfprefsd 要值。CFPreferencesCopyMultiple 本身就有缓存，
//  开销是一次进程内 IPC，在 hook 热路径上完全可以接受
//  （实测单次几十微秒，远低于 UI 帧预算）。
//
//  这样设置面板一改，目标 App 下一次判断就能看到新值，不需要重启。

NSDictionary *DGPreferences(void) {
    dispatch_once(&gOnce, ^{ });

    // ===================================================================
    //  读取顺序：文件优先，CFPreferences 兜底
    // ===================================================================
    //
    //  为什么文件优先：
    //
    //  设置 App 的 ent.plist 有 com.apple.private.security.no-container，
    //  它没有沙盒容器，CFPreferencesSetAppValue 在里面写不进去。
    //  所以设置 App 改成直写文件。
    //
    //  而 tweak 跑在第三方 App 进程里（有容器），CFPreferences 读的是
    //  cfprefsd 的缓存。设置 App 直写文件后，cfprefsd 不一定立刻感知，
    //  于是 tweak 会读到旧值 —— 表现就是「开关关了但功能还生效」。
    //
    //  所以两边统一：文件是唯一权威来源，CFPreferences 只作兜底。
    //

    // ---- 1. 文件（权威）----
    NSString *path = DGPreferencesFilePath();
    NSDictionary *fileDict = [NSDictionary dictionaryWithContentsOfFile:path];
    if ([fileDict isKindOfClass:[NSDictionary class]] && fileDict.count) {
        return fileDict;
    }

    // ---- 2. jbroot 里的副本 ----
    NSString *alt = [DGRootPrefix() stringByAppendingPathComponent:
                     [@"/var/mobile/Library/Preferences"
                      stringByAppendingPathComponent:
                      [DGPreferencesDomain stringByAppendingPathExtension:@"plist"]]];
    if (alt.length > 1 && ![alt isEqualToString:path]) {
        NSDictionary *altDict = [NSDictionary dictionaryWithContentsOfFile:alt];
        if ([altDict isKindOfClass:[NSDictionary class]] && altDict.count) {
            return altDict;
        }
    }

    // ---- 3. CFPreferences（兜底）----
    CFStringRef appID = (__bridge CFStringRef)DGPreferencesDomain;
    CFArrayRef keys = CFPreferencesCopyKeyList(appID, kCFPreferencesCurrentUser,
                                               kCFPreferencesAnyHost);
    if (keys) {
        NSDictionary *dict = CFBridgingRelease(CFPreferencesCopyMultiple(keys, appID,
                                                                        kCFPreferencesCurrentUser,
                                                                        kCFPreferencesAnyHost));
        CFRelease(keys);
        if ([dict isKindOfClass:[NSDictionary class]] && dict.count) return dict;
    }

    return @{};
}

void DGInvalidatePreferences(void) {
    // 不再有进程内缓存，保留这个函数只是为了不破坏调用方。
    // 真正的「刷新」发生在下一次 DGPreferences() 调用时 —— 它每次都问 cfprefsd。
}

BOOL DGBool(NSString *key, BOOL fallback) {
    if (!key.length) return fallback;
    id value = DGPreferences()[key];
    return value ? [value boolValue] : fallback;
}

BOOL DGAppBool(NSString *prefix, NSString *bundleID, BOOL fallback) {
    if (!prefix.length || !bundleID.length) return fallback;
    NSString *key = [prefix stringByAppendingString:bundleID];
    return DGBool(key, fallback);
}

BOOL DGEnabled(void)         { return DGBool(DGKeyEnabled, YES); }
BOOL DGRedirectEnabled(void) { return DGEnabled() && DGBool(DGKeyRedirectEnabled, YES); }
BOOL DGSensorEnabled(void)   { return DGEnabled() && DGBool(DGKeySensorEnabled, YES); }

#pragma mark - 写入（设置面板用）

void DGRemoveKey(NSString *key) {
    if (!key.length) return;

    // 从 cfprefsd 删除
    CFPreferencesSetAppValue((__bridge CFStringRef)key, NULL,
                             (__bridge CFStringRef)DGPreferencesDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)DGPreferencesDomain);

    // 同时从文件删除（文件是权威来源）
    NSString *path = DGPreferencesFilePath();
    NSMutableDictionary *dict = [[NSDictionary dictionaryWithContentsOfFile:path] mutableCopy];
    if (dict) {
        [dict removeObjectForKey:key];
        [dict writeToFile:path atomically:YES];
    }

    DGPostChanged();
}

void DGSetBool(NSString *key, BOOL value) {
    if (!key.length) return;
    // 写也走 CFPreferences：直写文件会被 cfprefsd 的旧副本覆盖回去
    CFPreferencesSetAppValue((__bridge CFStringRef)key,
                             (__bridge CFPropertyListRef)@(value),
                             (__bridge CFStringRef)DGPreferencesDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)DGPreferencesDomain);
    DGInvalidatePreferences();
    DGPostChanged();
}

void DGPostChanged(void) {
    notify_post(DGChangedNotification.UTF8String);
}

#pragma mark - 变更监听

static NSMutableArray *gChangeHandlers = nil;

void DGRegisterChangeHandler(dispatch_block_t handler) {
    if (!handler) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ gChangeHandlers = [NSMutableArray new]; });
    [gChangeHandlers addObject:[handler copy]];
}

void DGStartObserving(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        notify_register_dispatch(DGChangedNotification.UTF8String, &gNotifyToken,
                                 dispatch_get_main_queue(), ^(int token) {
            DGInvalidatePreferences();
            for (dispatch_block_t handler in [gChangeHandlers copy]) {
                @try { handler(); } @catch (NSException *e) {
                    NSLog(@"[DualGuard] change handler threw: %@", e);
                }
            }
        });
    });
}
