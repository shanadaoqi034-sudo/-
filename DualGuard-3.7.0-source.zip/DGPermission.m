//
//  DGPermission.m — 权限伪装实现
//

#import "DGPermission.h"
#import "DGCore.h"
#import "DGPerApp.h"
#import "DGLog.h"
#import <stdatomic.h>

// ---- per-App 特性名 ----
NSString * const DGFeaturePermPhotos       = @"permphotos";
NSString * const DGFeaturePermContacts     = @"permcontacts";
NSString * const DGFeaturePermCalendar     = @"permcalendar";
NSString * const DGFeaturePermReminders    = @"permreminders";
NSString * const DGFeaturePermMicrophone   = @"permmic";
NSString * const DGFeaturePermCamera       = @"permcamera";
NSString * const DGFeaturePermLocation     = @"permlocation";
NSString * const DGFeaturePermBluetooth    = @"permbluetooth";
NSString * const DGFeaturePermHealth       = @"permhealth";
NSString * const DGFeaturePermNotifications= @"permnotify";

// ---- 全局键 ----
NSString * const DGKeyPermEnabled      = @"PermFakeEnabled";
NSString * const DGKeyPermPhotos       = @"PermFakePhotos";
NSString * const DGKeyPermContacts     = @"PermFakeContacts";
NSString * const DGKeyPermCalendar     = @"PermFakeCalendar";
NSString * const DGKeyPermReminders    = @"PermFakeReminders";
NSString * const DGKeyPermMicrophone   = @"PermFakeMicrophone";
NSString * const DGKeyPermCamera       = @"PermFakeCamera";
NSString * const DGKeyPermLocation     = @"PermFakeLocation";
NSString * const DGKeyPermBluetooth    = @"PermFakeBluetooth";
NSString * const DGKeyPermHealth       = @"PermFakeHealth";
NSString * const DGKeyPermNotifications= @"PermFakeNotifications";

NSString *DGPermissionFeatureForKind(DGPermKind kind) {
    switch (kind) {
        case DGPermKindPhotos:        return DGFeaturePermPhotos;
        case DGPermKindContacts:      return DGFeaturePermContacts;
        case DGPermKindCalendar:      return DGFeaturePermCalendar;
        case DGPermKindReminders:     return DGFeaturePermReminders;
        case DGPermKindMicrophone:    return DGFeaturePermMicrophone;
        case DGPermKindCamera:        return DGFeaturePermCamera;
        case DGPermKindLocation:      return DGFeaturePermLocation;
        case DGPermKindBluetooth:     return DGFeaturePermBluetooth;
        case DGPermKindHealth:        return DGFeaturePermHealth;
        case DGPermKindNotifications: return DGFeaturePermNotifications;
    }
    return DGFeaturePermPhotos;
}

NSString *DGPermissionNameForKind(DGPermKind kind) {
    switch (kind) {
        case DGPermKindPhotos:        return @"相册";
        case DGPermKindContacts:      return @"通讯录";
        case DGPermKindCalendar:      return @"日历";
        case DGPermKindReminders:     return @"提醒事项";
        case DGPermKindMicrophone:    return @"麦克风";
        case DGPermKindCamera:        return @"摄像头";
        case DGPermKindLocation:      return @"定位";
        case DGPermKindBluetooth:     return @"蓝牙";
        case DGPermKindHealth:        return @"健康";
        case DGPermKindNotifications: return @"通知";
    }
    return @"未知权限";
}

static NSString *DGPermissionGlobalKeyForKind(DGPermKind kind) {
    switch (kind) {
        case DGPermKindPhotos:        return DGKeyPermPhotos;
        case DGPermKindContacts:      return DGKeyPermContacts;
        case DGPermKindCalendar:      return DGKeyPermCalendar;
        case DGPermKindReminders:     return DGKeyPermReminders;
        case DGPermKindMicrophone:    return DGKeyPermMicrophone;
        case DGPermKindCamera:        return DGKeyPermCamera;
        case DGPermKindLocation:      return DGKeyPermLocation;
        case DGPermKindBluetooth:     return DGKeyPermBluetooth;
        case DGPermKindHealth:        return DGKeyPermHealth;
        case DGPermKindNotifications: return DGKeyPermNotifications;
    }
    return DGKeyPermPhotos;
}

BOOL DGPermissionEnabled(void) {
    if (!DGEnabled()) return NO;
    return DGBool(DGKeyPermEnabled, NO);
}

BOOL DGPermissionFakeForKind(DGPermKind kind) {
    // 第一层：总开关
    if (!DGPermissionEnabled()) return NO;

    NSString *bid = DGBundleIdentifier();

    // 第二层：全局分项
    BOOL globalOn = DGBool(DGPermissionGlobalKeyForKind(kind), YES);
    if (!globalOn) return NO;

    // 第三层：该 App 的分项（没设过 → 继承全局）
    BOOL on = DGPerAppBool(DGPermissionFeatureForKind(kind), bid, YES);

    static atomic_int logCount = 0;
    int n = atomic_fetch_add(&logCount, 1);
    if (n < 15) {
        DGLog(@"权限伪装", @"%@ 全局=%@ App=%@ → %@ (bid=%@)",
              DGPermissionNameForKind(kind),
              globalOn ? @"开" : @"关",
              DGPermissionFeatureForKind(kind),
              on ? @"伪装" : @"放行", bid);
    }
    return on;
}

void DGPermissionNoteFake(DGPermKind kind, NSString *detail) {
    static atomic_int noteCount = 0;
    int n = atomic_fetch_add(&noteCount, 1);
    if (n < 30) {
        DGLog(@"权限伪装", @"%@ → %@", DGPermissionNameForKind(kind), detail ?: @"");
    }
}
