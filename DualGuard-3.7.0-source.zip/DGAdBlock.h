//
//  DGAdBlock.h — DNS 层广告拦截（进程内 DNS 拦截）
//
//  ⚠️ 仅供学习交流使用
//
//  为什么不用 /etc/hosts：
//    iOS 15+ 使用 SSV（Signed System Volume），系统卷只读。
//    /etc/hosts 在系统卷上，**即使 root 也写不了**（EPERM）。
//    所以 hosts 方案在 iOS 15+ 上不可行。
//
//  本模块改为进程内拦截 DNS 解析：
//    hook getaddrinfo / gethostbyname / getaddrinfo_async
//    命中广告域名时直接返回 0.0.0.0，连接必然失败。
//
//  优点：
//    * 不需要 root，不需要写系统文件
//    * 立即生效，无 DNS 缓存问题
//    * 对 App 内所有网络请求有效（NSURLSession / CFNetwork / socket）
//
//  局限：
//    * 只能覆盖当前进程，所以必须注入每个 App（tweak 本来就做了）
//    * 使用自有 DNS 解析器的 SDK 可能绕过（少见）
//

#import <Foundation/Foundation.h>

// 当前进程是否启用 DNS 拦截
FOUNDATION_EXPORT BOOL DGAdBlockEnabled(void);

// 安装 DNS hook（幂等，在 %ctor 里调用）
FOUNDATION_EXPORT void DGAdBlockInstall(void);

// 判断一个域名是否在广告名单里
FOUNDATION_EXPORT BOOL DGAdBlockIsAdDomain(const char *host);

// 规则数量
FOUNDATION_EXPORT NSUInteger DGAdBlockRuleCount(void);

// 统计：本进程拦截了多少次
FOUNDATION_EXPORT NSUInteger DGAdBlockBlockedCount(void);

// 最近拦截的域名（调试用，最多 50 条）
FOUNDATION_EXPORT NSArray<NSString *> *DGAdBlockRecentHosts(void);

// 清空统计
FOUNDATION_EXPORT void DGAdBlockResetStats(void);
