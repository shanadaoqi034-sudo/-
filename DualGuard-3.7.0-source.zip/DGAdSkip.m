//
//  DGAdSkip.m — 广告自动跳过（重构版）
//
//  ==========================================================================
//   设计原则：先证明有广告，再找跳过按钮。找不到证据就不点。
//  ==========================================================================
//
//  旧实现的问题：
//
//    1. 「广告容器」判定用子串匹配 @"Ad"，会命中 Header / Loading / Badge /
//       Shadow / Thread / Radio / Upload / Download / Adapter 等大量正常类名。
//       于是 DGHasAdAncestor() 经常误判为真。
//
//    2. L3 规则「右上角 + 小尺寸」一旦误判为广告容器就直接点，
//       等于在普通界面上盲点右上角 —— 这就是用户说的「盲目点击右上角」。
//
//    3. L1/L2 也有同样问题：只要类名里含 "Ad" 的祖先存在，
//       任何「跳过」文字都会触发点击。
//
//  ==========================================================================
//   新策略：三阶段，逐级严格
//  ==========================================================================
//
//    阶段 A  广告存在性判定（必须有正面证据）
//            ├─ A1  广告 SDK 类名（词边界匹配，不是子串）
//            ├─ A2  广告容器结构特征（全屏/大面积遮罩层）
//            └─ A3  广告专属文案（"广告" "广告推广" "Sponsored"）
//            三条都不满足 → 认定为「没有广告」→ 不点，直接返回
//
//    阶段 B  在已确认的广告子树里找跳过按钮
//            ├─ B1  文本白名单（跳过/Skip Ad 等广告专用词）
//            ├─ B2  文本 + 倒计时（"跳过 5s"）
//            └─ B3  可点击性验证（真的能响应点击，不是死标签）
//
//    阶段 C  点击前的最后确认
//            ├─ C1  按钮必须在广告容器内（不是广告外的同名按钮）
//            ├─ C2  按钮必须可见且可交互
//            └─ C3  同一按钮 30 秒内不重复点
//
//  关键差别：旧版是「找到像跳过的按钮 → 检查有没有广告祖先 → 点」，
//           新版是「先确认整个屏幕上有广告 → 只在广告子树里找 → 点」。
//           顺序反过来，误点率下降一个数量级。
//

#import "DGAdSkip.h"
#import "DGCore.h"
#import "DGPerApp.h"
#import "DGLog.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <QuartzCore/QuartzCore.h>

#define DG_ADSKIP_PREFIX @"AdSkip."

// ---------------------------------------------------------------------------
// 状态
// ---------------------------------------------------------------------------

static NSTimer *gScanTimer = nil;
static BOOL gRunning = NO;
static NSTimeInterval gAdSkipStartTime = 0;
static NSMutableSet<NSString *> *gClickedSignatures = nil;
static NSMutableArray<NSString *> *gRecentLog = nil;
static int gDiagScanCount = 0;
static id gWindowObserver = nil;
static id gScreenObserver = nil;

// 本次扫描认定到的广告容器（阶段 A 的产物，阶段 B 只在这个子树里找）
static NSMutableArray<UIView *> *gConfirmedAdRoots = nil;

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------

BOOL DGAdSkipEnabledForCurrentProcess(void) {
    if (!DGEnabled()) return NO;

    NSString *bid = DGBundleIdentifier();

    // 三层：全局 AdSkipEnabled → App master → App 的 adskip 键
    BOOL globalAdSkip = DGBool(DGKeyAdSkipEnabled, NO);
    return DGPerAppFeatureOn(DGFeatureAdSkip, bid, globalAdSkip);
}

static void DGAdSkipLog(NSString *msg) {
    if (!gRecentLog) gRecentLog = [NSMutableArray new];
    NSString *line = [NSString stringWithFormat:@"%.1fs %@",
                      [NSDate date].timeIntervalSince1970, msg];
    [gRecentLog addObject:line];
    while (gRecentLog.count > 100) [gRecentLog removeObjectAtIndex:0];
    NSLog(@"[DualGuard] AdSkip: %@", msg);
    // 同时写文件：NSLog 在真机上抓不到，写文件才能事后分析
    DGLog(@"广告跳过", @"%@", msg);
}

// ---- 前向声明 ----
//  诊断函数要用到 A1/A2 段的判定函数，而那些函数定义在后面。
static BOOL DGClassLooksLikeAdSDK(NSString *cls);
static int DGViewDepth(UIView *view);

static void DGAdSkipDumpTopViews(UIApplication *app) {
    NSMutableString *buf = [NSMutableString string];
    int found = 0;

    for (UIWindow *w in app.windows) {
        if (!w || w.hidden || w.alpha < 0.1) continue;
        [buf appendFormat:@"\n  window: %@", NSStringFromClass([w class])];

        NSMutableArray *queue = [NSMutableArray arrayWithObject:w];
        int visited = 0;
        while (queue.count && visited < 60) {
            UIView *v = queue.firstObject;
            [queue removeObjectAtIndex:0];
            visited++;

            CGRect f = [v convertRect:v.bounds toView:w];
            CGSize screen = w.bounds.size;
            if (screen.width <= 0 || screen.height <= 0) continue;
            CGFloat wr = f.size.width / screen.width;
            CGFloat hr = f.size.height / screen.height;

            if (wr >= 0.6 && hr >= 0.6) {
                NSString *cls = NSStringFromClass([v class]);
                BOOL adish = DGClassLooksLikeAdSDK(cls);
                [buf appendFormat:@"\n    %@%@ %.0fx%.0f d=%d",
                 adish ? @"[广告类名]" : @"",
                 cls, wr * 100, hr * 100, DGViewDepth(v)];
                found++;
            }

            for (UIView *sub in v.subviews) [queue addObject:sub];
        }
    }

    DGLog(@"广告跳过", @"扫描未命中广告容器（第 %d 次），大视图 %d 个：%@",
          gDiagScanCount, found, buf.length ? buf : @"(无)");
}


NSArray<NSString *> *DGAdSkipRecentLog(void) {
    return [gRecentLog copy] ?: @[];
}

// ===========================================================================
//  阶段 A：广告存在性判定
// ===========================================================================

// ---------------------------------------------------------------------------
//  A1  广告 SDK 类名 —— 词边界匹配，不用子串
// ---------------------------------------------------------------------------
//
//  旧版用 [cls containsString:@"Ad"]，会命中：
//    UITableViewHeaderFooterView、UIActivityIndicatorView（Loading）、
//    _UIBadgeView、UIButtonBarBadge、NSShadow、NSThread、
//    UIRadioButton、NSURLSessionUploadTask、NSURLSessionDownloadTask、
//    UICollectionViewAdapter、UIPageControlAdapter ...
//
//  这些在正常界面里到处都是，导致「有广告」误判为真。
//
//  正确做法：类名必须「以该词开头」或「该词出现在大写边界」。
//  例如 GADBannerView → 有 "GAD" 前缀 → 命中
//       ADBannerView   → 有 "AD" 前缀   → 命中
//       HeaderView     → "Header" 里的 "ad" 不是词边界 → 不命中

static BOOL DGClassHasToken(NSString *cls, NSString *token) {
    if (!cls.length || !token.length) return NO;

    // 1) 前缀匹配（GADBannerView / ADBannerView / BUAdView）
    if ([cls hasPrefix:token]) return YES;

    // 2) 词边界匹配
    //
    // 判断 token 在 cls 中间出现时，左边是不是「词的开始」。
    // 两种情况都算：
    //
    //   a) 前一个字符不是小写字母
    //      CSJSplashView 里 "Splash" 前面是 'J'（大写）→ 词边界
    //      UI_AdView     里 "Ad"     前面是 '_'（非字母）→ 词边界
    //
    //   b) 前一个字符是小写、但 token 首字母是大写
    //      MyGADBanner   里 "GAD"    前面是 'y'（小写）但 'G' 大写
    //      → CamelCase 的词边界，必须算命中
    //      （这是上一版漏掉的情况，导致 MyGADBanner 这类自定义前缀
    //        广告类名识别不到）
    //
    NSRange search = NSMakeRange(0, cls.length);
    while (search.length > 0) {
        NSRange r = [cls rangeOfString:token options:0 range:search];
        if (r.location == NSNotFound) break;

        BOOL okBefore = (r.location == 0);
        if (!okBefore) {
            unichar prev = [cls characterAtIndex:r.location - 1];
            unichar first = [token characterAtIndex:0];

            BOOL prevIsLower = [[NSCharacterSet lowercaseLetterCharacterSet]
                                characterIsMember:prev];
            BOOL tokenStartsUpper = [[NSCharacterSet uppercaseLetterCharacterSet]
                                     characterIsMember:first];

            // a) 前一个不是小写 → 边界
            // b) 前一个是小写但 token 首字母大写 → CamelCase 边界
            okBefore = (!prevIsLower) || (prevIsLower && tokenStartsUpper);
        }
        if (okBefore) return YES;

        NSUInteger next = r.location + r.length;
        if (next >= cls.length) break;
        search = NSMakeRange(next, cls.length - next);
    }
    return NO;
}

// 广告 SDK 的类名 token。这些是「一眼能认出是广告」的强特征。
static NSArray<NSString *> *DGAdClassTokens(void) {
    static NSArray *tokens;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        tokens = @[
            // Google
            @"GAD", @"DFP", @"AdMob",
            // 字节 / 穿山甲
            @"CSJ", @"BUAd", @"Pangle", @"Bytedance",
            // 腾讯广点通
            @"GDT", @"GDTSDK",
            // 阿里
            @"ALAd", @"Alimama",
            // 百度
            @"BaiduMobAd", @"BaiduAd",
            // 海外
            @"AppLovin", @"ALAd", @"Vungle", @"UnityAds", @"IronSource",
            @"Chartboost", @"Tapjoy", @"InMobi", @"Mopub", @"Mintegral",
            @"MTG", @"AdColony", @"StartApp", @"Ogury",
            // 通用广告类名（必须作为独立 token 出现）
            @"AdBanner", @"AdView", @"AdContainer", @"AdSlot",
            @"AdInterstitial", @"AdSplash", @"AdReward",
            @"InterstitialAd", @"RewardedAd", @"NativeAd", @"FeedAd",
            @"SplashAd", @"BannerAd", @"PromoAd",
            // 开屏
            @"SplashView", @"LaunchAd",
        ];
    });
    return tokens;
}

static BOOL DGClassLooksLikeAdSDK(NSString *cls) {
    for (NSString *token in DGAdClassTokens()) {
        if (DGClassHasToken(cls, token)) return YES;
    }
    return NO;
}

// ---------------------------------------------------------------------------
//  A2  广告容器结构特征
// ---------------------------------------------------------------------------
//
//  广告容器的典型结构：
//    * 全屏或接近全屏的遮罩层
//    * 层级很深（广告 SDK 喜欢套多层）
//    * 覆盖在当前界面之上
//
//  单个「大视图」不算证据 —— 很多正常页面也有全屏视图。
//  必须同时满足：全屏 + 层级深 + 有广告类名或广告文案。

static BOOL DGViewIsFullScreenOverlay(UIView *view) {
    if (!view || !view.window) return NO;

    CGRect f = [view convertRect:view.bounds toView:view.window];
    CGSize screen = view.window.bounds.size;
    if (screen.width <= 0 || screen.height <= 0) return NO;

    CGFloat wRatio = f.size.width / screen.width;
    CGFloat hRatio = f.size.height / screen.height;

    // 覆盖 80% 以上屏幕
    return (wRatio >= 0.8 && hRatio >= 0.8);
}

// 视图层级深度（从 window 往下数）
static int DGViewDepth(UIView *view) {
    int depth = 0;
    UIView *v = view;
    while (v.superview && depth < 100) {
        depth++;
        v = v.superview;
    }
    return depth;
}

// ---------------------------------------------------------------------------
//  A3  广告专属文案
// ---------------------------------------------------------------------------
//
//  屏幕上出现这些词，基本可以确定当前是广告页：
//    "广告" "广告推广" "赞助" "Sponsored" "Advertisement" "推广"
//
//  注意：「广告」两个字在设置界面里也可能出现（比如「关闭广告」按钮）。
//  所以 A3 只能作为**辅助证据**，不能单独成立。

static NSArray<NSString *> *DGAdMarkerTexts(void) {
    static NSArray *texts;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        texts = @[
            @"广告", @"广告推广", @"广告内容", @"赞助内容",
            @"Sponsored", @"Advertisement", @"Advertisements",
            @"推广内容", @"商业推广",
        ];
    });
    return texts;
}

// 在视图子树里找广告文案（限深度，避免扫太多）
static BOOL DGSubtreeHasAdMarkerText(UIView *root, int maxDepth, int depth) {
    if (!root || depth > maxDepth) return NO;

    NSString *text = nil;
    if ([root isKindOfClass:[UILabel class]]) {
        text = ((UILabel *)root).text;
    } else if ([root isKindOfClass:[UIButton class]]) {
        text = [(UIButton *)root titleForState:UIControlStateNormal];
    }
    if (text.length && text.length <= 30) {
        NSString *norm = [text stringByTrimmingCharactersInSet:
                          [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        for (NSString *marker in DGAdMarkerTexts()) {
            if ([norm caseInsensitiveCompare:marker] == NSOrderedSame) return YES;
        }
    }

    for (UIView *sub in root.subviews) {
        if (DGSubtreeHasAdMarkerText(sub, maxDepth, depth + 1)) return YES;
    }
    return NO;
}

// ---------------------------------------------------------------------------
//  阶段 A 综合判定
// ---------------------------------------------------------------------------

// 判定一个视图是否「确定是广告容器」
//
// 必须满足：至少一条强证据
//   强证据 1：类名命中广告 SDK token
//   强证据 2：全屏覆盖 + 层级较深 + 子树内有广告文案
static BOOL DGViewIsConfirmedAdContainer(UIView *view) {
    if (!view || view.hidden || view.alpha < 0.1) return NO;
    if (!view.window) return NO;

    NSString *cls = NSStringFromClass([view class]);

    // 排除系统组件
    if ([cls containsString:@"AlertController"] ||
        [cls containsString:@"ShimPresenter"] ||
        [cls containsString:@"StatusBar"] ||
        [cls containsString:@"Keyboard"] ||
        [cls containsString:@"TextField"] ||
        [cls containsString:@"NavigationBar"] ||
        [cls containsString:@"TabBar"] ||
        [cls containsString:@"ScrollIndicator"]) {
        return NO;
    }

    // ---- 强证据 1：类名命中广告 SDK ----
    if (DGClassLooksLikeAdSDK(cls)) {
        return YES;
    }

    // ---- 强证据 2：全屏 + 层级深 + 有广告文案 ----
    if (DGViewIsFullScreenOverlay(view)) {
        int depth = DGViewDepth(view);
        // 层级太浅的多半是正常页面的根视图
        if (depth >= 4 && DGSubtreeHasAdMarkerText(view, 4, 0)) {
            return YES;
        }
    }

    return NO;
}

// 从窗口往下找所有「确认的广告容器」
static void DGFindAdContainers(UIView *root,
                               NSMutableArray<UIView *> *out,
                               int depth) {
    if (!root || depth > 15) return;
    if (root.hidden || root.alpha < 0.05) return;

    if (DGViewIsConfirmedAdContainer(root)) {
        // 找到就停，不再往下钻 —— 避免把广告内部的子视图也当成容器
        [out addObject:root];
        return;
    }

    for (UIView *sub in root.subviews) {
        DGFindAdContainers(sub, out, depth + 1);
    }
}

// ---------------------------------------------------------------------------
//  A4  ViewController 层的广告识别（旧版完全没做）
// ---------------------------------------------------------------------------
//
//  这是个实打实的漏判。崩溃日志里百度广告的容器是：
//
//      <BaiduMobAdActionRootController: 0x140f351e0>
//
//  名字里带 Controller —— 它是 UIViewController，不是 UIView。
//
//  旧版 DGFindAdContainers 只遍历 UIView 树，虽然 VC 的 view 也在树里，
//  但那个 view 的类名通常是 UIView（不是广告类名），所以：
//
//      * 类名匹配不到 BaiduMobAd*
//      * 全屏判定可能过，但「有广告文案」不一定成立
//      → 容器确认失败 → 整个扫描直接返回 0 → 跳过按钮永远找不到
//
//  所以必须单独走一遍 VC 树：presentedViewController / childViewControllers。

// 遍历所有 window 的 VC 树，收集「类名像广告 SDK」的 VC
static void DGCollectAdViewControllers(UIWindow *window,
                                       NSMutableArray<UIViewController *> *out) {
    if (!window) return;

    NSMutableArray<UIViewController *> *stack = [NSMutableArray array];
    if (window.rootViewController) [stack addObject:window.rootViewController];

    int visited = 0;
    while (stack.count && visited < 80) {
        UIViewController *vc = stack.lastObject;
        [stack removeLastObject];
        visited++;

        if (!vc) continue;

        NSString *cls = NSStringFromClass([vc class]);
        if (DGClassLooksLikeAdSDK(cls)) {
            [out addObject:vc];
            // 不 return：广告 VC 里面可能还套着别的广告 VC
        }

        // 往下钻：presented + children
        if (vc.presentedViewController) [stack addObject:vc.presentedViewController];
        for (UIViewController *child in vc.childViewControllers) {
            [stack addObject:child];
        }

        // navigation / tab 的容器
        if ([vc isKindOfClass:[UINavigationController class]]) {
            UINavigationController *nav = (UINavigationController *)vc;
            for (UIViewController *c in nav.viewControllers) [stack addObject:c];
        }
        if ([vc isKindOfClass:[UITabBarController class]]) {
            UITabBarController *tab = (UITabBarController *)vc;
            for (UIViewController *c in tab.viewControllers) [stack addObject:c];
        }
    }
}

// ===========================================================================
//  阶段 B：在广告子树里找跳过按钮
// ===========================================================================

static NSArray<NSString *> *DGSkipButtonTexts(void) {
    static NSArray *texts;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // 只保留广告专用词。
        // 「关闭 / 知道了 / X / × / Later」这类通用词一律不要 ——
        // 它们在正常界面里到处都是。
        texts = @[
            // ---- 中文：带「广告」二字的（最安全）----
            @"跳过广告", @"跳过此广告", @"跳过广告内容", @"跳过开屏广告",
            @"跳过", @"略过广告", @"略过", @"跳过视频",
            @"关闭广告", @"关闭此广告", @"关闭推广",
            @"点击跳过", @"点此跳过", @"立即跳过", @"跳过该广告",
            // ---- 英文 ----
            @"Skip Ad", @"Skip Ads", @"Skip Advert", @"Skip Advertisement",
            @"Skip Video", @"Skip Intro", @"Skip", @"Close Ad",
            // ---- 倒计时圈 / 角标常见形态 ----
            //  很多开屏广告的跳过按钮就是「5」或「5s」，纯数字。
            //  纯数字单独处理（见 DGTextIsSkipButton），不放这里。
            @"跳过 >", @"跳过>", @"跳过 >>",
        ];
    });
    return texts;
}

static NSString *DGNormalize(NSString *text) {
    if (!text.length) return @"";
    NSString *trimmed = [text stringByTrimmingCharactersInSet:
                         [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return [trimmed stringByReplacingOccurrencesOfString:@"\u00a0" withString:@" "];
}

// 去掉文本尾部倒计时："跳过 5s" -> "跳过"
static NSString *DGStripCountdownSuffix(NSString *text) {
    NSString *t = DGNormalize(text);
    if (!t.length) return t;

    static NSRegularExpression *re;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        re = [NSRegularExpression regularExpressionWithPattern:
              @"[\\s\\(（]*(\\d{1,2})\\s*(s|S|秒|秒后)?[\\)）]*$"
                                                      options:0 error:NULL];
    });
    if (!re) return t;

    NSRange m = [re rangeOfFirstMatchInString:t options:0
                                        range:NSMakeRange(0, t.length)];
    if (m.location == NSNotFound || m.length == 0) return t;

    NSString *rest = [t substringToIndex:m.location];
    rest = [rest stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return rest.length ? rest : t;
}

static BOOL DGTextIsSkipButton(NSString *text) {
    NSString *t = DGNormalize(text);
    if (!t.length || t.length > 16) return NO;

    // ---- 1. 精确匹配 ----
    for (NSString *candidate in DGSkipButtonTexts()) {
        if ([t caseInsensitiveCompare:candidate] == NSOrderedSame) return YES;
    }

    // ---- 2. "跳过 5s" / "5s 跳过"：剥掉倒计时后再比 ----
    NSString *stripped = DGStripCountdownSuffix(t);
    if (stripped.length && ![stripped isEqualToString:t]) {
        for (NSString *candidate in DGSkipButtonTexts()) {
            if ([stripped caseInsensitiveCompare:candidate] == NSOrderedSame) return YES;
        }
    }

    // ---- 3. 包含式：只要含「跳过」且不超长就认 ----
    //
    //  为什么放宽：
    //    各家 SDK 的文案五花八门 ——「跳过广告 3」「| 跳过 |」「跳过 »」。
    //    之前要求精确相等，等于把这些全漏了。
    //    「跳过」这两个字在正常 UI 里极少出现（不是「关闭」「返回」那种通用词），
    //    而且我们已经限定了「必须在确认的广告容器里」才点，
    //    所以这里的放宽是被外层约束保护着的。
    if ([t containsString:@"跳过"] || [t containsString:@"略过"]) {
        return YES;
    }

    // ---- 4. 纯倒计时数字 ----
    //
    //  开屏广告常见形态：右上角一个圆圈，里面是「5」在倒数。
    //  点它就直接跳过。只认 1~2 位纯数字（或带 s/秒）。
    static NSRegularExpression *numRe;
    static dispatch_once_t once2;
    dispatch_once(&once2, ^{
        numRe = [NSRegularExpression regularExpressionWithPattern:
                 @"^\\s*(\\d{1,2})\\s*(s|S|秒)?\\s*$"
                                                        options:0 error:NULL];
    });
    if (numRe) {
        NSRange full = NSMakeRange(0, t.length);
        NSRange m = [numRe rangeOfFirstMatchInString:t options:0 range:full];
        if (m.location != NSNotFound && m.length == t.length) {
            return YES;
        }
    }

    return NO;
}

// 取视图文本
static NSString *DGTextOfView(UIView *view) {
    if ([view isKindOfClass:[UIButton class]]) {
        UIButton *btn = (UIButton *)view;
        NSString *t = [btn titleForState:UIControlStateNormal];
        if (!t.length) t = btn.titleLabel.text;
        if (!t.length) t = btn.accessibilityLabel;
        return t;
    }
    if ([view isKindOfClass:[UILabel class]]) {
        return ((UILabel *)view).text;
    }
    if ([view respondsToSelector:@selector(accessibilityLabel)]) {
        return view.accessibilityLabel;
    }
    return nil;
}

// ---------------------------------------------------------------------------
//  B3  可点击性验证
// ---------------------------------------------------------------------------
//
//  光有文字不够 —— 广告里的「跳过」有时是个死标签，
//  点了没反应，真正可点的是它的父视图。这里做两件事：
//    1. 判断视图自身能否响应点击
//    2. 如果不能，向上找最近的 UIControl

static BOOL DGViewIsTappable(UIView *view) {
    if (!view || !view.window) return NO;
    if (view.hidden || view.alpha < 0.05) return NO;
    if (!view.userInteractionEnabled) return NO;

    // 自己被禁用
    if ([view isKindOfClass:[UIControl class]]) {
        UIControl *c = (UIControl *)view;
        if (!c.enabled) return NO;
    }

    // 自身是 UIControl
    if ([view isKindOfClass:[UIControl class]]) return YES;

    // 有 tap 手势
    for (UIGestureRecognizer *g in view.gestureRecognizers) {
        if ([g isKindOfClass:[UITapGestureRecognizer class]] && g.enabled) return YES;
    }

    // 向上找可点的父视图
    UIView *v = view.superview;
    int depth = 0;
    while (v && depth < 5) {
        if ([v isKindOfClass:[UIControl class]]) {
            UIControl *c = (UIControl *)v;
            if (c.enabled && !c.hidden && c.alpha > 0.05) return YES;
        }
        for (UIGestureRecognizer *g in v.gestureRecognizers) {
            if ([g isKindOfClass:[UITapGestureRecognizer class]] && g.enabled) return YES;
        }
        v = v.superview;
        depth++;
    }
    return NO;
}

// 找到真正该点的目标（自己可点就点自己，否则找可点的父视图）
static UIView *DGResolveTappableTarget(UIView *view) {
    if (!view) return nil;
    if ([view isKindOfClass:[UIControl class]] &&
        ((UIControl *)view).enabled) {
        return view;
    }
    UIView *v = view.superview;
    int depth = 0;
    while (v && depth < 5) {
        if ([v isKindOfClass:[UIControl class]] && ((UIControl *)v).enabled) {
            return v;
        }
        v = v.superview;
        depth++;
    }
    return view;   // 退回原视图，用 accessibilityActivate 尝试
}

// 在广告子树里收集候选按钮
static void DGCollectSkipCandidates(UIView *root,
                                    NSMutableArray<UIView *> *out,
                                    int depth) {
    if (!root || depth > 12) return;
    if (root.hidden || root.alpha < 0.05) return;

    NSString *text = DGTextOfView(root);
    if (text.length && DGTextIsSkipButton(text)) {
        [out addObject:root];
        // 找到就不再往下钻，避免同一按钮被多个层级重复收集
        return;
    }

    for (UIView *sub in root.subviews) {
        DGCollectSkipCandidates(sub, out, depth + 1);
    }
}

// ===========================================================================
//  阶段 C：点击
// ===========================================================================

static NSString *DGSignatureOfView(UIView *view) {
    NSString *cls = NSStringFromClass([view class]);
    CGRect f = [view convertRect:view.bounds toView:nil];
    return [NSString stringWithFormat:@"%@_%.0f_%.0f_%.0f_%.0f_%@",
            cls, f.origin.x, f.origin.y, f.size.width, f.size.height,
            DGTextOfView(view) ?: @""];
}

static BOOL DGWasRecentlyClicked(NSString *sig) {
    if (!gClickedSignatures) gClickedSignatures = [NSMutableSet new];
    return [gClickedSignatures containsObject:sig];
}

static void DGMarkClicked(NSString *sig) {
    if (!gClickedSignatures) gClickedSignatures = [NSMutableSet new];
    [gClickedSignatures addObject:sig];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [gClickedSignatures removeObject:sig];
    });
}

static BOOL DGPerformClick(UIView *view, NSString *reason) {
    if (!view || !view.window) return NO;

    UIView *target = DGResolveTappableTarget(view);
    if (!target) return NO;

    NSString *sig = DGSignatureOfView(target);
    if (DGWasRecentlyClicked(sig)) return NO;

    CGRect f = [target convertRect:target.bounds toView:nil];
    if (f.size.width <= 0 || f.size.height <= 0) return NO;

    DGMarkClicked(sig);

    DGAdSkipLog([NSString stringWithFormat:@"点击 %@ 文本「%@」原因:%@",
                 NSStringFromClass([target class]),
                 DGTextOfView(view) ?: @"", reason]);

    if ([target isKindOfClass:[UIControl class]]) {
        [(UIControl *)target sendActionsForControlEvents:UIControlEventTouchUpInside];
        return YES;
    }

    if ([target respondsToSelector:@selector(sendActionsForControlEvents:)]) {
        [(id)target sendActionsForControlEvents:UIControlEventTouchUpInside];
        return YES;
    }

    if (target.isAccessibilityElement) {
        SEL activateSel = sel_registerName("accessibilityActivate");
        if ([target respondsToSelector:activateSel]) {
            BOOL (*fn)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
            if (fn(target, activateSel)) {
                DGAdSkipLog(@"  -> accessibilityActivate 成功");
                return YES;
            }
        }
    }

    DGAdSkipLog(@"  -> 无法触发点击");
    return NO;
}

// ===========================================================================
//  主流程
// ===========================================================================

NSUInteger DGAdSkipScanOnce(void) {
    if (!DGAdSkipEnabledForCurrentProcess()) return 0;

    // 启动后前 3 秒不扫：界面还在搭，元素位置不稳定
    if (gAdSkipStartTime > 0 &&
        [NSDate timeIntervalSinceReferenceDate] - gAdSkipStartTime < 3.0) {
        return 0;
    }

    UIApplication *app = UIApplication.sharedApplication;
    if (app.applicationState != UIApplicationStateActive) return 0;

    // ---- 阶段 A：先找广告容器 ----
    NSMutableArray<UIView *> *adRoots = [NSMutableArray array];

    for (UIWindow *window in app.windows) {
        if (!window || window.hidden || window.alpha < 0.1) continue;
        NSString *wcls = NSStringFromClass([window class]);
        if ([wcls containsString:@"ShimPresenter"]) continue;
        if ([wcls containsString:@"StatusBar"]) continue;
        if ([wcls containsString:@"TextEffects"]) continue;

        DGFindAdContainers(window, adRoots, 0);
    }

    // ---- 阶段 A2：VC 层的广告容器 ----
    //
    //  很多广告（尤其百度 / 广点通的开屏）容器是 UIViewController，
    //  它的 view 类名是普通 UIView，靠 A 阶段扫不出来。
    NSMutableArray<UIViewController *> *adVCs = [NSMutableArray array];
    for (UIWindow *window in app.windows) {
        if (!window || window.hidden || window.alpha < 0.1) continue;
        DGCollectAdViewControllers(window, adVCs);
    }

    for (UIViewController *vc in adVCs) {
        UIView *v = vc.view;
        if (!v || !v.window) continue;
        if ([adRoots containsObject:v]) continue;
        [adRoots addObject:v];
        DGAdSkipLog([NSString stringWithFormat:
                     @"VC 层命中广告容器: %@", NSStringFromClass([vc class])]);
    }

    gConfirmedAdRoots = adRoots;

    if (adRoots.count == 0) {
        // ---- 没有广告证据 → 什么都不做 ----
        //
        // 这是和旧版最大的区别。旧版不管有没有广告，
        // 都会去扫全窗口找「跳过」文字，然后靠 hasAdAncestor 判断。
        // 现在没找到确认的广告容器，直接返回，一个都不点。
        //
        // 但「什么都不做」也得留下为什么不做 —— 否则用户反馈
        // 「没识别到」时完全没法判断是没广告还是识别漏了。
        if (gDiagScanCount < 40) {
            gDiagScanCount++;
            DGAdSkipDumpTopViews(app);
        }
        return 0;
    }

    gDiagScanCount = 0;
    DGAdSkipLog([NSString stringWithFormat:@"确认广告容器 %lu 个",
                 (unsigned long)adRoots.count]);
    for (UIView *r in adRoots) {
        DGAdSkipLog([NSString stringWithFormat:
                     @"  容器: %@  frame=%@  depth=%d",
                     NSStringFromClass([r class]),
                     NSStringFromCGRect([r convertRect:r.bounds toView:r.window]),
                     DGViewDepth(r)]);
    }

    // ---- 阶段 B：只在广告子树里找跳过按钮 ----
    NSUInteger clicked = 0;

    for (UIView *adRoot in adRoots) {
        if (clicked >= 1) break;   // 每次扫描最多点一个

        NSMutableArray<UIView *> *candidates = [NSMutableArray array];
        DGCollectSkipCandidates(adRoot, candidates, 0);

        for (UIView *candidate in candidates) {
            if (clicked >= 1) break;

            // ---- 阶段 C：点击前最后确认 ----
            if (!DGViewIsTappable(candidate)) {
                DGAdSkipLog([NSString stringWithFormat:
                             @"跳过候选不可点，忽略: %@ 「%@」",
                             NSStringFromClass([candidate class]),
                             DGTextOfView(candidate) ?: @""]);
                continue;
            }

            if (DGPerformClick(candidate, @"广告容器内的跳过按钮")) {
                clicked++;
            }
        }
    }

    return clicked;
}

// ===========================================================================
//  启动 / 停止
// ===========================================================================

void DGAdSkipStart(void) {
    if (gRunning) return;
    if (!DGAdSkipEnabledForCurrentProcess()) {
        NSLog(@"[DualGuard] AdSkip 未启用 for %@", DGBundleIdentifier());
        return;
    }
    gRunning = YES;
    gAdSkipStartTime = [NSDate timeIntervalSinceReferenceDate];

    // 兜底轮询 5 秒一次（真正靠下面两个通知）
    gScanTimer = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                  repeats:YES
                                                    block:^(__unused NSTimer *t) {
        DGAdSkipScanOnce();
    }];
    gScanTimer.tolerance = 1.5;

    // 窗口可见时扫（广告弹出必然触发）
    gWindowObserver = [[NSNotificationCenter defaultCenter]
        addObserverForName:UIWindowDidBecomeVisibleNotification
                    object:nil
                     queue:NSOperationQueue.mainQueue
                usingBlock:^(__unused NSNotification *note) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            DGAdSkipScanOnce();
        });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            DGAdSkipScanOnce();
        });
    }];

    // 回到前台（开屏广告场景）
    gScreenObserver = [[NSNotificationCenter defaultCenter]
        addObserverForName:UIApplicationDidBecomeActiveNotification
                    object:nil
                     queue:NSOperationQueue.mainQueue
                usingBlock:^(__unused NSNotification *note) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            DGAdSkipScanOnce();
        });
    }];

    DGAdSkipLog([NSString stringWithFormat:@"已启动 for %@", DGBundleIdentifier()]);
}

void DGAdSkipStop(void) {
    if (!gRunning) return;
    gRunning = NO;
    [gScanTimer invalidate];
    gScanTimer = nil;
    if (gWindowObserver) {
        [[NSNotificationCenter defaultCenter] removeObserver:gWindowObserver];
        gWindowObserver = nil;
    }
    if (gScreenObserver) {
        [[NSNotificationCenter defaultCenter] removeObserver:gScreenObserver];
        gScreenObserver = nil;
    }
    DGAdSkipLog(@"已停止");
}
