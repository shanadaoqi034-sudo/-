//
//  DGRedirect.m — 跳转拦截判定
//

#import "DGRedirect.h"
#import "DGCore.h"
#import "DGPerApp.h"

static NSArray<NSString *> *DGAppStoreIDs(void) {
    static NSArray *ids;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ids = @[
            @"com.apple.AppStore",
            @"com.apple.storekit",
            @"com.apple.MobileStore",
            @"com.apple.store.Jolly",
            @"com.apple.store.amsui",
        ];
    });
    return ids;
}

static NSArray<NSString *> *DGSafariIDs(void) {
    static NSArray *ids;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ids = @[
            @"com.apple.mobilesafari",
            @"com.apple.SafariViewService",
            @"com.apple.Safari",
        ];
    });
    return ids;
}

static NSArray<NSString *> *DGBrowserIDs(void) {
    static NSArray *ids;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ids = @[
            @"com.google.chrome.ios",
            @"com.brave.ios.browser",
            @"org.mozilla.ios.Firefox",
            @"com.microsoft.edgemac",
            @"com.quark.iphone",
            @"com.tencent.mttlite",
            @"com.ucweb.iphone.lite",
        ];
    });
    return ids;
}

BOOL DGRedirectShouldBlockTarget(NSString *targetBundleID, int *kind) {
    if (!targetBundleID.length) return NO;

    if ([DGAppStoreIDs() containsObject:targetBundleID]) {
        if (kind) *kind = 0;
        return DGBool(DGKeyBlockAppStore, YES);
    }
    if ([DGSafariIDs() containsObject:targetBundleID]) {
        if (kind) *kind = 1;
        return DGBool(DGKeyBlockSafari, YES);
    }
    if ([DGBrowserIDs() containsObject:targetBundleID]) {
        if (kind) *kind = 2;
        return DGBool(DGKeyBlockOthers, NO);
    }
    if (kind) *kind = -1;
    return NO;
}

BOOL DGRedirectIsSourceBypassed(NSString *sourceBundleID) {
    if (!sourceBundleID.length) return NO;

    // 新结构：该 App 的 redirect 功能被单独关掉 → 视为放行
    // 三层优先级由 DGPerAppFeatureOn 处理：
    //   全局 RedirectEnabled → App master → App 的 redirect 键
    BOOL globalRedirect = DGBool(DGKeyRedirectEnabled, YES);
    return !DGPerAppFeatureOn(DGFeatureRedirect, sourceBundleID, globalRedirect);
}

BOOL DGRedirectShouldBlock(NSString *sourceBundleID, NSString *targetBundleID) {
    if (!DGRedirectEnabled()) return NO;
    if (!sourceBundleID.length || !targetBundleID.length) return NO;
    if ([sourceBundleID isEqualToString:targetBundleID]) return NO;
    if (DGRedirectIsSourceBypassed(sourceBundleID)) return NO;

    // 该 App 的跳转拦截总开关
    if (!DGPerAppBool(DGFeatureRedirect, sourceBundleID, YES)) return NO;

    // 按目标类型分别判定，每类都可单独 per-App 覆盖
    NSString *feature = nil;
    BOOL globalDefault = NO;

    if ([DGAppStoreIDs() containsObject:targetBundleID]) {
        feature = DGFeatureStore;
        globalDefault = DGBool(DGKeyBlockAppStore, YES);
    } else if ([DGSafariIDs() containsObject:targetBundleID]) {
        feature = DGFeatureSafari;
        globalDefault = DGBool(DGKeyBlockSafari, YES);
    } else if ([DGBrowserIDs() containsObject:targetBundleID]) {
        feature = DGFeatureBrowser;
        globalDefault = DGBool(DGKeyBlockOthers, NO);
    }

    if (feature) {
        return DGPerAppBool(feature, sourceBundleID, globalDefault);
    }

    if (DGRedirectShouldBlockTarget(targetBundleID, NULL)) return YES;

    // 兜底：任何「跳出当前 App」的行为，只要不是自己，都算跳转。
    // 这是「拦截所有外部跳转」开关（默认关，开了最严格）。
    if (DGBool(DGKeyBlockAllJumps, NO)) {
        NSLog(@"[DualGuard] blocked any-jump %@ -> %@", sourceBundleID, targetBundleID);
        return YES;
    }
    return NO;
}

// 从 scheme 推断目标 App（用于非标准 scheme，如 taobao:// pinduoduo://）
// 这些广告常跳的电商/短视频 App，如果开了「拦截其他 App 跳转」就拦
BOOL DGRedirectShouldBlockScheme(NSString *sourceBundleID, NSString *scheme) {
    if (!DGRedirectEnabled()) return NO;
    if (!sourceBundleID.length || !scheme.length) return NO;
    if (DGRedirectIsSourceBypassed(sourceBundleID)) return NO;

    NSString *s = scheme.lowercaseString;

    // 系统关键 scheme 不能拦（会搞坏系统功能）
    static NSArray *allowed;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        allowed = @[@"tel", @"telprompt", @"sms", @"mailto", @"facetime",
                    @"facetime-audio", @"maps", @"http", @"https",
                    @"about", @"javascript", @"data", @"file"];
    });
    if ([allowed containsObject:s]) return NO;

    // 自家 scheme
    if ([s containsString:@"deepseek"]) return NO;

    // App Store
    if ([s hasPrefix:@"itms"]) {
        return DGBool(DGKeyBlockAppStore, YES);
    }

    // 其他任意 scheme -> 看「拦截其他 App 跳转」开关
    if (DGBool(DGKeyBlockOtherApps, NO)) {
        NSLog(@"[DualGuard] blocked scheme %@:// from %@", s, sourceBundleID);
        return YES;
    }
    return NO;
}

// ---------------------------------------------------------------------------
// URL -> 目标 bundle id
// ---------------------------------------------------------------------------

NSString *DGRedirectTargetBundleFromURL(NSURL *url) {
    if (!url) return nil;
    NSString *scheme = url.scheme.lowercaseString;
    NSString *host = url.host.lowercaseString;

    // itms-apps:// / itms-services:// -> App Store
    if ([scheme hasPrefix:@"itms"]) {
        return @"com.apple.AppStore";
    }
    // https://apps.apple.com/... -> App Store
    if ([host isEqualToString:@"apps.apple.com"] ||
        [host isEqualToString:@"itunes.apple.com"]) {
        return @"com.apple.AppStore";
    }
    // http(s) -> 浏览器（Safari 会接管）
    if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"]) {
        return @"com.apple.mobilesafari";
    }
    // 其他 scheme：把 scheme 当作目标 App 的近似标识
    // 常见映射
    if ([scheme isEqualToString:@"tel"] || [scheme isEqualToString:@"telprompt"]) return @"com.apple.mobilephone";
    if ([scheme isEqualToString:@"sms"]) return @"com.apple.MobileSMS";
    if ([scheme isEqualToString:@"mailto"]) return @"com.apple.mobilemail";
    if ([scheme isEqualToString:@"maps"]) return @"com.apple.Maps";

    return nil;
}

void DGRedirectLogBlock(NSString *sourceBundleID, NSString *targetBundleID) {
    if (!sourceBundleID.length) sourceBundleID = @"?";
    if (!targetBundleID.length) targetBundleID = @"?";
    NSLog(@"[DualGuard] blocked %@ -> %@", sourceBundleID, targetBundleID);
}

// ---------------------------------------------------------------------------
// 网页类拦截（SFSafariViewController / ASWebAuthenticationSession）
// ---------------------------------------------------------------------------
//
// 判定策略（保守，避免误伤）：
//   1. App Store 链接（itms-apps / apps.apple.com）-> 拦（受 BlockAppStore 控制）
//   2. 已知广告域名 -> 拦（受 BlockSafari / BlockOthers 控制）
//   3. 普通网页 -> 看「拦截网页」总开关
//
// 为什么不能见网页就拦：
//   很多 App 的正常功能（登录、帮助、条款、支付）都走 SFSafariViewController。
//   全拦会把 App 用废。所以给一个独立开关，默认关。

static NSArray<NSString *> *DGAdDomainPatterns(void) {
    static NSArray *patterns;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        patterns = @[
            // Apple 推广
            @"apps.apple.com", @"itunes.apple.com",
            // 常见广告联盟 / 推广短链
            @"ad.", @"ads.", @"advert", @"doubleclick", @"googlesyndication",
            @"googleadservices", @"admob", @"applovin", @"unityads",
            @"vungle", @"chartboost", @"ironsrc", @"supersonicads",
            @"tapjoy", @"inmobi", @"mopub", @"pangle", @"mintegral",
            @"bytedance", @"pangolin", @"kuaishou", @"csj",
            // 常见国内推广
            @"cpro.baidu", @"pos.baidu", @"union.baidu",
            @"gdt.qq.com", @"e.qq.com", @"adsmind",
            @"tanx.com", @"alimama", @"mmstat",
            // 落地页特征
            @"landing", @"promo", @"campaign", @"click.", @"track.",
            @"redirect.", @"link.", @"jump.", @"dl.", @"down.",
        ];
    });
    return patterns;
}

BOOL DGRedirectURLLooksLikeAd(NSURL *url) {
    if (!url) return NO;
    NSString *host = url.host.lowercaseString;
    NSString *abs = url.absoluteString.lowercaseString;
    if (!host.length && !abs.length) return NO;

    for (NSString *pattern in DGAdDomainPatterns()) {
        // 域名包含匹配（对 ad./ads. 这类前缀用 hasPrefix）
        if ([host hasPrefix:pattern] || [host containsString:pattern]) return YES;
        if ([abs containsString:pattern]) return YES;
    }
    return NO;
}

BOOL DGRedirectShouldBlockWebURL(NSString *sourceBundleID, NSURL *url) {
    if (!DGRedirectEnabled()) return NO;
    if (!url) return NO;
    if (!sourceBundleID.length) return NO;
    if (DGRedirectIsSourceBypassed(sourceBundleID)) return NO;

    NSString *scheme = url.scheme.lowercaseString;
    NSString *host = url.host.lowercaseString;

    // 1) App Store 链接
    BOOL isStoreLink = [scheme hasPrefix:@"itms"] ||
                       [host isEqualToString:@"apps.apple.com"] ||
                       [host isEqualToString:@"itunes.apple.com"];
    if (isStoreLink) {
        BOOL block = DGBool(DGKeyBlockAppStore, YES);
        if (block) {
            NSLog(@"[DualGuard] blocked store web url from %@: %@",
                  sourceBundleID, host ?: scheme);
        }
        return block;
    }

    // 2) 广告特征域名
    if (DGRedirectURLLooksLikeAd(url)) {
        BOOL block = DGBool(DGKeyBlockOthers, YES);
        if (block) {
            NSLog(@"[DualGuard] blocked ad web url from %@: %@",
                  sourceBundleID, host ?: url.absoluteString);
        }
        return block;
    }

    // 3) 普通网页：看独立开关
    BOOL blockAllWeb = DGBool(DGKeyBlockWeb, NO);
    if (blockAllWeb) {
        NSLog(@"[DualGuard] blocked web url from %@: %@", sourceBundleID, host ?: scheme);
    }
    return blockAllWeb;
}
