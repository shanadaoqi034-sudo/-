//
//  DGPermissionHooks.xm — 权限伪装的 hook 本体
//
//  ⚠️ 仅供学习交流使用
//  作者 QQ：2836226951    交流群：724179606
//
//  单独一个 .xm 是因为 Logos 的 %hook 必须放 .xm，
//  而 DGPermission.m 里的纯逻辑要给设置 App 共用，不能混。
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
#import <Contacts/Contacts.h>
#import <EventKit/EventKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UserNotifications/UserNotifications.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <HealthKit/HealthKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import "DGPermission.h"
#import "DGCore.h"
#import "DGLog.h"

// ===========================================================================
//  1. 相册
// ===========================================================================
//
//  PHPhotoLibrary.authorizationStatus 决定 App 走哪个分支。
//  返回 Authorized 后，App 会去 fetchAssets。
//  所以必须同时让 fetch 返回空 —— 否则等于真授权了。

%group PermPhotoHooks

%hook PHPhotoLibrary

+ (PHAuthorizationStatus)authorizationStatus {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        DGPermissionNoteFake(DGPermKindPhotos, @"authorizationStatus → Authorized");
        return PHAuthorizationStatusAuthorized;
    }
    return %orig;
}

+ (PHAuthorizationStatus)authorizationStatusForAccessLevel:(PHAccessLevel)accessLevel {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        return PHAuthorizationStatusAuthorized;
    }
    return %orig;
}

+ (void)requestAuthorization:(void (^)(PHAuthorizationStatus status))handler {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        DGPermissionNoteFake(DGPermKindPhotos, @"requestAuthorization → 直接回调 Authorized，不弹框");
        if (handler) handler(PHAuthorizationStatusAuthorized);
        return;
    }
    %orig;
}

+ (void)requestAuthorizationForAccessLevel:(PHAccessLevel)accessLevel
                                   handler:(void (^)(PHAuthorizationStatus status))handler {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        if (handler) handler(PHAuthorizationStatusAuthorized);
        return;
    }
    %orig;
}

%end

// ---- PHAsset 查询：返回空 ----

%hook PHAsset

+ (PHFetchResult<PHAsset *> *)fetchAssetsWithOptions:(PHFetchOptions *)options {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        DGPermissionNoteFake(DGPermKindPhotos, @"fetchAssetsWithOptions → 空结果");
        return (PHFetchResult<PHAsset *> *)[PHFetchResult new];
    }
    return %orig;
}

+ (PHFetchResult<PHAsset *> *)fetchAssetsWithMediaType:(PHAssetMediaType)mediaType
                                               options:(PHFetchOptions *)options {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        return (PHFetchResult<PHAsset *> *)[PHFetchResult new];
    }
    return %orig;
}

%end

%hook PHAssetCollection

+ (PHFetchResult<PHAssetCollection *> *)fetchAssetCollectionsWithType:(PHAssetCollectionType)type
                                                              subtype:(PHAssetCollectionSubtype)subtype
                                                              options:(PHFetchOptions *)options {
    if (DGPermissionFakeForKind(DGPermKindPhotos)) {
        return (PHFetchResult<PHAssetCollection *> *)[PHFetchResult new];
    }
    return %orig;
}

%end

%end

// ===========================================================================
//  2. 通讯录
// ===========================================================================
//
//  iOS 9+ 是 CNContactStore，更老的是 ABAddressBook。
//  CNContactStore 的 requestAccessForEntityType 会弹框，必须拦。

%group PermContactHooks

%hook CNContactStore

- (CNAuthorizationStatus)authorizationStatusForEntityType:(CNEntityType)entityType {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        DGPermissionNoteFake(DGPermKindContacts, @"authorizationStatus → Authorized");
        return CNAuthorizationStatusAuthorized;
    }
    return %orig;
}

- (void)requestAccessForEntityType:(CNEntityType)entityType
                 completionHandler:(void (^)(BOOL granted, NSError *error))completionHandler {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        DGPermissionNoteFake(DGPermKindContacts, @"requestAccess → 直接回调 granted，不弹框");
        if (completionHandler) completionHandler(YES, nil);
        return;
    }
    %orig;
}

- (NSArray<CNContact *> *)unifiedContactsMatchingPredicate:(NSPredicate *)predicate
                                               keysToFetch:(NSArray<CNKeyDescriptor> *)keys
                                                     error:(NSError **)error {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        DGPermissionNoteFake(DGPermKindContacts, @"unifiedContacts → 空数组");
        return @[];
    }
    return %orig;
}

- (NSArray<CNGroup *> *)groupsMatchingPredicate:(NSPredicate *)predicate
                                          error:(NSError **)error {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        return @[];
    }
    return %orig;
}

- (NSArray<CNContainer *> *)containersMatchingPredicate:(NSPredicate *)predicate
                                                  error:(NSError **)error {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        return @[];
    }
    return %orig;
}

// 写入也假装成功
- (BOOL)executeSaveRequest:(CNSaveRequest *)saveRequest error:(NSError **)error {
    if (DGPermissionFakeForKind(DGPermKindContacts)) {
        DGPermissionNoteFake(DGPermKindContacts, @"executeSaveRequest → 假装成功，不写入");
        return YES;
    }
    return %orig;
}

%end

%end

// ===========================================================================
//  3. 日历 / 提醒事项
// ===========================================================================

%group PermEventHooks

%hook EKEventStore

- (EKAuthorizationStatus)authorizationStatusForEntityType:(EKEntityType)entityType {
    if (DGPermissionFakeForKind(DGPermKindCalendar)) {
        DGPermissionNoteFake(DGPermKindCalendar, @"authorizationStatus → Authorized");
        return EKAuthorizationStatusAuthorized;
    }
    return %orig;
}

- (void)requestAccessToEntityType:(EKEntityType)entityType
                       completion:(EKEventStoreRequestAccessCompletionHandler)completion {
    if (DGPermissionFakeForKind(DGPermKindCalendar)) {
        DGPermissionNoteFake(DGPermKindCalendar, @"requestAccess → 直接回调 granted，不弹框");
        if (completion) completion(YES, nil);
        return;
    }
    %orig;
}

- (NSArray<EKEvent *> *)eventsMatchingPredicate:(NSPredicate *)predicate {
    if (DGPermissionFakeForKind(DGPermKindCalendar)) {
        DGPermissionNoteFake(DGPermKindCalendar, @"eventsMatchingPredicate → 空数组");
        return @[];
    }
    return %orig;
}

- (NSArray<EKReminder *> *)fetchRemindersMatchingPredicate:(NSPredicate *)predicate
                                                completion:(void (^)(NSArray<EKReminder *> *reminders))completion {
    if (DGPermissionFakeForKind(DGPermKindReminders)) {
        DGPermissionNoteFake(DGPermKindReminders, @"fetchReminders → 空数组");
        if (completion) completion(@[]);
        return nil;
    }
    return %orig;
}

%end

%end

// ===========================================================================
//  4. 麦克风 / 摄像头
// ===========================================================================
//
//  这里只伪装「授权状态」，不拦实际录音/拍照。
//  理由：拦了会让视频通话、扫码、拍照全部失效，
//  而用户要的通常是「别偷偷录」，不是「不能用」。
//  真要禁录制，用系统的麦克风指示灯 + 隐私设置。

%group PermAVHooks

%hook AVAudioSession

- (AVAudioSessionRecordPermission)recordPermission {
    if (DGPermissionFakeForKind(DGPermKindMicrophone)) {
        DGPermissionNoteFake(DGPermKindMicrophone, @"recordPermission → Granted");
        return AVAudioSessionRecordPermissionGranted;
    }
    return %orig;
}

- (void)requestRecordPermission:(void (^)(BOOL granted))response {
    if (DGPermissionFakeForKind(DGPermKindMicrophone)) {
        DGPermissionNoteFake(DGPermKindMicrophone, @"requestRecordPermission → 回调 granted，不弹框");
        if (response) response(YES);
        return;
    }
    %orig;
}

%end

%hook AVCaptureDevice

+ (AVAuthorizationStatus)authorizationStatusForMediaType:(AVMediaType)mediaType {
    if (DGPermissionFakeForKind(DGPermKindCamera) ||
        DGPermissionFakeForKind(DGPermKindMicrophone)) {
        DGPermissionNoteFake(DGPermKindCamera, @"authorizationStatusForMediaType → Authorized");
        return AVAuthorizationStatusAuthorized;
    }
    return %orig;
}

+ (void)requestAccessForMediaType:(AVMediaType)mediaType
                completionHandler:(void (^)(BOOL granted))handler {
    if (DGPermissionFakeForKind(DGPermKindCamera) ||
        DGPermissionFakeForKind(DGPermKindMicrophone)) {
        if (handler) handler(YES);
        return;
    }
    %orig;
}

%end

%end

// ===========================================================================
//  5. 定位
// ===========================================================================
//
//  只伪装授权状态，不拦定位本身（拦了地图全废）。
//  航向已经在 DGSensor 那边单独处理了。

%group PermLocationHooks

%hook CLLocationManager

+ (CLAuthorizationStatus)authorizationStatus {
    if (DGPermissionFakeForKind(DGPermKindLocation)) {
        DGPermissionNoteFake(DGPermKindLocation, @"authorizationStatus → AuthorizedWhenInUse");
        return kCLAuthorizationStatusAuthorizedWhenInUse;
    }
    return %orig;
}

- (CLAuthorizationStatus)authorizationStatus {
    if (DGPermissionFakeForKind(DGPermKindLocation)) {
        return kCLAuthorizationStatusAuthorizedWhenInUse;
    }
    return %orig;
}

- (void)requestWhenInUseAuthorization {
    if (DGPermissionFakeForKind(DGPermKindLocation)) {
        DGPermissionNoteFake(DGPermKindLocation, @"requestWhenInUseAuthorization → 不弹框");
        return;
    }
    %orig;
}

- (void)requestAlwaysAuthorization {
    if (DGPermissionFakeForKind(DGPermKindLocation)) {
        return;
    }
    %orig;
}

%end

%end

// ===========================================================================
//  6. 通知
// ===========================================================================
//
//  getNotificationSettings 决定 App 是否弹「请开启通知」引导。
//  伪装成已授权，App 就不弹了。

%group PermNotifyHooks

%hook UNUserNotificationCenter

- (void)getNotificationSettingsWithCompletionHandler:(void (^)(UNNotificationSettings *settings))completionHandler {
    if (DGPermissionFakeForKind(DGPermKindNotifications)) {
        DGPermissionNoteFake(DGPermKindNotifications, @"getNotificationSettings → 伪造已授权");
        if (completionHandler) {
            // UNNotificationSettings 没有公开 init，[new] 会抛 unavailable。
            // 用 alloc + 私有 init 造一个，KVC 塞关键字段。
            // 任何一步失败都退回 %orig —— 绝不能让 App 因为拿不到 settings 崩。
            UNNotificationSettings *fake = nil;
            @try {
                fake = [UNNotificationSettings alloc];
                // 私有初始化方法，不同系统版本名字可能不同，逐个试
                SEL inits[] = {
                    sel_registerName("init"),
                    sel_registerName("_init"),
                    sel_registerName("initWithCoder:"),
                };
                for (int i = 0; i < 3 && !fake; i++) {
                    if ([fake respondsToSelector:inits[i]]) {
                        if (i == 2) {
                            fake = ((id (*)(id, SEL, id))objc_msgSend)(fake, inits[i], nil);
                        } else {
                            fake = ((id (*)(id, SEL))objc_msgSend)(fake, inits[i]);
                        }
                    }
                }
                if (fake) {
                    [fake setValue:@(UNAuthorizationStatusAuthorized)
                            forKey:@"authorizationStatus"];
                    [fake setValue:@(UNNotificationSettingEnabled) forKey:@"alertSetting"];
                    [fake setValue:@(UNNotificationSettingEnabled) forKey:@"soundSetting"];
                    [fake setValue:@(UNNotificationSettingEnabled) forKey:@"badgeSetting"];
                }
            } @catch (NSException *e) {
                DGLog(@"权限伪装", @"伪造 UNNotificationSettings 失败: %@", e.reason);
                fake = nil;
            }
            if (fake) {
                completionHandler(fake);
                return;
            }
        }
    }
    %orig;
}

- (void)requestAuthorizationWithOptions:(UNAuthorizationOptions)options
                      completionHandler:(void (^)(BOOL granted, NSError *error))completionHandler {
    if (DGPermissionFakeForKind(DGPermKindNotifications)) {
        DGPermissionNoteFake(DGPermKindNotifications, @"requestAuthorization → 回调 granted，不弹框");
        if (completionHandler) completionHandler(YES, nil);
        return;
    }
    %orig;
}

%end

%end

// ===========================================================================
//  7. 健康
// ===========================================================================
//
//  健康数据的授权模型和别的不一样：
//  App 永远无法知道「用户是否拒绝了读权限」（隐私设计）。
//  所以这里只需要让 authorizationStatusForType 返回 sharingAuthorized。

%group PermHealthHooks

%hook HKHealthStore

- (HKAuthorizationStatus)authorizationStatusForType:(HKObjectType *)type {
    if (DGPermissionFakeForKind(DGPermKindHealth)) {
        DGPermissionNoteFake(DGPermKindHealth, @"authorizationStatusForType → SharingAuthorized");
        return HKAuthorizationStatusSharingAuthorized;
    }
    return %orig;
}

%end

%end

// ===========================================================================
//  安装
// ===========================================================================

void DGInstallPermissionHooks(void) {
    if (!DGPermissionEnabled()) {
        DGLog(@"权限伪装", @"总开关关闭，跳过安装");
        return;
    }

    // 各个 group 的类可能不存在（App 没链接对应框架），
    // Logos 的 %init 内部会检查，不存在就跳过，不会崩。
    @try { %init(PermPhotoHooks); }    @catch (NSException *e) { DGLog(@"权限伪装", @"Photo group 失败: %@", e.reason); }
    @try { %init(PermContactHooks); }  @catch (NSException *e) { DGLog(@"权限伪装", @"Contact group 失败: %@", e.reason); }
    @try { %init(PermEventHooks); }    @catch (NSException *e) { DGLog(@"权限伪装", @"Event group 失败: %@", e.reason); }
    @try { %init(PermAVHooks); }       @catch (NSException *e) { DGLog(@"权限伪装", @"AV group 失败: %@", e.reason); }
    @try { %init(PermLocationHooks); } @catch (NSException *e) { DGLog(@"权限伪装", @"Location group 失败: %@", e.reason); }
    @try { %init(PermNotifyHooks); }   @catch (NSException *e) { DGLog(@"权限伪装", @"Notify group 失败: %@", e.reason); }
    @try { %init(PermHealthHooks); }   @catch (NSException *e) { DGLog(@"权限伪装", @"Health group 失败: %@", e.reason); }

    DGLog(@"权限伪装", @"已安装 for %@", DGBundleIdentifier());
}
